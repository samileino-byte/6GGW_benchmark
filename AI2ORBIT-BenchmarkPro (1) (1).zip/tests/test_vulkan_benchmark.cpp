/**
 * test_vulkan_benchmark.cpp - Tests for the VulkanBenchmark class
 *
 * Validates GPU graphics/compute pipeline benchmarking in simulated
 * (CPU fallback) mode: construction, result validity, and formatting.
 */

#include <gtest/gtest.h>
#include "vulkan_benchmark.h"
#include <string>

// === Construction ===

TEST(VulkanBenchmarkTest, DefaultConstruction)
{
    VulkanBenchmark bench;
    (void)bench;
}

// === Run method ===

TEST(VulkanBenchmarkTest, RunReturnsResults)
{
    VulkanBenchmark bench;
    auto results = bench.run(100); // small iteration count for fast test
    EXPECT_TRUE(results.benchmark_successful);
}

TEST(VulkanBenchmarkTest, SimulatedModeReportsNotAvailable)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    EXPECT_FALSE(results.vulkan_available);
}

TEST(VulkanBenchmarkTest, FillRatePositive)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    EXPECT_GT(results.fill_rate_mpixels_sec, 0.0);
}

TEST(VulkanBenchmarkTest, ShaderOpsPositive)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    EXPECT_GT(results.shader_ops_per_second, 0.0);
}

TEST(VulkanBenchmarkTest, DrawCallsPositive)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    EXPECT_GT(results.draw_calls_per_second, 0.0);
}

// === Format results ===

TEST(VulkanBenchmarkTest, FormatResultsProducesOutput)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    std::string output = VulkanBenchmark::format_results(results);
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("Vulkan Benchmark"), std::string::npos);
}

TEST(VulkanBenchmarkTest, FormatResultsContainsApiVersion)
{
    VulkanBenchmark bench;
    auto results = bench.run(100);
    std::string output = VulkanBenchmark::format_results(results);
    EXPECT_NE(output.find("API Version:"), std::string::npos);
    EXPECT_NE(output.find("1.3.0"), std::string::npos);
}
