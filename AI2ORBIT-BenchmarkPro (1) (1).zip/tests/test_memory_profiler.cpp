/**
 * test_memory_profiler.cpp - Tests for the MemoryProfiler class
 *
 * Validates cache hierarchy profiling: latency measurement,
 * bandwidth measurement, cache level detection, and result formatting.
 */

#include <gtest/gtest.h>
#include "memory_profiler.h"
#include <string>

// === Construction ===

TEST(MemoryProfilerTest, DefaultConstruction)
{
    MemoryProfiler profiler;
    (void)profiler;
}

// === Profile method ===

TEST(MemoryProfilerTest, ProfileReturnsSuccessful)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    EXPECT_TRUE(results.profiling_successful);
}

TEST(MemoryProfilerTest, ProfileDetectsMultipleLevels)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    // Should detect at least 2 cache levels (L1 + DRAM at minimum)
    ASSERT_GE(results.levels.size(), 2u);
}

TEST(MemoryProfilerTest, LevelsHavePositiveLatency)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    for (const auto& level : results.levels)
    {
        EXPECT_GT(level.latency_ns, 0.0) << "Level: " << level.label;
    }
}

TEST(MemoryProfilerTest, LevelsHavePositiveBandwidth)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    for (const auto& level : results.levels)
    {
        EXPECT_GT(level.bandwidth_mbps, 0.0) << "Level: " << level.label;
    }
}

TEST(MemoryProfilerTest, LevelsHavePositiveSize)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    for (const auto& level : results.levels)
    {
        EXPECT_GT(level.size_bytes, 0u) << "Level: " << level.label;
    }
}

TEST(MemoryProfilerTest, LevelsHaveNonEmptyLabel)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    for (const auto& level : results.levels)
    {
        EXPECT_FALSE(level.label.empty());
    }
}

TEST(MemoryProfilerTest, LatencyIncreasesByLevel)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    // Each successive buffer size should generally have equal or higher latency
    for (std::size_t i = 1; i < results.levels.size(); ++i)
    {
        // Allow some tolerance - latency should generally trend upward
        // but adjacent measurements can fluctuate
        EXPECT_GE(results.levels[i].latency_ns, results.levels[0].latency_ns * 0.5)
            << "Level " << i << " latency unexpectedly low";
    }
}

TEST(MemoryProfilerTest, L1LatencyIsPopulated)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    EXPECT_GT(results.l1_latency_ns, 0.0);
}

TEST(MemoryProfilerTest, DramLatencyIsPopulated)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    EXPECT_GT(results.dram_latency_ns, 0.0);
}

TEST(MemoryProfilerTest, DramLatencyHigherThanL1)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    EXPECT_GT(results.dram_latency_ns, results.l1_latency_ns);
}

TEST(MemoryProfilerTest, SmallestBufferIsOneKB)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    ASSERT_FALSE(results.levels.empty());
    EXPECT_EQ(results.levels.front().size_bytes, 1024u);
}

TEST(MemoryProfilerTest, LargestBufferIs64MB)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    ASSERT_FALSE(results.levels.empty());
    EXPECT_EQ(results.levels.back().size_bytes, 64u * 1024u * 1024u);
}

// === Format results ===

TEST(MemoryProfilerTest, FormatResultsProducesOutput)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    std::string output = MemoryProfiler::format_results(results);
    EXPECT_FALSE(output.empty());
}

TEST(MemoryProfilerTest, FormatResultsContainsHeader)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    std::string output = MemoryProfiler::format_results(results);
    EXPECT_NE(output.find("Memory Hierarchy"), std::string::npos);
}

TEST(MemoryProfilerTest, FormatResultsContainsLatency)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    std::string output = MemoryProfiler::format_results(results);
    // Should contain latency data
    EXPECT_NE(output.find("ns"), std::string::npos);
}

TEST(MemoryProfilerTest, FormatResultsContainsBandwidth)
{
    MemoryProfiler profiler;
    auto results = profiler.profile();
    std::string output = MemoryProfiler::format_results(results);
    EXPECT_NE(output.find("MB/s"), std::string::npos);
}

TEST(MemoryProfilerTest, FormatResultsEmptyLevels)
{
    MemoryProfiler::Results results{};
    results.profiling_successful = false;
    std::string output = MemoryProfiler::format_results(results);
    EXPECT_FALSE(output.empty());
}
