#include <gtest/gtest.h>
#include "memory_benchmark.h"
#include <string>
#include <cmath>

TEST(MemoryBenchmarkTest, DefaultConstruction) {
    MemoryBenchmark bench;
    SUCCEED();
}

TEST(MemoryBenchmarkTest, RunWithZeroBufferSize) {
    MemoryBenchmark bench;
    auto results = bench.run(0, 5);
    // Should return default results with throughput 0.
    EXPECT_DOUBLE_EQ(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunWithZeroIterations) {
    MemoryBenchmark bench;
    auto results = bench.run(1024, 0);
    EXPECT_DOUBLE_EQ(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunWithSmallBuffer) {
    MemoryBenchmark bench;
    auto results = bench.run(1024, 5);
    EXPECT_TRUE(results.verification_passed);
    EXPECT_EQ(results.verification_errors, 0u);
}

TEST(MemoryBenchmarkTest, RunWithLargerBuffer) {
    MemoryBenchmark bench;
    auto results = bench.run(1024 * 1024, 3);  // 1 MB
    EXPECT_TRUE(results.verification_passed);
    EXPECT_EQ(results.verification_errors, 0u);
}

TEST(MemoryBenchmarkTest, VerificationPasses) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 10);
    EXPECT_TRUE(results.verification_passed);
    EXPECT_EQ(results.verification_errors, 0u);
}

TEST(MemoryBenchmarkTest, ThroughputIsPositive) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 5);
    EXPECT_GT(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, TimingStatisticsPopulated) {
    MemoryBenchmark bench;
    std::size_t iterations = 5;
    auto results = bench.run(4096, iterations);
    EXPECT_GT(results.timing.min_latency_ns, 0.0);
    EXPECT_GT(results.timing.max_latency_ns, 0.0);
    EXPECT_GT(results.timing.avg_latency_ns, 0.0);
    EXPECT_EQ(results.timing.sample_count, iterations);
}

TEST(MemoryBenchmarkTest, VarianceAndStdDevComputed) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 10);
    // With more than 1 iteration, variance and std_deviation should be >= 0.
    EXPECT_GE(results.timing.variance_ns, 0.0);
    EXPECT_GE(results.timing.std_deviation_ns, 0.0);
}

TEST(MemoryBenchmarkTest, MinLatencyLessOrEqualMax) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 10);
    EXPECT_LE(results.timing.min_latency_ns, results.timing.max_latency_ns);
}

TEST(MemoryBenchmarkTest, AvgLatencyBetweenMinAndMax) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 10);
    EXPECT_GE(results.timing.avg_latency_ns, results.timing.min_latency_ns);
    EXPECT_LE(results.timing.avg_latency_ns, results.timing.max_latency_ns);
}

TEST(MemoryBenchmarkTest, RunContinuousWithMaxRuns) {
    MemoryBenchmark bench;
    // max_runs=3, max_duration=0 -> should complete exactly 3 runs.
    auto results = bench.run_continuous(1024, 5, 3, 0.0);
    EXPECT_TRUE(results.verification_passed);
    EXPECT_EQ(results.verification_errors, 0u);
    // iterations should be iterations_per_run * completed_runs = 5 * 3 = 15
    EXPECT_EQ(results.iterations, 15u);
    EXPECT_GT(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunContinuousWithDuration) {
    MemoryBenchmark bench;
    // max_runs=0, duration=2.0 -> runs for approximately 2 seconds.
    auto results = bench.run_continuous(1024, 5, 0, 2.0);
    EXPECT_TRUE(results.verification_passed);
    EXPECT_GT(results.throughput_mbps, 0.0);
    // Total time should be roughly around 2 seconds (at least 1 second).
    EXPECT_GE(results.timing.total_time_seconds, 0.0);
}

TEST(MemoryBenchmarkTest, RunContinuousZeroBuffer) {
    MemoryBenchmark bench;
    auto results = bench.run_continuous(0, 5, 3, 0.0);
    EXPECT_DOUBLE_EQ(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunContinuousZeroIterations) {
    MemoryBenchmark bench;
    auto results = bench.run_continuous(1024, 0, 3, 0.0);
    EXPECT_DOUBLE_EQ(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunContinuousBothZero) {
    MemoryBenchmark bench;
    // max_runs=0 and duration<=0 -> should return default.
    auto results = bench.run_continuous(1024, 5, 0, 0.0);
    EXPECT_DOUBLE_EQ(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, RunContinuousAggregation) {
    MemoryBenchmark bench;
    auto results = bench.run_continuous(2048, 3, 4, 0.0);
    EXPECT_TRUE(results.verification_passed);
    // Should have aggregated 4 runs of 3 iterations each = 12 total.
    EXPECT_EQ(results.iterations, 12u);
    // sample_count in continuous mode is completed_runs (4).
    EXPECT_EQ(results.timing.sample_count, 4u);
    EXPECT_GT(results.timing.total_time_seconds, 0.0);
    EXPECT_GT(results.throughput_mbps, 0.0);
}

TEST(MemoryBenchmarkTest, PrintResultsDoesNotCrash) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 5);

    testing::internal::CaptureStdout();
    MemoryBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("RAM Benchmark Results"), std::string::npos);
}

TEST(MemoryBenchmarkTest, PrintResultsFailedVerification) {
    MemoryBenchmark::Results results{};
    results.buffer_size_bytes = 4096;
    results.iterations = 5;
    results.verification_passed = false;
    results.verification_errors = 3;
    results.throughput_mbps = 100.0;
    results.timing.total_time_seconds = 1.0;
    results.timing.min_latency_ns = 100.0;
    results.timing.max_latency_ns = 200.0;
    results.timing.avg_latency_ns = 150.0;
    results.timing.sample_count = 5;

    testing::internal::CaptureStdout();
    MemoryBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_NE(output.find("FAILED"), std::string::npos);
    EXPECT_NE(output.find("3 errors"), std::string::npos);
}

TEST(MemoryBenchmarkTest, PrintResultsSmallBuffer) {
    MemoryBenchmark::Results results{};
    results.buffer_size_bytes = 512;  // < 1024 bytes
    results.iterations = 1;
    results.timing.total_time_seconds = 0.001;
    results.timing.sample_count = 1;
    results.verification_passed = true;

    testing::internal::CaptureStdout();
    MemoryBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_NE(output.find("512"), std::string::npos);
    EXPECT_NE(output.find("bytes"), std::string::npos);
}

TEST(MemoryBenchmarkTest, PrintResultsKBBuffer) {
    MemoryBenchmark::Results results{};
    results.buffer_size_bytes = 8192;  // 8 KB
    results.iterations = 1;
    results.timing.total_time_seconds = 0.001;
    results.timing.sample_count = 1;
    results.verification_passed = true;

    testing::internal::CaptureStdout();
    MemoryBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_NE(output.find("KB"), std::string::npos);
}

TEST(MemoryBenchmarkTest, PrintResultsMBBuffer) {
    MemoryBenchmark::Results results{};
    results.buffer_size_bytes = 2 * 1024 * 1024;  // 2 MB
    results.iterations = 1;
    results.timing.total_time_seconds = 0.001;
    results.timing.sample_count = 1;
    results.verification_passed = true;

    testing::internal::CaptureStdout();
    MemoryBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_NE(output.find("MB"), std::string::npos);
}

TEST(MemoryBenchmarkTest, SingleIterationStats) {
    MemoryBenchmark bench;
    auto results = bench.run(4096, 1);
    // With 1 iteration, calculate_statistics returns variance=0 and stddev=0.
    EXPECT_DOUBLE_EQ(results.timing.variance_ns, 0.0);
    EXPECT_DOUBLE_EQ(results.timing.std_deviation_ns, 0.0);
}
