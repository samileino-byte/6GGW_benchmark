/**
 * test_cuda_native.cpp - Tests for the CudaNative CUDA-C benchmark
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * Validates all CUDA-C kernel benchmarks in CPU emulation mode:
 * SGEMM, reduction, stencil, memory hierarchy, PCIe, atomics,
 * DRAM speedup, and full suite execution.
 */

#include <gtest/gtest.h>
#include "cuda_native.h"
#include <string>
#include <vector>

// === Construction ===

TEST(CudaNativeTest, DefaultConstruction) {
    CudaNative bench;
    (void)bench;
}

TEST(CudaNativeTest, CudaNotAvailableInEmulation) {
    CudaNative bench;
    EXPECT_FALSE(bench.is_cuda_available());
}

// === SGEMM Kernel ===

TEST(CudaNativeTest, SgemmReturnsPositiveThroughput) {
    CudaNative bench;
    auto result = bench.run_sgemm(128);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.throughput, 0.0);
    EXPECT_EQ(result.throughput_unit, "GFLOPS");
}

TEST(CudaNativeTest, SgemmElapsedTimePositive) {
    CudaNative bench;
    auto result = bench.run_sgemm(64);
    EXPECT_GT(result.elapsed_ms, 0.0);
}

TEST(CudaNativeTest, SgemmKernelName) {
    CudaNative bench;
    auto result = bench.run_sgemm(64);
    EXPECT_NE(result.kernel_name.find("SGEMM"), std::string::npos);
}

TEST(CudaNativeTest, SgemmLargerDimHigherThroughput) {
    CudaNative bench;
    auto small = bench.run_sgemm(64);
    auto large = bench.run_sgemm(256);
    // Larger matrices generally have better FLOPS utilization
    // Both should at least be positive
    EXPECT_GT(small.throughput, 0.0);
    EXPECT_GT(large.throughput, 0.0);
}

// === Parallel Reduction ===

TEST(CudaNativeTest, ReductionReturnsPositiveThroughput) {
    CudaNative bench;
    auto result = bench.run_reduction(1024 * 1024);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.throughput, 0.0);
    EXPECT_EQ(result.throughput_unit, "GB/s");
}

TEST(CudaNativeTest, ReductionKernelName) {
    CudaNative bench;
    auto result = bench.run_reduction(1024);
    EXPECT_NE(result.kernel_name.find("Reduction"), std::string::npos);
}

// === 2D Stencil ===

TEST(CudaNativeTest, StencilReturnsPositiveThroughput) {
    CudaNative bench;
    auto result = bench.run_stencil(256, 256);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.throughput, 0.0);
    EXPECT_EQ(result.throughput_unit, "GB/s");
}

TEST(CudaNativeTest, StencilKernelName) {
    CudaNative bench;
    auto result = bench.run_stencil(64, 64);
    EXPECT_NE(result.kernel_name.find("Stencil"), std::string::npos);
}

// === Memory Hierarchy ===

TEST(CudaNativeTest, MemoryHierarchyReturnsTiers) {
    CudaNative bench;
    auto tiers = bench.measure_memory_hierarchy(1024 * 1024);
    EXPECT_GE(tiers.size(), 5u);
}

TEST(CudaNativeTest, MemoryHierarchyTierNamesValid) {
    CudaNative bench;
    auto tiers = bench.measure_memory_hierarchy(1024 * 1024);
    bool has_registers = false;
    bool has_global = false;
    for (const auto& t : tiers) {
        if (t.tier_name.find("Registers") != std::string::npos) has_registers = true;
        if (t.tier_name.find("Global") != std::string::npos) has_global = true;
    }
    EXPECT_TRUE(has_registers);
    EXPECT_TRUE(has_global);
}

TEST(CudaNativeTest, MemoryHierarchyBandwidthDecreases) {
    CudaNative bench;
    auto tiers = bench.measure_memory_hierarchy(1024 * 1024);
    // Registers should be faster than Global
    if (tiers.size() >= 5) {
        EXPECT_GT(tiers[0].bandwidth_gbps, tiers[4].bandwidth_gbps);
    }
}

TEST(CudaNativeTest, MemoryHierarchyLatencyIncreases) {
    CudaNative bench;
    auto tiers = bench.measure_memory_hierarchy(1024 * 1024);
    // Registers should have lower latency than Global
    if (tiers.size() >= 5) {
        EXPECT_LT(tiers[0].latency_ns, tiers[4].latency_ns);
    }
}

// === PCIe Transfer ===

TEST(CudaNativeTest, PcieTransferPositive) {
    CudaNative bench;
    auto result = bench.run_pcie_transfer(4 * 1024 * 1024);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.throughput, 0.0);
    EXPECT_EQ(result.throughput_unit, "GB/s");
}

TEST(CudaNativeTest, PcieTransferReasonableRange) {
    CudaNative bench;
    auto result = bench.run_pcie_transfer(4 * 1024 * 1024);
    // PCIe 4.0 x16 max ~32 GB/s, we cap at 25
    EXPECT_LE(result.throughput, 26.0);
}

// === Atomic Operations ===

TEST(CudaNativeTest, AtomicsReturnsPositive) {
    CudaNative bench;
    auto result = bench.run_atomics(1024 * 1024);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.throughput, 0.0);
    EXPECT_EQ(result.throughput_unit, "Gops/s");
}

// === DRAM Speedup ===

TEST(CudaNativeTest, DramSpeedupPositive) {
    CudaNative bench;
    double speedup = bench.measure_dram_speedup(256 * 1024);
    EXPECT_GT(speedup, 0.0);
}

TEST(CudaNativeTest, DramSpeedupReasonableRange) {
    CudaNative bench;
    double speedup = bench.measure_dram_speedup(256 * 1024);
    // Expected 2-6x range with GPU scaling
    EXPECT_GT(speedup, 1.0);
    EXPECT_LT(speedup, 50.0);
}

// === Full Suite ===

TEST(CudaNativeTest, FullSuiteCompletes) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024); // Small sizes for speed
    EXPECT_TRUE(results.benchmark_successful);
}

TEST(CudaNativeTest, FullSuiteHasAllKernels) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_GE(results.kernel_results.size(), 5u);
}

TEST(CudaNativeTest, FullSuiteHasMemoryTiers) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_GE(results.memory_tiers.size(), 5u);
}

TEST(CudaNativeTest, FullSuiteAggregateScores) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_GT(results.peak_compute_gflops, 0.0);
    EXPECT_GT(results.peak_memory_bandwidth_gbps, 0.0);
    EXPECT_GT(results.pcie_host_to_device_gbps, 0.0);
    EXPECT_GT(results.pcie_device_to_host_gbps, 0.0);
    EXPECT_GT(results.pcie_bidirectional_gbps, 0.0);
}

TEST(CudaNativeTest, FullSuiteDramOptimization) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_GT(results.dram_optimized_speedup, 1.0);
}

TEST(CudaNativeTest, FullSuiteTimingPositive) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_GT(results.total_time_seconds, 0.0);
}

TEST(CudaNativeTest, FullSuiteDeviceInfo) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    EXPECT_FALSE(results.device_name.empty());
    EXPECT_FALSE(results.cuda_available);
}

// === Format Results ===

TEST(CudaNativeTest, FormatResultsProducesOutput) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    std::string output = CudaNative::format_results(results);
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("CUDA-C Native"), std::string::npos);
}

TEST(CudaNativeTest, FormatResultsContainsKernelInfo) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    std::string output = CudaNative::format_results(results);
    EXPECT_NE(output.find("SGEMM"), std::string::npos);
    EXPECT_NE(output.find("Reduction"), std::string::npos);
    EXPECT_NE(output.find("Stencil"), std::string::npos);
}

TEST(CudaNativeTest, FormatResultsContainsMemoryHierarchy) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    std::string output = CudaNative::format_results(results);
    EXPECT_NE(output.find("Memory Hierarchy"), std::string::npos);
    EXPECT_NE(output.find("Registers"), std::string::npos);
    EXPECT_NE(output.find("Global"), std::string::npos);
}

TEST(CudaNativeTest, FormatResultsContainsDramOptimization) {
    CudaNative bench;
    auto results = bench.run(128, 256 * 1024);
    std::string output = CudaNative::format_results(results);
    EXPECT_NE(output.find("DRAM"), std::string::npos);
}
