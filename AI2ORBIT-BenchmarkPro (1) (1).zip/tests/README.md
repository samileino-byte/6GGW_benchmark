# BenchmarkCore Test Suite

## Overview

This directory contains Google Test (gtest) unit tests for the BenchmarkCore library:

- **test_timer.cpp** - Tests for the `Timer` header-only class (start, elapsed_seconds, elapsed_nanoseconds).
- **test_cpu_benchmark.cpp** - Tests for `CpuBenchmark` (run, print_results, edge cases).
- **test_memory_benchmark.cpp** - Tests for `MemoryBenchmark` (run, run_continuous, print_results, edge cases, statistics).

## Prerequisites

- CMake 3.14 or higher
- C++17 compatible compiler (GCC 7+, Clang 5+, MSVC 2017+)
- Internet connection (for FetchContent to download Google Test on first build)

Optional for coverage:
- lcov
- genhtml (part of lcov package)

## Building and Running Tests

### Standard build

```bash
mkdir -p build && cd build
cmake ..
make -j$(nproc)
ctest --output-on-failure
```

### Build with code coverage

```bash
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Debug -DENABLE_COVERAGE=ON
make -j$(nproc)
ctest --output-on-failure
```

### Generate coverage report

After running tests with coverage enabled:

```bash
cd build
lcov --capture --directory . --output-file coverage.info --ignore-errors mismatch
lcov --remove coverage.info '/usr/*' '*/googletest/*' '*/gtest/*' '*/_deps/*' \
     --output-file coverage_filtered.info --ignore-errors unused
genhtml coverage_filtered.info --output-directory coverage_report
```

Open `build/coverage_report/index.html` in a browser to view the report.

## Test Structure

Each test file follows the pattern:

- **DefaultConstruction** - Verifies the class can be instantiated.
- **Edge cases** - Zero/invalid inputs return appropriate defaults or failure flags.
- **Functional tests** - Verify correct results, timing, and statistics.
- **Print tests** - Verify `print_results()` produces expected output without crashing.

## CI/CD

The `.github/workflows/test.yml` workflow automatically builds, tests, and generates coverage reports on push/PR to main/master branches.
