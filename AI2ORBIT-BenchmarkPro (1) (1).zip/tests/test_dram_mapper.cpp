/**
 * test_dram_mapper.cpp - Tests for the DramMapper class
 *
 * Validates the 5-priority RAM table mapping, virtual memory pool,
 * prioritized allocation, acceleration measurement, and formatting.
 */

#include <gtest/gtest.h>
#include "dram_mapper.h"
#include <string>
#include <cstdlib>

// Use a small probe size for fast tests
static constexpr std::size_t TEST_PROBE_SIZE = 1024 * 1024; // 1MB

// === Construction ===

TEST(DramMapperTest, DefaultConstruction)
{
    DramMapper mapper;
    (void)mapper;
}

// === Map memory ===

TEST(DramMapperTest, MapMemorySucceeds)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    EXPECT_TRUE(results.mapping_successful);
}

TEST(DramMapperTest, MapsMultipleRegions)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    // With 1MB max and 4KB start, doubling: 4K,8K,16K,32K,64K,128K,256K,512K,1M = 9 regions
    EXPECT_GE(results.regions_mapped, 2u);
}

TEST(DramMapperTest, RegionsHavePositiveLatency)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    EXPECT_GT(results.fastest_latency_ns, 0.0);
    EXPECT_GT(results.slowest_latency_ns, 0.0);
}

TEST(DramMapperTest, RegionsHavePositiveBandwidth)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);

    // Check that all regions across all tables have positive bandwidth
    auto check_regions = [](const std::vector<DramMapper::MemoryRegion>& regions) {
        for (const auto& r : regions) {
            EXPECT_GT(r.bandwidth_mbps, 0.0) << "Region " << r.label << " has zero bandwidth";
        }
    };

    check_regions(results.tables.table1_cpu_ram);
    check_regions(results.tables.table2_ram);
    check_regions(results.tables.table3_priority);
    check_regions(results.tables.table4_extra);
    check_regions(results.tables.table5_partial);
}

TEST(DramMapperTest, AllRegionsClassified)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);

    // Total regions across all tables should equal regions_mapped
    std::size_t total_in_tables =
        results.tables.table1_cpu_ram.size() +
        results.tables.table2_ram.size() +
        results.tables.table3_priority.size() +
        results.tables.table4_extra.size() +
        results.tables.table5_partial.size();

    EXPECT_EQ(total_in_tables, results.regions_mapped);

    // All regions should have table 1-5
    auto check_table = [](const std::vector<DramMapper::MemoryRegion>& regions, int expected_table) {
        for (const auto& r : regions) {
            EXPECT_EQ(r.priority_table, expected_table);
        }
    };

    check_table(results.tables.table1_cpu_ram, 1);
    check_table(results.tables.table2_ram, 2);
    check_table(results.tables.table3_priority, 3);
    check_table(results.tables.table4_extra, 4);
    check_table(results.tables.table5_partial, 5);
}

TEST(DramMapperTest, Table1IsFastest)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);

    if (!results.tables.table1_cpu_ram.empty() && !results.tables.table5_partial.empty()) {
        // Table 1 regions should have lower or equal average latency than table 5
        double t1_avg = 0.0;
        for (const auto& r : results.tables.table1_cpu_ram) {
            t1_avg += (r.read_latency_ns + r.write_latency_ns) / 2.0;
        }
        t1_avg /= static_cast<double>(results.tables.table1_cpu_ram.size());

        double t5_avg = 0.0;
        for (const auto& r : results.tables.table5_partial) {
            t5_avg += (r.read_latency_ns + r.write_latency_ns) / 2.0;
        }
        t5_avg /= static_cast<double>(results.tables.table5_partial.size());

        EXPECT_LE(t1_avg, t5_avg);
    }
    // If either table is empty, the test passes trivially
    SUCCEED();
}

TEST(DramMapperTest, Table5IsSlowest)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);

    if (!results.tables.table5_partial.empty() && !results.tables.table1_cpu_ram.empty()) {
        double t5_avg = 0.0;
        for (const auto& r : results.tables.table5_partial) {
            t5_avg += (r.read_latency_ns + r.write_latency_ns) / 2.0;
        }
        t5_avg /= static_cast<double>(results.tables.table5_partial.size());

        double t1_avg = 0.0;
        for (const auto& r : results.tables.table1_cpu_ram) {
            t1_avg += (r.read_latency_ns + r.write_latency_ns) / 2.0;
        }
        t1_avg /= static_cast<double>(results.tables.table1_cpu_ram.size());

        EXPECT_GE(t5_avg, t1_avg);
    }
    SUCCEED();
}

TEST(DramMapperTest, VirtualizationRatioNear4Point2)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    // Should be approximately 4.2x (allow some tolerance for integer truncation)
    EXPECT_GT(results.virtualization_ratio, 4.0);
    EXPECT_LT(results.virtualization_ratio, 4.5);
}

TEST(DramMapperTest, VirtualPoolLargerThanPhysical)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    EXPECT_GT(results.virtual_pool_bytes, results.total_mapped_bytes);
}

TEST(DramMapperTest, StopMarkersDetected)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    // Stop markers count should be a non-negative integer (may be 0 if latencies are uniform)
    // We just verify the field is populated and the function doesn't crash
    EXPECT_GE(results.stop_markers_hit, static_cast<std::size_t>(0));
}

// === Prioritized allocation ===

TEST(DramMapperTest, AllocatePrioritizedReturnsNonNull)
{
    DramMapper mapper;
    mapper.map_memory(TEST_PROBE_SIZE);
    void* ptr = mapper.allocate_prioritized(1024);
    EXPECT_NE(ptr, nullptr);
    mapper.free_prioritized(ptr);
}

TEST(DramMapperTest, FreePrioritizedDoesNotCrash)
{
    DramMapper mapper;
    mapper.map_memory(TEST_PROBE_SIZE);
    void* ptr = mapper.allocate_prioritized(1024);
    ASSERT_NE(ptr, nullptr);
    // Should not crash
    mapper.free_prioritized(ptr);
    // Freeing nullptr should also be safe
    mapper.free_prioritized(nullptr);
}

// === Acceleration ===

TEST(DramMapperTest, MeasureAccelerationReturnsPositive)
{
    DramMapper mapper;
    mapper.map_memory(TEST_PROBE_SIZE);
    double accel = mapper.measure_acceleration();
    EXPECT_GT(accel, 0.0);
}

// === Format results ===

TEST(DramMapperTest, FormatResultsProducesOutput)
{
    DramMapper mapper;
    auto results = mapper.map_memory(TEST_PROBE_SIZE);
    std::string output = DramMapper::format_results(results);
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("DRAM Mapper"), std::string::npos);
}
