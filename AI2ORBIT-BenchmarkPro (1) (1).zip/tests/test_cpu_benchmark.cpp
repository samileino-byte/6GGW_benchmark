#include <gtest/gtest.h>
#include "cpu_benchmark.h"
#include <string>
#include <cmath>

TEST(CpuBenchmarkTest, DefaultConstruction) {
    CpuBenchmark bench;
    SUCCEED();
}

TEST(CpuBenchmarkTest, RunWithZeroIterationsReturnsFailed) {
    CpuBenchmark bench;
    auto results = bench.run(0);
    EXPECT_FALSE(results.benchmark_successful);
}

TEST(CpuBenchmarkTest, RunWithSmallIterations) {
    CpuBenchmark bench;
    auto results = bench.run(100);
    EXPECT_TRUE(results.benchmark_successful);
    EXPECT_GT(results.timing.total_time_seconds, 0.0);
    EXPECT_GT(results.timing.operations_per_second, 0.0);
    EXPECT_GT(results.timing.time_per_operation_ns, 0.0);
}

TEST(CpuBenchmarkTest, RunWithLargeIterations) {
    CpuBenchmark bench;
    auto results = bench.run(1000000);
    EXPECT_TRUE(results.benchmark_successful);
    EXPECT_GT(results.timing.total_time_seconds, 0.0);
}

TEST(CpuBenchmarkTest, BenchmarkTypeIsCorrect) {
    CpuBenchmark bench;
    auto results = bench.run(100);
    EXPECT_EQ(results.benchmark_type, "Mixed CPU Workload");
}

TEST(CpuBenchmarkTest, TimingValuesArePositive) {
    CpuBenchmark bench;
    auto results = bench.run(1000);
    ASSERT_TRUE(results.benchmark_successful);
    EXPECT_GT(results.timing.total_time_seconds, 0.0);
    EXPECT_GT(results.timing.operations_per_second, 0.0);
    EXPECT_GT(results.timing.time_per_operation_ns, 0.0);
}

TEST(CpuBenchmarkTest, OperationsPerSecondCalculation) {
    CpuBenchmark bench;
    std::size_t iterations = 10000;
    auto results = bench.run(iterations);
    ASSERT_TRUE(results.benchmark_successful);

    // ops/sec should equal (iterations * 3) / total_time approximately.
    double expected_ops = static_cast<double>(iterations * 3) / results.timing.total_time_seconds;
    double ratio = results.timing.operations_per_second / expected_ops;
    EXPECT_NEAR(ratio, 1.0, 0.01);
}

TEST(CpuBenchmarkTest, TimePerOperationCalculation) {
    CpuBenchmark bench;
    auto results = bench.run(10000);
    ASSERT_TRUE(results.benchmark_successful);

    // time_per_op_ns * ops_per_sec should approximate 1e9.
    double product = results.timing.time_per_operation_ns * results.timing.operations_per_second;
    EXPECT_NEAR(product / 1e9, 1.0, 0.01);
}

TEST(CpuBenchmarkTest, PrintResultsDoesNotCrash) {
    CpuBenchmark bench;
    auto results = bench.run(100);

    testing::internal::CaptureStdout();
    CpuBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("CPU Benchmark Results"), std::string::npos);
    EXPECT_NE(output.find("Mixed CPU Workload"), std::string::npos);
}

TEST(CpuBenchmarkTest, PrintResultsFailedBenchmark) {
    CpuBenchmark::Results results{};
    results.benchmark_successful = false;
    results.benchmark_type = "Mixed CPU Workload";
    results.iterations = 0;

    testing::internal::CaptureStdout();
    CpuBenchmark::print_results(results);
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_NE(output.find("failed"), std::string::npos);
}

TEST(CpuBenchmarkTest, DeterministicIterationCount) {
    CpuBenchmark bench;
    std::size_t input_iterations = 5000;
    auto results = bench.run(input_iterations);
    EXPECT_EQ(results.iterations, input_iterations);
}

TEST(CpuBenchmarkTest, MultipleRunsProduceResults) {
    CpuBenchmark bench;
    auto results1 = bench.run(500);
    auto results2 = bench.run(500);
    EXPECT_TRUE(results1.benchmark_successful);
    EXPECT_TRUE(results2.benchmark_successful);
}
