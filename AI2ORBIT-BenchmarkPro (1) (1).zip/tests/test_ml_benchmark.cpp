/**
 * test_ml_benchmark.cpp - Tests for the MlBenchmark AI/ML module
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * Validates neural network operations: matrix math, activation functions,
 * forward pass, backpropagation, training, inference, convolution,
 * and full benchmark suite.
 */

#include <gtest/gtest.h>
#include "ml_benchmark.h"
#include <cmath>
#include <string>

// === Matrix Operations ===

TEST(MlBenchmarkTest, MatrixConstruction) {
    MlBenchmark::Matrix m(3, 4);
    EXPECT_EQ(m.rows, 3u);
    EXPECT_EQ(m.cols, 4u);
    EXPECT_EQ(m.data.size(), 12u);
}

TEST(MlBenchmarkTest, MatrixFillConstruction) {
    MlBenchmark::Matrix m(2, 3, 1.5f);
    EXPECT_FLOAT_EQ(m.at(0, 0), 1.5f);
    EXPECT_FLOAT_EQ(m.at(1, 2), 1.5f);
}

TEST(MlBenchmarkTest, MatrixAccess) {
    MlBenchmark::Matrix m(2, 2);
    m.at(0, 0) = 1.0f;
    m.at(0, 1) = 2.0f;
    m.at(1, 0) = 3.0f;
    m.at(1, 1) = 4.0f;
    EXPECT_FLOAT_EQ(m.at(1, 0), 3.0f);
}

TEST(MlBenchmarkTest, MatmulIdentity) {
    // Multiply by identity matrix
    MlBenchmark::Matrix a(2, 2);
    a.at(0, 0) = 1.0f; a.at(0, 1) = 2.0f;
    a.at(1, 0) = 3.0f; a.at(1, 1) = 4.0f;

    MlBenchmark::Matrix id(2, 2);
    id.at(0, 0) = 1.0f; id.at(1, 1) = 1.0f;

    auto result = MlBenchmark::matmul(a, id);
    EXPECT_FLOAT_EQ(result.at(0, 0), 1.0f);
    EXPECT_FLOAT_EQ(result.at(0, 1), 2.0f);
    EXPECT_FLOAT_EQ(result.at(1, 0), 3.0f);
    EXPECT_FLOAT_EQ(result.at(1, 1), 4.0f);
}

TEST(MlBenchmarkTest, MatmulCompute) {
    MlBenchmark::Matrix a(1, 3);
    a.at(0, 0) = 1.0f; a.at(0, 1) = 2.0f; a.at(0, 2) = 3.0f;

    MlBenchmark::Matrix b(3, 1);
    b.at(0, 0) = 4.0f; b.at(1, 0) = 5.0f; b.at(2, 0) = 6.0f;

    auto result = MlBenchmark::matmul(a, b);
    EXPECT_EQ(result.rows, 1u);
    EXPECT_EQ(result.cols, 1u);
    EXPECT_FLOAT_EQ(result.at(0, 0), 32.0f); // 1*4 + 2*5 + 3*6
}

TEST(MlBenchmarkTest, TransposeCorrect) {
    MlBenchmark::Matrix m(2, 3);
    m.at(0, 0) = 1.0f; m.at(0, 1) = 2.0f; m.at(0, 2) = 3.0f;
    m.at(1, 0) = 4.0f; m.at(1, 1) = 5.0f; m.at(1, 2) = 6.0f;

    auto t = MlBenchmark::transpose(m);
    EXPECT_EQ(t.rows, 3u);
    EXPECT_EQ(t.cols, 2u);
    EXPECT_FLOAT_EQ(t.at(0, 0), 1.0f);
    EXPECT_FLOAT_EQ(t.at(2, 1), 6.0f);
}

TEST(MlBenchmarkTest, HadamardProduct) {
    MlBenchmark::Matrix a(2, 2, 3.0f);
    MlBenchmark::Matrix b(2, 2, 2.0f);
    auto result = MlBenchmark::hadamard(a, b);
    EXPECT_FLOAT_EQ(result.at(0, 0), 6.0f);
}

// === Activation Functions ===

TEST(MlBenchmarkTest, SigmoidZero) {
    EXPECT_NEAR(MlBenchmark::sigmoid(0.0f), 0.5f, 1e-5f);
}

TEST(MlBenchmarkTest, SigmoidLargePositive) {
    EXPECT_NEAR(MlBenchmark::sigmoid(30.0f), 1.0f, 1e-5f);
}

TEST(MlBenchmarkTest, SigmoidLargeNegative) {
    EXPECT_NEAR(MlBenchmark::sigmoid(-30.0f), 0.0f, 1e-5f);
}

TEST(MlBenchmarkTest, ReluPositive) {
    EXPECT_FLOAT_EQ(MlBenchmark::relu(5.0f), 5.0f);
}

TEST(MlBenchmarkTest, ReluNegative) {
    EXPECT_FLOAT_EQ(MlBenchmark::relu(-3.0f), 0.0f);
}

TEST(MlBenchmarkTest, ReluZero) {
    EXPECT_FLOAT_EQ(MlBenchmark::relu(0.0f), 0.0f);
}

TEST(MlBenchmarkTest, ApplyActivationRelu) {
    MlBenchmark::Matrix m(1, 4);
    m.data = {-2.0f, -1.0f, 0.0f, 3.0f};
    MlBenchmark::apply_activation(m, "relu");
    EXPECT_FLOAT_EQ(m.data[0], 0.0f);
    EXPECT_FLOAT_EQ(m.data[1], 0.0f);
    EXPECT_FLOAT_EQ(m.data[2], 0.0f);
    EXPECT_FLOAT_EQ(m.data[3], 3.0f);
}

TEST(MlBenchmarkTest, SoftmaxSumsToOne) {
    MlBenchmark::Matrix m(1, 4);
    m.data = {1.0f, 2.0f, 3.0f, 4.0f};
    MlBenchmark::apply_softmax(m);
    float sum = m.data[0] + m.data[1] + m.data[2] + m.data[3];
    EXPECT_NEAR(sum, 1.0f, 1e-5f);
}

TEST(MlBenchmarkTest, SoftmaxLargestInputHighestOutput) {
    MlBenchmark::Matrix m(1, 3);
    m.data = {1.0f, 5.0f, 2.0f};
    MlBenchmark::apply_softmax(m);
    EXPECT_GT(m.data[1], m.data[0]);
    EXPECT_GT(m.data[1], m.data[2]);
}

TEST(MlBenchmarkTest, SoftmaxMultipleRows) {
    MlBenchmark::Matrix m(2, 3);
    m.data = {1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f};
    MlBenchmark::apply_softmax(m);
    float sum1 = m.at(0, 0) + m.at(0, 1) + m.at(0, 2);
    float sum2 = m.at(1, 0) + m.at(1, 1) + m.at(1, 2);
    EXPECT_NEAR(sum1, 1.0f, 1e-5f);
    EXPECT_NEAR(sum2, 1.0f, 1e-5f);
}

// === Loss Functions ===

TEST(MlBenchmarkTest, CrossEntropyLossPositive) {
    MlBenchmark::Matrix pred(1, 3);
    pred.data = {0.7f, 0.2f, 0.1f};
    MlBenchmark::Matrix target(1, 3);
    target.data = {1.0f, 0.0f, 0.0f};
    float loss = MlBenchmark::cross_entropy_loss(pred, target);
    EXPECT_GT(loss, 0.0f);
}

TEST(MlBenchmarkTest, CrossEntropyPerfectPrediction) {
    MlBenchmark::Matrix pred(1, 3);
    pred.data = {0.99f, 0.005f, 0.005f};
    MlBenchmark::Matrix target(1, 3);
    target.data = {1.0f, 0.0f, 0.0f};
    float loss = MlBenchmark::cross_entropy_loss(pred, target);
    EXPECT_LT(loss, 0.1f); // Low loss for correct prediction
}

TEST(MlBenchmarkTest, MseLossZeroForIdentical) {
    MlBenchmark::Matrix a(1, 3, 0.5f);
    float loss = MlBenchmark::mse_loss(a, a);
    EXPECT_NEAR(loss, 0.0f, 1e-6f);
}

TEST(MlBenchmarkTest, MseLossPositiveForDifferent) {
    MlBenchmark::Matrix pred(1, 3);
    pred.data = {0.0f, 0.0f, 0.0f};
    MlBenchmark::Matrix target(1, 3);
    target.data = {1.0f, 1.0f, 1.0f};
    float loss = MlBenchmark::mse_loss(pred, target);
    EXPECT_GT(loss, 0.0f);
}

// === 2D Convolution ===

TEST(MlBenchmarkTest, Conv2dOutputSize) {
    MlBenchmark::Matrix input(5, 5, 1.0f);
    MlBenchmark::Matrix kernel(3, 3, 1.0f);
    auto output = MlBenchmark::conv2d(input, kernel);
    EXPECT_EQ(output.rows, 3u); // 5-3+1
    EXPECT_EQ(output.cols, 3u);
}

TEST(MlBenchmarkTest, Conv2dUniformResult) {
    MlBenchmark::Matrix input(4, 4, 1.0f);
    MlBenchmark::Matrix kernel(2, 2, 0.25f);
    auto output = MlBenchmark::conv2d(input, kernel);
    // Each output = sum of 4 elements * 0.25 = 1.0
    EXPECT_NEAR(output.at(0, 0), 1.0f, 1e-5f);
}

TEST(MlBenchmarkTest, Conv2dMnistSize) {
    // MNIST input 28x28, 3x3 kernel -> 26x26 output
    MlBenchmark::Matrix input(28, 28, 0.5f);
    MlBenchmark::Matrix kernel(3, 3, 0.1f);
    auto output = MlBenchmark::conv2d(input, kernel);
    EXPECT_EQ(output.rows, 26u);
    EXPECT_EQ(output.cols, 26u);
}

// === Network Creation ===

TEST(MlBenchmarkTest, CreateNetworkLayers) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {784, 128, "relu"},
        {128, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    EXPECT_EQ(net.layers.size(), 2u);
}

TEST(MlBenchmarkTest, CreateNetworkParameters) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {784, 128, "relu"},
        {128, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    // 784*128 + 128 + 128*10 + 10 = 100480 + 128 + 1280 + 10 = 101898
    EXPECT_EQ(net.total_parameters, 784u * 128 + 128 + 128u * 10 + 10);
}

TEST(MlBenchmarkTest, CreateNetworkWeightsDimensions) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {784, 64, "sigmoid"},
        {64, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    EXPECT_EQ(net.layers[0].weights.rows, 784u);
    EXPECT_EQ(net.layers[0].weights.cols, 64u);
    EXPECT_EQ(net.layers[1].weights.rows, 64u);
    EXPECT_EQ(net.layers[1].weights.cols, 10u);
}

// === Forward Pass ===

TEST(MlBenchmarkTest, ForwardPassOutputShape) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {784, 128, "relu"},
        {128, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    MlBenchmark::Matrix input(1, 784, 0.5f);
    auto output = MlBenchmark::forward(net, input);
    EXPECT_EQ(output.rows, 1u);
    EXPECT_EQ(output.cols, 10u);
}

TEST(MlBenchmarkTest, ForwardPassSoftmaxOutput) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {10, 5, "relu"},
        {5, 3, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    MlBenchmark::Matrix input(1, 10, 0.5f);
    auto output = MlBenchmark::forward(net, input);
    // Softmax output should sum to 1
    float sum = 0.0f;
    for (auto& v : output.data) sum += v;
    EXPECT_NEAR(sum, 1.0f, 1e-4f);
}

TEST(MlBenchmarkTest, ForwardPassBatchInput) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {784, 64, "relu"},
        {64, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    MlBenchmark::Matrix input(32, 784, 0.3f); // Batch of 32
    auto output = MlBenchmark::forward(net, input);
    EXPECT_EQ(output.rows, 32u);
    EXPECT_EQ(output.cols, 10u);
}

// === Backpropagation ===

TEST(MlBenchmarkTest, BackwardReturnsLoss) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {4, 3, "relu"},
        {3, 2, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    MlBenchmark::Matrix input(1, 4, 0.5f);
    MlBenchmark::forward(net, input);
    MlBenchmark::Matrix target(1, 2, 0.0f);
    target.at(0, 0) = 1.0f;
    float loss = MlBenchmark::backward(net, target, 0.01f);
    EXPECT_GT(loss, 0.0f);
}

TEST(MlBenchmarkTest, TrainingReducesLoss) {
    std::vector<MlBenchmark::LayerConfig> arch = {
        {4, 8, "relu"},
        {8, 2, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    MlBenchmark::Matrix input(1, 4, 0.5f);
    MlBenchmark::Matrix target(1, 2, 0.0f);
    target.at(0, 0) = 1.0f;

    // First forward+backward
    MlBenchmark::forward(net, input);
    float loss1 = MlBenchmark::backward(net, target, 0.1f);

    // After several iterations, loss should decrease
    float loss_last = loss1;
    for (int i = 0; i < 50; ++i) {
        MlBenchmark::forward(net, input);
        loss_last = MlBenchmark::backward(net, target, 0.1f);
    }

    EXPECT_LT(loss_last, loss1);
}

// === Synthetic Data ===

TEST(MlBenchmarkTest, SyntheticDataShape) {
    auto [inputs, labels] = MlBenchmark::generate_synthetic_data(100, 784, 10);
    EXPECT_EQ(inputs.rows, 100u);
    EXPECT_EQ(inputs.cols, 784u);
    EXPECT_EQ(labels.rows, 100u);
    EXPECT_EQ(labels.cols, 10u);
}

TEST(MlBenchmarkTest, SyntheticDataOneHotLabels) {
    auto [inputs, labels] = MlBenchmark::generate_synthetic_data(20, 784, 10);
    // Each label row should have exactly one 1.0
    for (std::size_t r = 0; r < labels.rows; ++r) {
        float sum = 0.0f;
        for (std::size_t c = 0; c < labels.cols; ++c) {
            sum += labels.at(r, c);
        }
        EXPECT_NEAR(sum, 1.0f, 1e-5f);
    }
}

TEST(MlBenchmarkTest, SyntheticDataNormalized) {
    auto [inputs, labels] = MlBenchmark::generate_synthetic_data(50, 784, 10);
    for (auto& v : inputs.data) {
        EXPECT_GE(v, 0.0f);
        EXPECT_LE(v, 1.0f);
    }
}

// === Inference Benchmark ===

TEST(MlBenchmarkTest, InferenceBenchmarkCompletes) {
    MlBenchmark bench;
    std::vector<MlBenchmark::LayerConfig> arch = {
        {100, 32, "relu"},
        {32, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    auto result = bench.benchmark_inference(net, 100, 100);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.inferences_per_second, 0.0);
}

TEST(MlBenchmarkTest, InferenceLatencyPositive) {
    MlBenchmark bench;
    std::vector<MlBenchmark::LayerConfig> arch = {
        {100, 32, "relu"},
        {32, 10, "none"}
    };
    auto net = MlBenchmark::create_network(arch);
    auto result = bench.benchmark_inference(net, 100, 100);
    EXPECT_GT(result.avg_latency_us, 0.0);
    EXPECT_LE(result.min_latency_us, result.avg_latency_us);
}

// === Training Benchmark ===

TEST(MlBenchmarkTest, TrainingBenchmarkCompletes) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto result = bench.benchmark_training(config);
    EXPECT_TRUE(result.passed);
    EXPECT_GT(result.epochs_per_second, 0.0);
}

TEST(MlBenchmarkTest, TrainingLossHistoryPopulated) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 3, 32};
    auto result = bench.benchmark_training(config);
    EXPECT_EQ(result.loss_history.size(), 3u);
}

TEST(MlBenchmarkTest, TrainingAccuracyValid) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 3, 64};
    auto result = bench.benchmark_training(config);
    EXPECT_GE(result.final_accuracy, 0.0f);
    EXPECT_LE(result.final_accuracy, 1.0f);
}

// === Tensor Operations Benchmark ===

TEST(MlBenchmarkTest, TensorOpsCompletes) {
    MlBenchmark bench;
    auto result = bench.benchmark_tensor_ops(64);
    EXPECT_TRUE(result.passed);
}

TEST(MlBenchmarkTest, TensorOpsMatmulPositive) {
    MlBenchmark bench;
    auto result = bench.benchmark_tensor_ops(64);
    EXPECT_GT(result.matmul_gflops, 0.0);
}

TEST(MlBenchmarkTest, TensorOpsElementwisePositive) {
    MlBenchmark bench;
    auto result = bench.benchmark_tensor_ops(64);
    EXPECT_GT(result.elementwise_gops, 0.0);
}

TEST(MlBenchmarkTest, TensorOpsActivationPositive) {
    MlBenchmark bench;
    auto result = bench.benchmark_tensor_ops(64);
    EXPECT_GT(result.activation_gops, 0.0);
}

TEST(MlBenchmarkTest, TensorOpsConvPositive) {
    MlBenchmark bench;
    auto result = bench.benchmark_tensor_ops(64);
    EXPECT_GT(result.convolution_gflops, 0.0);
}

// === Full Suite ===

TEST(MlBenchmarkTest, FullSuiteCompletes) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    EXPECT_TRUE(results.benchmark_successful);
}

TEST(MlBenchmarkTest, FullSuiteHasDescription) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    EXPECT_FALSE(results.network_description.empty());
    EXPECT_NE(results.network_description.find("784"), std::string::npos);
}

TEST(MlBenchmarkTest, FullSuiteDramSpeedup) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    EXPECT_GT(results.dram_inference_speedup, 0.0);
    EXPECT_GT(results.dram_training_speedup, 0.0);
}

// === Format Results ===

TEST(MlBenchmarkTest, FormatResultsProducesOutput) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    std::string output = MlBenchmark::format_results(results);
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("AI/ML Benchmark"), std::string::npos);
}

TEST(MlBenchmarkTest, FormatResultsContainsInference) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    std::string output = MlBenchmark::format_results(results);
    EXPECT_NE(output.find("Inference"), std::string::npos);
    EXPECT_NE(output.find("inferences/s"), std::string::npos);
}

TEST(MlBenchmarkTest, FormatResultsContainsTraining) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    std::string output = MlBenchmark::format_results(results);
    EXPECT_NE(output.find("Training"), std::string::npos);
    EXPECT_NE(output.find("Accuracy"), std::string::npos);
}

TEST(MlBenchmarkTest, FormatResultsContainsTensorOps) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    std::string output = MlBenchmark::format_results(results);
    EXPECT_NE(output.find("Tensor Operations"), std::string::npos);
    EXPECT_NE(output.find("Conv2D"), std::string::npos);
}

TEST(MlBenchmarkTest, FormatResultsContainsDram) {
    MlBenchmark bench;
    MlBenchmark::TrainingConfig config{0.01f, 32, 2, 32};
    auto results = bench.run(config);
    std::string output = MlBenchmark::format_results(results);
    EXPECT_NE(output.find("DRAM"), std::string::npos);
}
