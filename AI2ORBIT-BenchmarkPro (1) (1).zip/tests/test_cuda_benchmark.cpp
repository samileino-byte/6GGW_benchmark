/**
 * test_cuda_benchmark.cpp - Tests for the CudaBenchmark class
 *
 * Validates GPU compute benchmarking in simulated (CPU fallback) mode:
 * construction, result validity, and output formatting.
 */

#include <gtest/gtest.h>
#include "cuda_benchmark.h"
#include <string>

// === Construction ===

TEST(CudaBenchmarkTest, DefaultConstruction)
{
    CudaBenchmark bench;
    (void)bench;
}

// === Run method ===

TEST(CudaBenchmarkTest, RunReturnsResults)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024); // small problem for fast test
    EXPECT_TRUE(results.benchmark_successful);
}

TEST(CudaBenchmarkTest, SimulatedModeReportsNotAvailable)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    EXPECT_FALSE(results.cuda_available);
}

TEST(CudaBenchmarkTest, ComputeGflopsPositive)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    EXPECT_GT(results.compute_gflops, 0.0);
}

TEST(CudaBenchmarkTest, MemoryBandwidthPositive)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    EXPECT_GT(results.memory_bandwidth_gbps, 0.0);
}

TEST(CudaBenchmarkTest, TransferSpeedPositive)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    EXPECT_GT(results.cpu_to_gpu_transfer_gbps, 0.0);
    EXPECT_GT(results.gpu_to_cpu_transfer_gbps, 0.0);
}

// === Format results ===

TEST(CudaBenchmarkTest, FormatResultsProducesOutput)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    std::string output = CudaBenchmark::format_results(results);
    EXPECT_FALSE(output.empty());
    EXPECT_NE(output.find("CUDA Benchmark"), std::string::npos);
}

TEST(CudaBenchmarkTest, FormatResultsContainsDeviceInfo)
{
    CudaBenchmark bench;
    auto results = bench.run(64 * 1024);
    std::string output = CudaBenchmark::format_results(results);
    EXPECT_NE(output.find("Device:"), std::string::npos);
    EXPECT_NE(output.find("Simulated"), std::string::npos);
}
