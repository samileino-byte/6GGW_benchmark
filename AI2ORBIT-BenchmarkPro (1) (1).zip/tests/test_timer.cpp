#include <gtest/gtest.h>
#include "timer.h"

// Helper: busy-loop to burn a small amount of time without sleeping.
static void busy_wait(volatile int count = 1000000) {
    volatile int x = 0;
    for (int i = 0; i < count; ++i) {
        x += i;
    }
    (void)x;
}

TEST(TimerTest, DefaultConstruction) {
    Timer t;
    // Should be constructible without throwing.
    SUCCEED();
}

TEST(TimerTest, ElapsedSecondsReturnsPositive) {
    Timer t;
    t.start();
    busy_wait();
    double elapsed = t.elapsed_seconds();
    EXPECT_GT(elapsed, 0.0);
}

TEST(TimerTest, ElapsedNanosecondsReturnsPositive) {
    Timer t;
    t.start();
    busy_wait();
    long long elapsed = t.elapsed_nanoseconds();
    EXPECT_GT(elapsed, 0);
}

TEST(TimerTest, MultipleStartCallsResetTimer) {
    Timer t;
    t.start();
    // Do substantial work so first elapsed is meaningful.
    busy_wait(5000000);
    double first_elapsed = t.elapsed_seconds();
    EXPECT_GT(first_elapsed, 0.0);

    // Reset the timer.
    t.start();
    // Immediately measure — should be very small relative to first_elapsed.
    double second_elapsed = t.elapsed_seconds();
    EXPECT_LT(second_elapsed, first_elapsed);
}

TEST(TimerTest, ConsistencyBetweenUnits) {
    Timer t;
    t.start();
    busy_wait(2000000);

    double seconds = t.elapsed_seconds();
    long long nanoseconds = t.elapsed_nanoseconds();

    // These are measured at slightly different times, so allow 50% tolerance.
    double seconds_as_ns = seconds * 1e9;
    double ratio = static_cast<double>(nanoseconds) / seconds_as_ns;
    EXPECT_GT(ratio, 0.5);
    EXPECT_LT(ratio, 1.5);
}
