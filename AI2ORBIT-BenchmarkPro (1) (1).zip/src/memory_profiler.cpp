/**
 * memory_profiler.cpp - Memory profiler implementation
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 *
 * Uses pointer chasing for latency measurement and sequential reads
 * for bandwidth measurement across buffer sizes from 1KB to 64MB.
 */

#include "memory_profiler.h"

#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <numeric>
#include <sstream>
#include <iomanip>
#include <random>
#include <vector>

MemoryProfiler::MemoryProfiler() noexcept = default;

/**
 * Measures random-access latency via pointer chasing.
 *
 * A random permutation of pointer-sized slots creates a cycle where each
 * dereference depends on the previous, preventing hardware prefetching.
 * The buffer is warmed up before the timed section to ensure we measure
 * steady-state latency rather than cold-start effects.
 */
double MemoryProfiler::measure_latency(std::size_t size_bytes, std::size_t accesses) {
    const std::size_t num_slots = size_bytes / sizeof(void*);
    if (num_slots < 2) return 0.0;

    std::vector<void*> buffer(num_slots);

    // Build a random permutation to form a pointer chase loop
    std::vector<std::size_t> indices(num_slots);
    std::iota(indices.begin(), indices.end(), 0);

    // Fixed seed for reproducible results across runs
    std::mt19937 rng(42);
    std::shuffle(indices.begin(), indices.end(), rng);

    // Link each slot to the next in the permutation, forming a Hamiltonian cycle
    for (std::size_t i = 0; i < num_slots; ++i) {
        std::size_t next = indices[(i + 1) % num_slots];
        buffer[indices[i]] = &buffer[next];
    }

    // Warm up: traverse the full cycle once to populate caches
    void** ptr = reinterpret_cast<void**>(buffer[indices[0]]);
    for (std::size_t i = 0; i < num_slots; ++i) {
        ptr = reinterpret_cast<void**>(*ptr);
    }

    // Timed pointer chase
    auto start = std::chrono::high_resolution_clock::now();

    for (std::size_t i = 0; i < accesses; ++i) {
        ptr = reinterpret_cast<void**>(*ptr);
    }

    auto end = std::chrono::high_resolution_clock::now();

    // Prevent compiler from optimizing out the chase
    volatile void* sink = ptr;
    (void)sink;

    double elapsed_ns = std::chrono::duration<double, std::nano>(end - start).count();
    return elapsed_ns / static_cast<double>(accesses);
}

/**
 * Measures sequential read bandwidth by summing 64-bit words across
 * multiple passes. Non-zero buffer fill prevents OS zero-page optimization.
 */
double MemoryProfiler::measure_bandwidth(std::size_t size_bytes, std::size_t iterations) {
    std::vector<uint8_t> buffer(size_bytes);

    // Fill with non-zero data to avoid OS zero-page optimization
    for (std::size_t i = 0; i < size_bytes; ++i) {
        buffer[i] = static_cast<uint8_t>(i & 0xFF);
    }

    volatile uint64_t checksum = 0;

    auto start = std::chrono::high_resolution_clock::now();

    for (std::size_t iter = 0; iter < iterations; ++iter) {
        uint64_t local_sum = 0;
        const uint64_t* data = reinterpret_cast<const uint64_t*>(buffer.data());
        const std::size_t count = size_bytes / sizeof(uint64_t);

        for (std::size_t i = 0; i < count; ++i) {
            local_sum += data[i];
        }
        checksum += local_sum;
    }

    auto end = std::chrono::high_resolution_clock::now();
    (void)checksum;

    double elapsed_sec = std::chrono::duration<double>(end - start).count();
    double total_bytes = static_cast<double>(size_bytes) * static_cast<double>(iterations);
    double bandwidth_mbps = (total_bytes / (1024.0 * 1024.0)) / elapsed_sec;

    return bandwidth_mbps;
}

/**
 * Detects cache level boundaries by scanning for latency jumps > 1.5x
 * between consecutive buffer sizes. Assigns L1/L2/L3/DRAM labels.
 *
 * Typical ARM cache hierarchy for reference:
 *   L1:   32-64KB   (~1-4ns)
 *   L2:   256KB-1MB (~5-15ns)
 *   L3:   2-8MB     (~15-40ns, may not be present)
 *   DRAM: >8MB      (~50-200ns)
 */
void MemoryProfiler::detect_cache_levels(Results& results) {
    results.l1_latency_ns = 0.0;
    results.l2_latency_ns = 0.0;
    results.l3_latency_ns = 0.0;
    results.dram_latency_ns = 0.0;

    if (results.levels.empty()) return;

    double base_latency = results.levels[0].latency_ns;
    if (base_latency <= 0.0) base_latency = 1.0;

    // Compute inter-level latency ratios for jump detection
    std::vector<double> ratios;
    for (std::size_t i = 1; i < results.levels.size(); ++i) {
        double ratio = results.levels[i].latency_ns / results.levels[i - 1].latency_ns;
        ratios.push_back(ratio);
    }

    // Walk through levels: start at L1, bump when ratio > 1.5x
    int current_level = 1;  // 1=L1, 2=L2, 3=L3, 4=DRAM

    for (std::size_t i = 0; i < results.levels.size(); ++i) {
        if (i > 0 && current_level < 4) {
            double ratio = results.levels[i].latency_ns / results.levels[i - 1].latency_ns;
            if (ratio > 1.5) {
                current_level++;
            }
        }

        switch (current_level) {
            case 1:
                results.levels[i].label = "L1";
                results.l1_latency_ns = results.levels[i].latency_ns;
                break;
            case 2:
                results.levels[i].label = "L2";
                results.l2_latency_ns = results.levels[i].latency_ns;
                break;
            case 3:
                results.levels[i].label = "L3";
                results.l3_latency_ns = results.levels[i].latency_ns;
                break;
            case 4:
            default:
                results.levels[i].label = "DRAM";
                results.dram_latency_ns = results.levels[i].latency_ns;
                break;
        }
    }

    // Fallback: if L1 was never explicitly set, use the first entry
    if (results.l1_latency_ns <= 0.0 && !results.levels.empty()) {
        results.l1_latency_ns = results.levels[0].latency_ns;
    }
}

/**
 * Profiles the full memory hierarchy from 1KB to 64MB.
 * For each power-of-2 buffer size, measures latency (pointer chasing)
 * and bandwidth (sequential reads), then detects cache boundaries.
 */
MemoryProfiler::Results MemoryProfiler::profile() {
    Results results;
    results.profiling_successful = false;

    const std::size_t min_size = 1024;             // 1 KB
    const std::size_t max_size = 64 * 1024 * 1024; // 64 MB

    for (std::size_t size = min_size; size <= max_size; size *= 2) {
        CacheLevel level;
        level.size_bytes = size;

        // Scale access count inversely with buffer size for reasonable runtime:
        // smaller buffers are faster so we run more accesses for statistical accuracy.
        std::size_t latency_accesses;
        if (size <= 64 * 1024) {
            latency_accesses = 2000000;  // 2M accesses for <= 64KB
        } else if (size <= 1024 * 1024) {
            latency_accesses = 1000000;  // 1M for <= 1MB
        } else if (size <= 8 * 1024 * 1024) {
            latency_accesses = 500000;   // 500K for <= 8MB
        } else {
            latency_accesses = 200000;   // 200K for > 8MB
        }

        // Scale bandwidth iterations similarly
        std::size_t bw_iterations;
        if (size <= 64 * 1024) {
            bw_iterations = 2000;
        } else if (size <= 1024 * 1024) {
            bw_iterations = 200;
        } else if (size <= 8 * 1024 * 1024) {
            bw_iterations = 20;
        } else {
            bw_iterations = 5;
        }

        level.latency_ns = measure_latency(size, latency_accesses);
        level.bandwidth_mbps = measure_bandwidth(size, bw_iterations);
        level.label = "?";  // Placeholder; assigned by detect_cache_levels()

        results.levels.push_back(level);
    }

    detect_cache_levels(results);

    results.profiling_successful = true;
    return results;
}

/**
 * Formats profiling results as a multi-line string with a summary
 * of detected cache latencies and a per-level detail table.
 */
std::string MemoryProfiler::format_results(const Results& results) {
    std::ostringstream oss;
    oss << std::fixed;

    oss << "\n===== Memory Hierarchy Profiler =====\n";
    oss << "Status: " << (results.profiling_successful ? "PASSED" : "FAILED") << "\n";
    oss << "-------------------------------------\n";

    // Summary of detected cache latencies
    oss << std::setprecision(2);
    oss << "L1  Latency:  " << results.l1_latency_ns << " ns\n";
    oss << "L2  Latency:  " << results.l2_latency_ns << " ns\n";
    oss << "L3  Latency:  " << results.l3_latency_ns << " ns\n";
    oss << "DRAM Latency: " << results.dram_latency_ns << " ns\n";
    oss << "-------------------------------------\n";

    // Per-level detail table
    oss << std::setw(10) << "Size"
        << std::setw(8)  << "Level"
        << std::setw(14) << "Latency(ns)"
        << std::setw(16) << "BW(MB/s)" << "\n";
    oss << std::string(48, '-') << "\n";

    for (const auto& level : results.levels) {
        std::string size_str;
        if (level.size_bytes >= 1024 * 1024) {
            std::ostringstream ss;
            ss << (level.size_bytes / (1024 * 1024)) << " MB";
            size_str = ss.str();
        } else {
            std::ostringstream ss;
            ss << (level.size_bytes / 1024) << " KB";
            size_str = ss.str();
        }

        oss << std::setw(10) << size_str
            << std::setw(8)  << level.label
            << std::setw(14) << std::setprecision(2) << level.latency_ns
            << std::setw(16) << std::setprecision(1) << level.bandwidth_mbps
            << "\n";
    }

    oss << "=====================================\n";
    return oss.str();
}
