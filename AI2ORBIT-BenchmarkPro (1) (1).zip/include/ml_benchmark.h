/**
 * ml_benchmark.h - AI/ML Neural Network Benchmark
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 *
 * Pure C++ neural network implementation for benchmarking AI workloads.
 * No external ML framework dependencies (no PyTorch/TensorFlow required).
 *
 * Implements:
 *   - Dense (fully-connected) neural network layers
 *   - Activation functions: Sigmoid, ReLU, Softmax
 *   - Loss functions: MSE, Cross-Entropy
 *   - Forward pass and backpropagation
 *   - Mini-batch SGD optimizer
 *   - MNIST-style digit recognition (28x28 -> 10 classes)
 *   - CNN-style convolution operations (2D)
 *   - Tensor operations benchmark
 *   - Training speed and inference speed measurement
 *   - Standard vs DRAM-optimized comparison
 *
 * Based on ML course material (Chapters 4 & 6):
 *   - Chapter 4: Neural networks, backpropagation, MNIST
 *   - Chapter 6: PyTorch concepts, ReLU, CNN, softmax
 */

#ifndef ML_BENCHMARK_H
#define ML_BENCHMARK_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

/**
 * MlBenchmark - AI/ML workload benchmark suite.
 *
 * Implements neural network operations in pure C++ and measures
 * inference/training performance. Uses synthetic MNIST-like data
 * for reproducible benchmarking without requiring dataset files.
 */
class MlBenchmark {
public:
    /** A 2D matrix stored as a flat vector (row-major). */
    struct Matrix {
        std::vector<float> data;    ///< Flat storage
        std::size_t rows;           ///< Number of rows
        std::size_t cols;           ///< Number of columns

        Matrix() : rows(0), cols(0) {}
        Matrix(std::size_t r, std::size_t c);
        Matrix(std::size_t r, std::size_t c, float fill_val);

        float& at(std::size_t r, std::size_t c);
        float at(std::size_t r, std::size_t c) const;
    };

    /** Neural network layer configuration. */
    struct LayerConfig {
        std::size_t input_size;     ///< Number of inputs
        std::size_t output_size;    ///< Number of outputs (neurons)
        std::string activation;     ///< "sigmoid", "relu", or "none"
    };

    /** A single dense layer with weights, biases, and activation. */
    struct DenseLayer {
        Matrix weights;             ///< Weight matrix [input x output]
        std::vector<float> biases;  ///< Bias vector [output]
        std::string activation;     ///< Activation function name
        Matrix last_input;          ///< Cached input for backprop
        Matrix last_output;         ///< Cached output for backprop
        Matrix last_pre_activation; ///< Pre-activation values
    };

    /** Neural network model. */
    struct NeuralNetwork {
        std::vector<DenseLayer> layers;         ///< Network layers
        std::vector<LayerConfig> architecture;  ///< Layer configs
        std::size_t total_parameters;           ///< Total trainable params
    };

    /** Training hyperparameters. */
    struct TrainingConfig {
        float learning_rate;        ///< SGD learning rate (default 0.01)
        std::size_t batch_size;     ///< Mini-batch size (default 32)
        std::size_t epochs;         ///< Number of training epochs (default 5)
        std::size_t hidden_neurons; ///< Hidden layer neurons (default 128)
    };

    /** Result of inference benchmark. */
    struct InferenceResult {
        double inferences_per_second;   ///< Forward passes per second
        double avg_latency_us;          ///< Average inference latency in us
        double min_latency_us;          ///< Minimum inference latency
        double max_latency_us;          ///< Maximum inference latency
        std::size_t total_inferences;   ///< Number of inferences performed
        double total_time_seconds;      ///< Total benchmark time
        bool passed;                    ///< True if completed successfully
    };

    /** Result of training benchmark. */
    struct TrainingResult {
        double epochs_per_second;       ///< Training epochs per second
        double samples_per_second;      ///< Training samples per second
        std::vector<float> loss_history; ///< Loss at end of each epoch
        float final_accuracy;           ///< Final accuracy on test data (0-1)
        double total_time_seconds;      ///< Total training time
        std::size_t total_parameters;   ///< Network parameter count
        bool passed;                    ///< True if completed successfully
    };

    /** Result of tensor operations benchmark. */
    struct TensorOpsResult {
        double matmul_gflops;           ///< Matrix multiply throughput
        double elementwise_gops;        ///< Element-wise ops throughput
        double activation_gops;         ///< Activation function throughput
        double softmax_gops;            ///< Softmax throughput
        double convolution_gflops;      ///< 2D convolution throughput
        double total_time_seconds;      ///< Total benchmark time
        bool passed;                    ///< True if completed successfully
    };

    /** Complete ML benchmark results. */
    struct Results {
        InferenceResult inference;          ///< Inference speed results
        TrainingResult training;            ///< Training speed results
        TensorOpsResult tensor_ops;         ///< Tensor operation results
        double dram_inference_speedup;      ///< DRAM-optimized inference speedup
        double dram_training_speedup;       ///< DRAM-optimized training speedup
        std::string network_description;    ///< Network architecture string
        double total_time_seconds;          ///< Total benchmark time
        bool benchmark_successful;          ///< True if all tests passed
    };

    MlBenchmark() noexcept;

    /**
     * Runs the full ML benchmark suite.
     * @param config Training hyperparameters.
     * @return Results with inference, training, and tensor op metrics.
     */
    Results run(const TrainingConfig& config = {0.01f, 32, 5, 128});

    /**
     * Benchmarks neural network inference speed.
     * @param net The neural network to benchmark.
     * @param input_size Input vector size.
     * @param num_inferences Number of forward passes to run.
     * @return InferenceResult with throughput metrics.
     */
    InferenceResult benchmark_inference(NeuralNetwork& net,
                                         std::size_t input_size,
                                         std::size_t num_inferences = 10000);

    /**
     * Benchmarks neural network training speed.
     * @param config Training hyperparameters.
     * @return TrainingResult with epoch speed and loss history.
     */
    TrainingResult benchmark_training(const TrainingConfig& config);

    /**
     * Benchmarks raw tensor operations.
     * @param size Matrix/vector dimension for tests.
     * @return TensorOpsResult with throughput for each operation.
     */
    TensorOpsResult benchmark_tensor_ops(std::size_t size = 512);

    /**
     * Creates a neural network with the given architecture.
     * @param layers Vector of layer configurations.
     * @return Initialized NeuralNetwork with random weights.
     */
    static NeuralNetwork create_network(const std::vector<LayerConfig>& layers);

    /**
     * Runs forward pass through the network.
     * @param net The neural network.
     * @param input Input matrix [batch_size x input_features].
     * @return Output matrix [batch_size x output_classes].
     */
    static Matrix forward(NeuralNetwork& net, const Matrix& input);

    /**
     * Runs backpropagation and updates weights.
     * @param net The neural network to update.
     * @param target Target output matrix.
     * @param learning_rate SGD learning rate.
     * @return Loss value for this batch.
     */
    static float backward(NeuralNetwork& net, const Matrix& target,
                           float learning_rate);

    /**
     * Generates synthetic MNIST-like training data.
     * @param num_samples Number of samples to generate.
     * @param input_size Input dimension (784 for 28x28).
     * @param num_classes Number of output classes (10 for digits).
     * @return Pair of (inputs, one-hot labels) matrices.
     */
    static std::pair<Matrix, Matrix> generate_synthetic_data(
        std::size_t num_samples, std::size_t input_size = 784,
        std::size_t num_classes = 10);

    /**
     * Computes 2D convolution (single channel).
     * @param input Input matrix [H x W].
     * @param kernel Convolution kernel [KH x KW].
     * @return Output matrix [(H-KH+1) x (W-KW+1)].
     */
    static Matrix conv2d(const Matrix& input, const Matrix& kernel);

    /**
     * Formats full benchmark results as a report.
     * @param results The Results struct to format.
     * @return Multi-line formatted string.
     */
    static std::string format_results(const Results& results);

    // === Activation functions (public for testing) ===

    /** Sigmoid: 1 / (1 + exp(-x)) */
    static float sigmoid(float x);

    /** ReLU: max(0, x) */
    static float relu(float x);

    /** Applies activation function in-place to a matrix. */
    static void apply_activation(Matrix& m, const std::string& activation);

    /** Applies softmax to each row of the matrix. */
    static void apply_softmax(Matrix& m);

    /** Cross-entropy loss between predictions and targets. */
    static float cross_entropy_loss(const Matrix& predictions,
                                     const Matrix& targets);

    /** Mean squared error loss. */
    static float mse_loss(const Matrix& predictions, const Matrix& targets);

    // === Matrix operations ===

    /** Matrix multiply: C = A * B */
    static Matrix matmul(const Matrix& a, const Matrix& b);

    /** Matrix transpose */
    static Matrix transpose(const Matrix& m);

    /** Element-wise multiply */
    static Matrix hadamard(const Matrix& a, const Matrix& b);

private:
    /** Measures DRAM-optimized inference speedup. */
    double measure_dram_inference_speedup(NeuralNetwork& net,
                                           std::size_t input_size);

    /** Measures DRAM-optimized training speedup. */
    double measure_dram_training_speedup(const TrainingConfig& config);

    /** Simple pseudo-random number generator (deterministic). */
    static float rand_float(uint32_t& seed);
};

#endif // ML_BENCHMARK_H
