/**
 * eula.h - AI2ORBIT EULA Approval and Copyright Notice
 *
 * Copyright (c) AI-2-Orbit Co. 2026. All rights reserved.
 *
 * This header provides EULA display and acceptance functionality
 * for all AI2ORBIT products across all platforms:
 * Phone, Pad, Desktop, Laptop, Server, Embedded, IoT, Legacy Wrapped Systems.
 */

#ifndef AI2ORBIT_EULA_H
#define AI2ORBIT_EULA_H

#include <fstream>
#include <iostream>
#include <string>

namespace ai2orbit {

static const char* COPYRIGHT_NOTICE =
    "Copyright (c) AI-2-Orbit Co. 2026. All rights reserved.";

static const char* EULA_TEXT = R"(
================================================================================
  END USER LICENSE AGREEMENT
  Copyright (c) AI-2-Orbit Co. 2026. All rights reserved.
================================================================================

IMPORTANT - READ CAREFULLY: This End User License Agreement ("EULA") is a legal
agreement between you ("User") and AI-2-Orbit Co. ("Company"), a company
registered in Turku, Finland, for the use of AI2ORBIT software and all
associated products ("Software").

By installing, copying, or using the Software, you agree to be bound by the
terms of this EULA. If you do not agree, do not install or use the Software.

1. LICENSE GRANT
   The Company grants you a limited, non-exclusive, non-transferable, revocable
   license to install and use the Software on devices you own or control, solely
   for personal or internal business purposes.

2. RESTRICTIONS
   You may not:
   (a) Copy, modify, distribute, sell, or lease any part of the Software
   (b) Reverse engineer, decompile, or disassemble the Software
   (c) Remove or alter any proprietary notices, labels, or marks
   (d) Use the Software for any unlawful purpose
   (e) Sublicense or transfer the Software without written consent

3. INTELLECTUAL PROPERTY
   The Software, including all code, algorithms, designs, documentation, and
   trademarks, is the exclusive property of AI-2-Orbit Co. and is protected by
   international copyright, patent, and trade secret laws.

4. DATA COLLECTION
   The Software may collect device performance metrics for benchmarking purposes.
   No personal data is collected, stored, or transmitted without explicit consent.

5. WARRANTY DISCLAIMER
   THE SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   IMPLIED. THE COMPANY DOES NOT WARRANT THAT THE SOFTWARE WILL BE UNINTERRUPTED
   OR ERROR-FREE.

6. LIMITATION OF LIABILITY
   IN NO EVENT SHALL AI-2-ORBIT CO. BE LIABLE FOR ANY INDIRECT, INCIDENTAL,
   SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING FROM USE OF THE SOFTWARE.

7. TERMINATION
   This license is effective until terminated. It terminates automatically if you
   fail to comply with any term. Upon termination, you must destroy all copies.

8. GOVERNING LAW
   This EULA is governed by the laws of Finland. Any disputes shall be resolved
   in the courts of Turku, Finland.

9. CONTACT
   AI-2-Orbit Co., Turku, Finland
   info@ai-2-orbit.com

================================================================================
  Copyright (c) AI-2-Orbit Co. 2026. All rights reserved.
================================================================================
)";

/**
 * Returns the path to the EULA acceptance marker file.
 * Uses the user's home directory on all platforms.
 */
inline std::string eula_marker_path() {
#ifdef _WIN32
    const char* home = std::getenv("USERPROFILE");
#else
    const char* home = std::getenv("HOME");
#endif
    if (!home) home = ".";
    return std::string(home) + "/.ai2orbit_eula_accepted";
}

/**
 * Checks if the EULA has already been accepted.
 */
inline bool eula_accepted() {
    std::ifstream f(eula_marker_path());
    return f.good();
}

/**
 * Marks the EULA as accepted by creating the marker file.
 */
inline void mark_eula_accepted() {
    std::ofstream f(eula_marker_path());
    f << "EULA accepted" << std::endl;
}

/**
 * Displays the EULA and prompts the user for acceptance.
 * Returns true if accepted, false if declined.
 * If --accept-eula flag was passed, accepts automatically.
 * If EULA was previously accepted, skips the prompt.
 */
inline bool check_eula(int argc = 0, char** argv = nullptr) {
    // Check for --accept-eula flag
    for (int i = 1; i < argc; i++) {
        if (std::string(argv[i]) == "--accept-eula") {
            mark_eula_accepted();
            return true;
        }
    }

    // Check if already accepted
    if (eula_accepted()) {
        return true;
    }

    // Display EULA
    std::cout << EULA_TEXT << std::endl;
    std::cout << "Do you accept the terms of this EULA? (yes/no): ";
    std::cout.flush();

    std::string response;
    std::getline(std::cin, response);

    if (response == "yes" || response == "YES" || response == "y" || response == "Y") {
        mark_eula_accepted();
        std::cout << "\nEULA accepted. Thank you.\n" << std::endl;
        return true;
    } else {
        std::cout << "\nEULA declined. You must accept the EULA to use this software.\n";
        return false;
    }
}

/**
 * Prints the copyright footer. Call at end of program output.
 */
inline void print_copyright() {
    std::cout << "\n" << COPYRIGHT_NOTICE << "\n";
}

} // namespace ai2orbit

#endif // AI2ORBIT_EULA_H
