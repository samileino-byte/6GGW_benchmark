/**
 * memory_profiler.h - Cache hierarchy profiler using pointer chasing
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 */

#ifndef MEMORY_PROFILER_H
#define MEMORY_PROFILER_H

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

/**
 * MemoryProfiler - Cache hierarchy profiler using pointer chasing
 * and sequential bandwidth measurement.
 *
 * Allocates buffers from 1KB to 64MB in powers of 2, performs
 * random-access reads (pointer chasing) to measure latency at each
 * size, and sequential reads to measure bandwidth. Detects cache
 * boundaries by looking for latency jumps between levels.
 */
class MemoryProfiler {
public:
    /** Measured performance data for a single buffer size (cache level). */
    struct CacheLevel {
        std::size_t size_bytes;    ///< Buffer size tested
        double latency_ns;         ///< Average random-access latency in nanoseconds
        double bandwidth_mbps;     ///< Sequential read bandwidth in MB/s
        std::string label;         ///< Detected level label ("L1", "L2", "L3", or "DRAM")
    };

    /** Aggregated profiling results across all tested buffer sizes. */
    struct Results {
        std::vector<CacheLevel> levels;  ///< Per-size measurements, ordered by buffer size
        double l1_latency_ns;            ///< Representative L1 cache latency
        double l2_latency_ns;            ///< Representative L2 cache latency
        double l3_latency_ns;            ///< Representative L3 cache latency
        double dram_latency_ns;          ///< Representative main memory latency
        bool profiling_successful;       ///< True if profiling completed without error
    };

    MemoryProfiler() noexcept;

    /**
     * Profiles the memory hierarchy from 1KB to 64MB.
     * Uses pointer chasing for latency and sequential reads for bandwidth.
     * Detects cache level boundaries automatically.
     * @return Results with per-level latency/bandwidth and detected cache boundaries.
     */
    Results profile();

    /**
     * Formats profiling results as a human-readable string.
     * Suitable for console output or JNI bridge transfer.
     * @param results The Results struct to format.
     * @return Formatted multi-line string.
     */
    static std::string format_results(const Results& results);

private:
    /**
     * Measures random-access latency for a given buffer size
     * using pointer chasing (each element points to a random next element).
     * @param size_bytes Buffer size to test.
     * @param accesses   Number of pointer chase steps to perform.
     * @return Average latency in nanoseconds per access.
     */
    double measure_latency(std::size_t size_bytes, std::size_t accesses);

    /**
     * Measures sequential read bandwidth for a given buffer size.
     * @param size_bytes  Buffer size to test.
     * @param iterations  Number of full passes over the buffer.
     * @return Bandwidth in MB/s.
     */
    double measure_bandwidth(std::size_t size_bytes, std::size_t iterations);

    /**
     * Detects cache level labels based on latency jumps between
     * consecutive buffer sizes. A ratio > 1.5x triggers a level bump.
     * Populates l1/l2/l3/dram latency fields in Results.
     * @param results [in,out] Results with levels populated; labels and
     *                latency summary fields are written.
     */
    void detect_cache_levels(Results& results);
};

#endif // MEMORY_PROFILER_H
