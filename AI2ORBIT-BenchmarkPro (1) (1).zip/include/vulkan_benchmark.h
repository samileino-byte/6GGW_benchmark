/**
 * vulkan_benchmark.h - Vulkan GPU graphics benchmark
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 */

#ifndef VULKAN_BENCHMARK_H
#define VULKAN_BENCHMARK_H

#include <cstddef>
#include <string>

/**
 * VulkanBenchmark - Graphics/compute pipeline benchmark with CPU fallback.
 *
 * When Vulkan is available, runs real GPU pipeline benchmarks.
 * Otherwise, simulates GPU-like operations on CPU: fill rate,
 * shader ops, draw call overhead, and texture bandwidth, then
 * applies empirical GPU scaling factors.
 */
class VulkanBenchmark {
public:
    /** Results of a Vulkan benchmark run. */
    struct Results {
        double fill_rate_mpixels_sec;       ///< Triangle fill rate in megapixels/sec
        double shader_ops_per_second;       ///< Compute shader throughput in ops/sec
        double draw_calls_per_second;       ///< Draw call overhead in calls/sec
        double texture_bandwidth_gbps;      ///< Texture sampling bandwidth in GB/s
        double total_time_seconds;          ///< Wall-clock time for the entire benchmark
        bool vulkan_available;              ///< True if real Vulkan runtime was detected
        bool benchmark_successful;          ///< True if the benchmark completed
        std::string device_name;            ///< GPU device name or "Simulated" for fallback
        std::string api_version;            ///< Vulkan API version string
    };

    VulkanBenchmark() noexcept;

    /**
     * Runs the Vulkan benchmark (real or simulated fallback).
     * @param iterations Number of iterations per sub-benchmark (default 1000).
     * @return Results struct with GPU pipeline throughput metrics.
     */
    Results run(std::size_t iterations = 1000);

    /**
     * Formats benchmark results as a human-readable string.
     * @param results The Results struct to format.
     * @return Formatted multi-line string.
     */
    static std::string format_results(const Results& results);

private:
    /**
     * Checks whether a Vulkan-capable device is available.
     * @return True if Vulkan runtime is accessible and a device is found.
     */
    bool detect_vulkan() noexcept;

    /**
     * Runs the CPU-simulated fallback with GPU scaling factors.
     * @param iterations Number of iterations per sub-benchmark.
     * @return Results with estimated GPU-equivalent throughput.
     */
    Results run_simulated(std::size_t iterations);
};

#endif // VULKAN_BENCHMARK_H
