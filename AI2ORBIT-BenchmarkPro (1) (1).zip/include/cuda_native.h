/**
 * cuda_native.h - Native CUDA-C GPU compute benchmark
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 *
 * Provides real CUDA kernel benchmarks when compiled with nvcc and
 * a CUDA-capable GPU is present. Falls back to optimized CPU simulation
 * using SIMD-style batched operations when no CUDA device is detected.
 *
 * Kernels tested:
 *   - SGEMM (single-precision matrix multiply)
 *   - Reduction (parallel sum)
 *   - Stencil (2D 5-point stencil, memory-bound)
 *   - Device memory bandwidth (global, shared, constant)
 *   - PCIe transfer (host-to-device, device-to-host, bidirectional)
 *   - Atomic operations throughput
 */

#ifndef CUDA_NATIVE_H
#define CUDA_NATIVE_H

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

/**
 * CudaNative - Native CUDA-C benchmark suite with CPU fallback.
 *
 * When CUDA hardware is available and the binary was compiled with nvcc,
 * executes real GPU kernels. Otherwise, runs CPU-emulated equivalents
 * with realistic GPU scaling factors derived from published NVIDIA specs.
 */
class CudaNative {
public:
    /** Individual kernel benchmark result. */
    struct KernelResult {
        std::string kernel_name;        ///< Name of the kernel/test
        double elapsed_ms;              ///< Wall-clock time in milliseconds
        double throughput;              ///< Throughput metric (GFLOPS, GB/s, or ops/s)
        std::string throughput_unit;    ///< Unit string ("GFLOPS", "GB/s", "Gops/s")
        bool passed;                    ///< True if the kernel completed correctly
    };

    /** Memory tier results for DRAM-aware GPU allocation. */
    struct MemoryTierResult {
        std::string tier_name;          ///< "Registers", "Shared", "L1", "L2", "Global", "Host"
        double bandwidth_gbps;          ///< Measured or estimated bandwidth in GB/s
        double latency_ns;              ///< Measured or estimated latency in nanoseconds
        std::size_t capacity_bytes;     ///< Capacity of this memory tier
    };

    /** Complete CUDA-C benchmark results. */
    struct Results {
        /// Device information
        bool cuda_available;                    ///< True if real CUDA hardware was used
        std::string device_name;                ///< GPU name or "CPU Emulation"
        int compute_capability_major;           ///< SM major version (0 if emulated)
        int compute_capability_minor;           ///< SM minor version
        int sm_count;                           ///< Number of streaming multiprocessors
        int cuda_cores;                         ///< Estimated CUDA core count
        std::size_t device_memory_bytes;        ///< Total GPU memory in bytes
        int memory_bus_width_bits;              ///< Memory bus width
        double memory_clock_mhz;                ///< Memory clock speed

        /// Kernel results
        std::vector<KernelResult> kernel_results;  ///< Per-kernel benchmark data

        /// Memory hierarchy
        std::vector<MemoryTierResult> memory_tiers; ///< GPU memory tier measurements

        /// Aggregate scores
        double peak_compute_gflops;             ///< Peak compute throughput
        double peak_memory_bandwidth_gbps;      ///< Peak memory bandwidth
        double pcie_host_to_device_gbps;        ///< PCIe H2D transfer rate
        double pcie_device_to_host_gbps;        ///< PCIe D2H transfer rate
        double pcie_bidirectional_gbps;         ///< PCIe bidirectional rate
        double total_time_seconds;              ///< Total benchmark duration

        /// DRAM Mapper integration
        double dram_optimized_speedup;          ///< Speedup with DRAM-prioritized allocation
        bool benchmark_successful;              ///< True if all kernels completed
    };

    CudaNative() noexcept;

    /**
     * Runs the full CUDA-C benchmark suite.
     * @param matrix_dim  Dimension for SGEMM (NxN matrix, default 1024).
     * @param vector_size Number of elements for reduction/bandwidth (default 16M).
     * @return Results struct with all kernel and device metrics.
     */
    Results run(std::size_t matrix_dim = 1024, std::size_t vector_size = 16 * 1024 * 1024);

    /**
     * Runs only the SGEMM benchmark.
     * @param dim Matrix dimension (NxN).
     * @return KernelResult with GFLOPS throughput.
     */
    KernelResult run_sgemm(std::size_t dim);

    /**
     * Runs the parallel reduction benchmark.
     * @param n Number of elements to reduce.
     * @return KernelResult with GB/s throughput.
     */
    KernelResult run_reduction(std::size_t n);

    /**
     * Runs the 2D stencil benchmark (memory-bound workload).
     * @param width  Grid width.
     * @param height Grid height.
     * @return KernelResult with GB/s effective bandwidth.
     */
    KernelResult run_stencil(std::size_t width, std::size_t height);

    /**
     * Measures device memory bandwidth across tiers.
     * @param buffer_size Size in bytes for bandwidth tests.
     * @return Vector of MemoryTierResult for each memory level.
     */
    std::vector<MemoryTierResult> measure_memory_hierarchy(std::size_t buffer_size);

    /**
     * Measures PCIe transfer rates (H2D, D2H, bidirectional).
     * @param transfer_size Size in bytes to transfer.
     * @return KernelResult with GB/s throughput.
     */
    KernelResult run_pcie_transfer(std::size_t transfer_size);

    /**
     * Runs atomic operations throughput benchmark.
     * @param n Number of atomic operations.
     * @return KernelResult with Gops/s throughput.
     */
    KernelResult run_atomics(std::size_t n);

    /**
     * Measures speedup from DRAM-prioritized allocation vs standard.
     * @param problem_size Size of the workload.
     * @return Speedup ratio (e.g., 4.2 means 4.2x faster).
     */
    double measure_dram_speedup(std::size_t problem_size);

    /**
     * Formats full results as a human-readable report.
     * @param results The Results struct to format.
     * @return Multi-line formatted string.
     */
    static std::string format_results(const Results& results);

    /**
     * Checks if CUDA hardware is available.
     * @return True if CUDA runtime is accessible.
     */
    bool is_cuda_available() const noexcept;

private:
    bool cuda_detected_;    ///< Cached CUDA detection result

    /** Attempts to detect CUDA runtime and query device properties. */
    void detect_cuda() noexcept;

    /** CPU-emulated SGEMM with cache-optimized blocking. */
    KernelResult emulate_sgemm(std::size_t dim);

    /** CPU-emulated parallel reduction. */
    KernelResult emulate_reduction(std::size_t n);

    /** CPU-emulated 2D stencil. */
    KernelResult emulate_stencil(std::size_t width, std::size_t height);

    /** CPU-emulated memory hierarchy measurement. */
    std::vector<MemoryTierResult> emulate_memory_hierarchy(std::size_t buffer_size);

    /** CPU-emulated PCIe transfer. */
    KernelResult emulate_pcie_transfer(std::size_t transfer_size);

    /** CPU-emulated atomic throughput. */
    KernelResult emulate_atomics(std::size_t n);
};

#endif // CUDA_NATIVE_H
