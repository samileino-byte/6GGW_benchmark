/**
 * AI2ORBITBoot.swift - Swift wrapper for AI2ORBIT Bootloader
 *
 * Usage in your ViewController:
 *   let boot = AI2ORBITBoot()
 *   let lines = boot.run(isTablet: UIDevice.current.userInterfaceIdiom == .pad)
 *   bootLabel.text = lines.joined()
 *
 * Copyright (c) AI2ORBIT Co. 2026
 */

import Foundation

public class AI2ORBITBoot {

    public init() {}

    public func run(isTablet: Bool = false) -> [String] {
        var lines: [String] = []

        let bootRef = ai2orbit_boot_create()
        if isTablet {
            ai2orbit_boot_set_tablet(bootRef)
        }

        ai2orbit_boot_set_output_callback(bootRef) { cStr in
            if let cStr = cStr {
                lines.append(String(cString: cStr))
            }
        }

        ai2orbit_boot_run(bootRef)
        ai2orbit_boot_destroy(bootRef)

        return lines
    }

    public func version() -> String {
        return String(cString: ai2orbit_boot_version())
    }
}
