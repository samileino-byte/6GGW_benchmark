/**
 * ai2orbit_boot_c.h - C interface for AI2ORBIT Bootloader (iOS/Swift bridge)
 *
 * Pure C API so Swift can call without C++ bridging header complexity.
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#ifndef AI2ORBIT_BOOT_C_H
#define AI2ORBIT_BOOT_C_H

#ifdef __cplusplus
extern "C" {
#endif

typedef void* AI2ORBITBootRef;
typedef void (*AI2ORBITOutputCallback)(const char* line);

AI2ORBITBootRef ai2orbit_boot_create(void);
void ai2orbit_boot_destroy(AI2ORBITBootRef ref);

void ai2orbit_boot_set_tablet(AI2ORBITBootRef ref);
void ai2orbit_boot_set_output_callback(AI2ORBITBootRef ref, AI2ORBITOutputCallback cb);

int ai2orbit_boot_run(AI2ORBITBootRef ref);
const char* ai2orbit_boot_version(void);

#ifdef __cplusplus
}
#endif

#endif
