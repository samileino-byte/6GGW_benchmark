/**
 * ai2orbit_boot_c.cpp - C interface implementation for iOS/Swift bridge
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "ai2orbit_boot_c.h"
#include "ai2orbit_boot.h"

struct AI2ORBITBootImpl {
    ai2orbit::Bootloader bootloader;
    AI2ORBITOutputCallback output_cb;
};

extern "C" {

AI2ORBITBootRef ai2orbit_boot_create(void) {
    auto* impl = new AI2ORBITBootImpl();
    impl->output_cb = nullptr;
    impl->bootloader.set_platform(ai2orbit::BootPlatform::IOS);
    impl->bootloader.set_form_factor(ai2orbit::BootFormFactor::PHONE);
    return static_cast<AI2ORBITBootRef>(impl);
}

void ai2orbit_boot_destroy(AI2ORBITBootRef ref) {
    auto* impl = static_cast<AI2ORBITBootImpl*>(ref);
    delete impl;
}

void ai2orbit_boot_set_tablet(AI2ORBITBootRef ref) {
    auto* impl = static_cast<AI2ORBITBootImpl*>(ref);
    impl->bootloader.set_form_factor(ai2orbit::BootFormFactor::TABLET);
}

void ai2orbit_boot_set_output_callback(AI2ORBITBootRef ref, AI2ORBITOutputCallback cb) {
    auto* impl = static_cast<AI2ORBITBootImpl*>(ref);
    impl->output_cb = cb;
    impl->bootloader.set_output_callback([cb](const std::string& line) {
        if (cb) cb(line.c_str());
    });
}

int ai2orbit_boot_run(AI2ORBITBootRef ref) {
    auto* impl = static_cast<AI2ORBITBootImpl*>(ref);
    auto result = impl->bootloader.run();
    return result.ready ? 0 : 1;
}

const char* ai2orbit_boot_version(void) {
    return ai2orbit::Bootloader::version();
}

}
