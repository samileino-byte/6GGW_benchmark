LOCAL_PATH := $(call my-dir)

# Static library (link into your own JNI code)
include $(CLEAR_VARS)

LOCAL_MODULE    := ai2orbit_boot_static
LOCAL_SRC_FILES := ai2orbit_boot.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_CPPFLAGS  := -std=c++17 -Wall -Wextra -O2
LOCAL_LDLIBS    := -llog

include $(BUILD_STATIC_LIBRARY)

# Shared library with JNI bridge (drop-in for Kotlin/Java)
include $(CLEAR_VARS)

LOCAL_MODULE    := ai2orbit_boot
LOCAL_SRC_FILES := ai2orbit_boot.cpp ai2orbit_boot_jni.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_CPPFLAGS  := -std=c++17 -Wall -Wextra -O2
LOCAL_LDLIBS    := -llog

include $(BUILD_SHARED_LIBRARY)
