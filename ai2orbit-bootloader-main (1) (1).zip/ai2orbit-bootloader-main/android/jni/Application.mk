APP_ABI := arm64-v8a armeabi-v7a x86_64 x86
APP_PLATFORM := android-24
APP_STL := c++_static
APP_CPPFLAGS := -std=c++17 -fexceptions
