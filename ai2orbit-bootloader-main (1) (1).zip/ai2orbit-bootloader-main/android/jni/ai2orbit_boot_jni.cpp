/**
 * ai2orbit_boot_jni.cpp - JNI Bridge for AI2ORBIT Bootloader
 *
 * Exposes bootloader to Kotlin/Java via JNI.
 * Call AI2ORBITBoot.run() from your Activity to start boot sequence.
 * Set an output listener to receive text lines for rendering.
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "ai2orbit_boot.h"
#include <jni.h>
#include <string>

static ai2orbit::Bootloader* g_bootloader = nullptr;

extern "C" {

JNIEXPORT void JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeInit(JNIEnv* env, jobject thiz) {
    if (g_bootloader) delete g_bootloader;
    g_bootloader = new ai2orbit::Bootloader();
    g_bootloader->set_form_factor(ai2orbit::BootFormFactor::PHONE);
}

JNIEXPORT void JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeInitTablet(JNIEnv* env, jobject thiz) {
    if (g_bootloader) delete g_bootloader;
    g_bootloader = new ai2orbit::Bootloader();
    g_bootloader->set_form_factor(ai2orbit::BootFormFactor::TABLET);
}

JNIEXPORT jobjectArray JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeRun(JNIEnv* env, jobject thiz) {
    if (!g_bootloader) return nullptr;

    std::vector<std::string> lines;

    g_bootloader->set_output_callback([&lines](const std::string& line) {
        lines.push_back(line);
    });

    ai2orbit::BootResult result = g_bootloader->run(
        [&lines](const std::string& stage, double progress) {
            // progress callback - app can use for UI updates
        }
    );

    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray(
        static_cast<jsize>(lines.size()), stringClass, nullptr);

    for (size_t i = 0; i < lines.size(); ++i) {
        jstring js = env->NewStringUTF(lines[i].c_str());
        env->SetObjectArrayElement(arr, static_cast<jsize>(i), js);
        env->DeleteLocalRef(js);
    }

    return arr;
}

JNIEXPORT jdouble JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeGetTimingPs(JNIEnv* env, jobject thiz) {
    if (!g_bootloader) return 0.0;
    ai2orbit::BootResult result = g_bootloader->run();
    return result.selected_timing_ps;
}

JNIEXPORT jstring JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeVersion(JNIEnv* env, jobject thiz) {
    return env->NewStringUTF(ai2orbit::Bootloader::version());
}

JNIEXPORT void JNICALL
Java_com_ai2orbit_boot_AI2ORBITBoot_nativeDestroy(JNIEnv* env, jobject thiz) {
    if (g_bootloader) {
        delete g_bootloader;
        g_bootloader = nullptr;
    }
}

}
