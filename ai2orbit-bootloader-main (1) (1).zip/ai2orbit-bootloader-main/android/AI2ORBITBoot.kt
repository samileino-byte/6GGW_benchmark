/**
 * AI2ORBITBoot.kt - Kotlin wrapper for AI2ORBIT Bootloader
 *
 * Usage in your Activity:
 *   val boot = AI2ORBITBoot()
 *   boot.init()                       // phone
 *   boot.initTablet()                 // tablet
 *   val lines = boot.run()            // returns array of text lines
 *   textView.text = lines.joinToString("")  // render on black screen
 *   boot.destroy()
 *
 * Copyright (c) AI2ORBIT Co. 2026
 */

package com.ai2orbit.boot

class AI2ORBITBoot {

    companion object {
        init {
            System.loadLibrary("ai2orbit_boot")
        }
    }

    fun init() = nativeInit()

    fun initTablet() = nativeInitTablet()

    fun run(): Array<String> = nativeRun()

    fun version(): String = nativeVersion()

    fun destroy() = nativeDestroy()

    private external fun nativeInit()
    private external fun nativeInitTablet()
    private external fun nativeRun(): Array<String>
    private external fun nativeGetTimingPs(): Double
    private external fun nativeVersion(): String
    private external fun nativeDestroy()
}
