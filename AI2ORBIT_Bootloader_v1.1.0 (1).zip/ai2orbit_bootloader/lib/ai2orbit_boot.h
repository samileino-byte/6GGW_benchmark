/**
 * ai2orbit_boot.h - AI2ORBIT Bootloader Library
 *
 * Performance bootloader for application startup.
 * Selects random picosecond timing from 244 options,
 * runs DRAM mapper 4x, optimizes browser/network/screen.
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 *
 * Platforms: Windows, Linux, macOS, Android (NDK), iOS
 * Form factors: Phone, Tablet (iPad), Desktop
 */

#ifndef AI2ORBIT_BOOT_H
#define AI2ORBIT_BOOT_H

#include <cstdint>
#include <string>
#include <vector>
#include <functional>

namespace ai2orbit {

enum class BootPlatform {
    WINDOWS,
    LINUX,
    MACOS,
    ANDROID,
    IOS
};

enum class BootFormFactor {
    DESKTOP,
    PHONE,
    TABLET
};

struct TimingOption {
    int index;
    double picoseconds;
};

struct DramPassResult {
    int pass_number;
    double elapsed_sec;
    double throughput_mbps;
    double latency_ns;
    int regions;
    double acceleration;
};

struct BootResult {
    double selected_timing_ps;
    int selected_index;
    int rnd45_value;
    double loader_time_sec;
    double platform_time_sec;
    DramPassResult dram_passes[4];
    double total_boot_sec;

    double browser_speedup_pct;
    double network_speedup_pct;
    double screen_speedup_pct;

    std::string platform;
    std::string form_factor;
    bool ready;
};

using BootProgressCallback = std::function<void(const std::string& stage, double progress)>;
using BootOutputCallback = std::function<void(const std::string& line)>;

class Bootloader {
public:
    Bootloader();
    ~Bootloader();

    void set_platform(BootPlatform platform);
    void set_form_factor(BootFormFactor form_factor);
    void set_output_callback(BootOutputCallback cb);

    void generate_timing_table();

    const std::vector<TimingOption>& get_timing_table() const;

    BootResult run(BootProgressCallback on_progress = nullptr);

    static const char* platform_name(BootPlatform p);
    static const char* form_factor_name(BootFormFactor f);

    static BootPlatform detect_platform();
    static BootFormFactor detect_form_factor(BootPlatform platform);

    static const char* version();

    bool is_mobile() const;

private:
    BootPlatform platform_;
    BootFormFactor form_factor_;
    std::vector<TimingOption> timing_table_;
    BootOutputCallback output_cb_;

    TimingOption select_random_timing();
    int select_rnd45();
    void run_loader_bar(double duration_sec, BootProgressCallback cb);
    void run_platform_init(BootProgressCallback cb);
    DramPassResult run_dram_pass(int pass_num, BootProgressCallback cb);
    void compute_speedups(BootResult& result);
    void emit(const std::string& line);
    void print_status(const std::string& msg);
    void print_value(const std::string& label, double value, const std::string& unit);

    size_t dram_block_size() const;
    int loader_bar_width() const;
    int platform_init_iterations() const;
};

}

#endif
