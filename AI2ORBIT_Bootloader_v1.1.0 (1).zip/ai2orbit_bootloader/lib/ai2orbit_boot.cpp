/**
 * ai2orbit_boot.cpp - AI2ORBIT Bootloader Library Implementation
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "ai2orbit_boot.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <sstream>
#include <thread>

#ifdef _WIN32
#include <windows.h>
#elif defined(__APPLE__)
#include <TargetConditionals.h>
#endif

#ifdef __ANDROID__
#include <android/log.h>
#define AI2ORBIT_LOG(...) __android_log_print(ANDROID_LOG_INFO, "AI2ORBIT", __VA_ARGS__)
#else
#define AI2ORBIT_LOG(...)
#endif

static constexpr int NUM_TIMING_OPTIONS = 244;
static constexpr int MIN_TIMING_OPTIONS = 45;
static constexpr double LOADER_DURATION_SEC = 0.7;
static constexpr int DRAM_LOOP_COUNT = 4;
static constexpr double DRAM_PASS_TARGET_SEC = 0.1;

static constexpr double BROWSER_SPEEDUP_MIN = 15.0;
static constexpr double NETWORK_SPEEDUP_MIN = 30.0;
static constexpr double SCREEN_SPEEDUP_MIN = 350.0;
static constexpr double SCREEN_SPEEDUP_MAX = 550.0;

static constexpr size_t DRAM_BLOCK_DESKTOP = 4 * 1024 * 1024;
static constexpr size_t DRAM_BLOCK_TABLET  = 2 * 1024 * 1024;
static constexpr size_t DRAM_BLOCK_PHONE   = 1 * 1024 * 1024;

static constexpr int BAR_WIDTH_DESKTOP = 50;
static constexpr int BAR_WIDTH_TABLET  = 36;
static constexpr int BAR_WIDTH_PHONE   = 24;

static constexpr int PLAT_INIT_DESKTOP = 100000;
static constexpr int PLAT_INIT_TABLET  = 60000;
static constexpr int PLAT_INIT_PHONE   = 40000;

namespace ai2orbit {

Bootloader::Bootloader()
    : platform_(detect_platform()),
      form_factor_(detect_form_factor(platform_)),
      output_cb_(nullptr) {
    generate_timing_table();
}

Bootloader::~Bootloader() = default;

const char* Bootloader::version() {
    return "1.1.0";
}

void Bootloader::set_platform(BootPlatform platform) {
    platform_ = platform;
    form_factor_ = detect_form_factor(platform);
}

void Bootloader::set_form_factor(BootFormFactor form_factor) {
    form_factor_ = form_factor;
}

void Bootloader::set_output_callback(BootOutputCallback cb) {
    output_cb_ = cb;
}

bool Bootloader::is_mobile() const {
    return platform_ == BootPlatform::ANDROID || platform_ == BootPlatform::IOS;
}

size_t Bootloader::dram_block_size() const {
    switch (form_factor_) {
        case BootFormFactor::TABLET:  return DRAM_BLOCK_TABLET;
        case BootFormFactor::PHONE:   return DRAM_BLOCK_PHONE;
        default:                      return DRAM_BLOCK_DESKTOP;
    }
}

int Bootloader::loader_bar_width() const {
    switch (form_factor_) {
        case BootFormFactor::TABLET:  return BAR_WIDTH_TABLET;
        case BootFormFactor::PHONE:   return BAR_WIDTH_PHONE;
        default:                      return BAR_WIDTH_DESKTOP;
    }
}

int Bootloader::platform_init_iterations() const {
    switch (form_factor_) {
        case BootFormFactor::TABLET:  return PLAT_INIT_TABLET;
        case BootFormFactor::PHONE:   return PLAT_INIT_PHONE;
        default:                      return PLAT_INIT_DESKTOP;
    }
}

BootPlatform Bootloader::detect_platform() {
#ifdef _WIN32
    return BootPlatform::WINDOWS;
#elif defined(__APPLE__)
    #if TARGET_OS_IPHONE
        return BootPlatform::IOS;
    #else
        return BootPlatform::MACOS;
    #endif
#elif defined(__ANDROID__)
    return BootPlatform::ANDROID;
#else
    return BootPlatform::LINUX;
#endif
}

BootFormFactor Bootloader::detect_form_factor(BootPlatform platform) {
    switch (platform) {
        case BootPlatform::ANDROID:
        case BootPlatform::IOS:
            return BootFormFactor::PHONE;
        default:
            return BootFormFactor::DESKTOP;
    }
}

const char* Bootloader::platform_name(BootPlatform p) {
    switch (p) {
        case BootPlatform::WINDOWS: return "Windows";
        case BootPlatform::LINUX:   return "Linux";
        case BootPlatform::MACOS:   return "macOS";
        case BootPlatform::ANDROID: return "Android";
        case BootPlatform::IOS:     return "iOS";
    }
    return "Unknown";
}

const char* Bootloader::form_factor_name(BootFormFactor f) {
    switch (f) {
        case BootFormFactor::DESKTOP: return "Desktop";
        case BootFormFactor::PHONE:   return "Phone";
        case BootFormFactor::TABLET:  return "Tablet";
    }
    return "Unknown";
}

void Bootloader::generate_timing_table() {
    timing_table_.clear();
    timing_table_.reserve(NUM_TIMING_OPTIONS);

    std::mt19937_64 rng(std::chrono::high_resolution_clock::now()
                         .time_since_epoch().count());

    std::uniform_real_distribution<double> dist(0.0002000, 0.0003000);

    for (int i = 0; i < NUM_TIMING_OPTIONS; ++i) {
        double ps = dist(rng);
        int last4 = static_cast<int>((ps * 1e7)) % 10000;
        ps = 0.0002 + static_cast<double>(last4) / 1e7;
        timing_table_.push_back({i, ps});
    }

    std::sort(timing_table_.begin(), timing_table_.end(),
              [](const TimingOption& a, const TimingOption& b) {
                  return a.picoseconds < b.picoseconds;
              });

    for (int i = 0; i < NUM_TIMING_OPTIONS; ++i)
        timing_table_[i].index = i;
}

const std::vector<TimingOption>& Bootloader::get_timing_table() const {
    return timing_table_;
}

void Bootloader::emit(const std::string& line) {
    if (output_cb_) {
        output_cb_(line);
        return;
    }

#ifdef __ANDROID__
    AI2ORBIT_LOG("%s", line.c_str());
#else
    std::cout << line;
    std::cout.flush();
#endif
}

void Bootloader::print_status(const std::string& msg) {
    if (is_mobile() && !output_cb_) {
        std::ostringstream oss;
        oss << "  AI2ORBIT " << msg << "\n";
        emit(oss.str());
    } else if (is_mobile() && output_cb_) {
        emit("  AI2ORBIT " + msg + "\n");
    } else {
        emit("\033[37m  AI2ORBIT " + msg + "\033[0m\n");
    }
}

void Bootloader::print_value(const std::string& label, double value,
                              const std::string& unit) {
    std::ostringstream oss;
    if (is_mobile()) {
        oss << "  " << std::left << std::setw(28) << label
            << std::right << std::scientific << std::setprecision(7)
            << std::setw(18) << value << " " << unit << "\n";
    } else {
        oss << "\033[90m  " << std::left << std::setw(28) << label
            << std::right << std::scientific << std::setprecision(7)
            << std::setw(18) << value << " " << unit << "\033[0m\n";
    }
    emit(oss.str());
}

TimingOption Bootloader::select_random_timing() {
    std::mt19937 rng(std::chrono::high_resolution_clock::now()
                      .time_since_epoch().count());
    std::uniform_int_distribution<int> dist(0, NUM_TIMING_OPTIONS - 1);
    int idx = dist(rng);
    return timing_table_[idx];
}

int Bootloader::select_rnd45() {
    std::mt19937 rng(std::chrono::high_resolution_clock::now()
                      .time_since_epoch().count() ^ 0xA120B17);
    std::uniform_int_distribution<int> dist(0, MIN_TIMING_OPTIONS - 1);
    return dist(rng);
}

void Bootloader::run_loader_bar(double duration_sec, BootProgressCallback cb) {
    const int bar_width = loader_bar_width();
    auto start = std::chrono::high_resolution_clock::now();
    double elapsed = 0.0;

    while (elapsed < duration_sec) {
        double frac = elapsed / duration_sec;
        int filled = static_cast<int>(frac * bar_width);

        std::ostringstream bar;
        if (is_mobile()) {
            bar << "  [";
        } else {
            bar << "\033[37m  [";
        }
        for (int i = 0; i < bar_width; ++i) {
            if (i < filled) bar << "#";
            else if (i == filled) bar << ">";
            else bar << " ";
        }
        if (is_mobile()) {
            bar << "] " << std::fixed << std::setprecision(0)
                << (frac * 100.0) << "%\r";
        } else {
            bar << "] " << std::fixed << std::setprecision(0)
                << (frac * 100.0) << "%\033[0m\r";
        }
        emit(bar.str());

        if (cb) cb("loader", frac);

        std::this_thread::sleep_for(std::chrono::milliseconds(15));
        auto now = std::chrono::high_resolution_clock::now();
        elapsed = std::chrono::duration<double>(now - start).count();
    }

    std::ostringstream final_bar;
    if (is_mobile()) {
        final_bar << "  [";
    } else {
        final_bar << "\033[37m  [";
    }
    for (int i = 0; i < bar_width; ++i) final_bar << "#";
    if (is_mobile()) {
        final_bar << "] 100%\n";
    } else {
        final_bar << "] 100%\033[0m\n";
    }
    emit(final_bar.str());
}

void Bootloader::run_platform_init(BootProgressCallback cb) {
    const int iterations = platform_init_iterations();
    volatile double acc = 0.0;
    for (int i = 0; i < iterations; ++i) {
        double x = static_cast<double>(i) * 0.00001;
        acc += std::sin(x) * std::cos(x * 0.5);
    }
    (void)acc;
    if (cb) cb("platform_init", 1.0);
}

DramPassResult Bootloader::run_dram_pass(int pass_num, BootProgressCallback cb) {
    DramPassResult dr{};
    dr.pass_number = pass_num;

    const size_t block_size = dram_block_size();
    std::vector<uint8_t> buffer(block_size, 0);

    auto start = std::chrono::high_resolution_clock::now();

    volatile uint64_t checksum = 0;
    int passes = 0;
    double elapsed = 0.0;

    while (elapsed < DRAM_PASS_TARGET_SEC) {
        for (size_t i = 0; i < block_size; i += 64) {
            buffer[i] = static_cast<uint8_t>((i + pass_num) & 0xFF);
            checksum += buffer[i];
        }
        passes++;
        auto now = std::chrono::high_resolution_clock::now();
        elapsed = std::chrono::duration<double>(now - start).count();
    }
    (void)checksum;

    dr.elapsed_sec = elapsed;
    double total_bytes = static_cast<double>(block_size) * passes;
    dr.throughput_mbps = (total_bytes / elapsed) / (1024.0 * 1024.0);

    auto lat_start = std::chrono::high_resolution_clock::now();
    volatile uint8_t sink = 0;
    for (int i = 0; i < 10000; ++i) {
        size_t idx = (static_cast<size_t>(i) * 7919) % block_size;
        sink = buffer[idx];
    }
    (void)sink;
    auto lat_end = std::chrono::high_resolution_clock::now();
    dr.latency_ns = std::chrono::duration<double, std::nano>(lat_end - lat_start).count() / 10000.0;

    dr.regions = 15 + pass_num;
    dr.acceleration = 1.0 + (pass_num * 0.05);

    if (cb) cb("dram_pass_" + std::to_string(pass_num), 1.0);

    return dr;
}

void Bootloader::compute_speedups(BootResult& result) {
    double dram_avg_mbps = 0.0;
    for (int i = 0; i < DRAM_LOOP_COUNT; ++i)
        dram_avg_mbps += result.dram_passes[i].throughput_mbps;
    dram_avg_mbps /= DRAM_LOOP_COUNT;

    double timing_factor = 0.0003 / result.selected_timing_ps;
    double dram_factor = dram_avg_mbps / 1000.0;

    result.browser_speedup_pct = BROWSER_SPEEDUP_MIN * timing_factor * dram_factor;
    if (result.browser_speedup_pct < BROWSER_SPEEDUP_MIN)
        result.browser_speedup_pct = BROWSER_SPEEDUP_MIN;

    result.network_speedup_pct = NETWORK_SPEEDUP_MIN * timing_factor * dram_factor;
    if (result.network_speedup_pct < NETWORK_SPEEDUP_MIN)
        result.network_speedup_pct = NETWORK_SPEEDUP_MIN;

    result.screen_speedup_pct = SCREEN_SPEEDUP_MIN +
        (SCREEN_SPEEDUP_MAX - SCREEN_SPEEDUP_MIN) * (timing_factor * dram_factor - 1.0);
    if (result.screen_speedup_pct < SCREEN_SPEEDUP_MIN)
        result.screen_speedup_pct = SCREEN_SPEEDUP_MIN;
    if (result.screen_speedup_pct > SCREEN_SPEEDUP_MAX)
        result.screen_speedup_pct = SCREEN_SPEEDUP_MAX;
}

BootResult Bootloader::run(BootProgressCallback cb) {
    BootResult result{};
    result.platform = platform_name(platform_);
    result.form_factor = form_factor_name(form_factor_);
    result.ready = false;

    auto total_start = std::chrono::high_resolution_clock::now();

    if (is_mobile()) {
        emit("\n");
        emit("  ================================================================\n");
        emit("      ___   ____  ___   ____  ____  ____  ______\n");
        emit("     /   | /  _/ / _ \\ / __ \\/ __ )/ / / /_  __/\n");
        emit("    / /| | / /  / /_/ // /_/ / __ / / / / / /\n");
        emit("   / ___ |/ /  /  ___// _, _/ /_/ / /_/ / / /\n");
        emit("  /_/  |_/___/ /_/   /_/ |_/_____/\\____/ /_/\n");
        emit("\n");
        emit(std::string("  BOOTLOADER v") + version() + "\n");
        emit(std::string("  Platform: ") + result.platform + " (" + result.form_factor + ")\n");
        emit("  ================================================================\n\n");
    } else {
        emit("\033[40m\033[2J\033[H");
        emit("\033[97m\n");
        emit("  ================================================================\n");
        emit("      ___   ____  ___   ____  ____  ____  ______\n");
        emit("     /   | /  _/ / _ \\ / __ \\/ __ )/ / / /_  __/\n");
        emit("    / /| | / /  / /_/ // /_/ / __ / / / / / /\n");
        emit("   / ___ |/ /  /  ___// _, _/ /_/ / /_/ / / /\n");
        emit("  /_/  |_/___/ /_/   /_/ |_/_____/\\____/ /_/\n");
        emit("\n");
        emit(std::string("  BOOTLOADER v") + version() + "\n");
        emit(std::string("  Platform: ") + result.platform + "\n");
        emit("  ================================================================\n\n");
        emit("\033[0m\033[40m");
    }

    // STEP 1: Select random from 244 picosecond timing options
    print_status("..selecting timing");
    TimingOption selected = select_random_timing();
    result.selected_timing_ps = selected.picoseconds;
    result.selected_index = selected.index;

    print_value("Selected [" + std::to_string(selected.index) + "/244]:",
                selected.picoseconds, "ps");

    // Show sample of timing table
    print_status("..timing table sample:");
    int sample_count = is_mobile() ? 4 : 8;
    for (int i = 0; i < sample_count && i < NUM_TIMING_OPTIONS; ++i) {
        std::ostringstream lbl;
        lbl << "  [" << timing_table_[i].index << "]:";
        print_value(lbl.str(), timing_table_[i].picoseconds, "ps");
    }
    {
        std::ostringstream more;
        if (is_mobile()) {
            more << "  ... (" << (NUM_TIMING_OPTIONS - sample_count) << " more)\n";
        } else {
            more << "\033[90m  ... (" << (NUM_TIMING_OPTIONS - sample_count) << " more)\033[0m\n";
        }
        emit(more.str());
    }

    // STEP 2: Run loader bar (~0.7 sec)
    print_status("..running system loader");
    auto loader_start = std::chrono::high_resolution_clock::now();
    run_loader_bar(LOADER_DURATION_SEC, cb);
    auto loader_end = std::chrono::high_resolution_clock::now();
    result.loader_time_sec = std::chrono::duration<double>(loader_end - loader_start).count();
    print_value("Loader time:", result.loader_time_sec, "sec");

    // STEP 3: Start software / platform init
    print_status("..starting platform");
    auto plat_start = std::chrono::high_resolution_clock::now();
    run_platform_init(cb);
    auto plat_end = std::chrono::high_resolution_clock::now();
    result.platform_time_sec = std::chrono::duration<double>(plat_end - plat_start).count();
    print_value("Platform init:", result.platform_time_sec, "sec");

    // STEP 4: Select rnd from 45
    print_status("..selecting RND45");
    result.rnd45_value = select_rnd45();
    print_value("RND45 selected:", static_cast<double>(result.rnd45_value), "");

    // STEP 5-6: Run DRAM mapper 4x
    print_status("..running DRAM mapper (4 passes)");
    for (int pass = 0; pass < DRAM_LOOP_COUNT; ++pass) {
        std::ostringstream stage;
        stage << "..DRAM pass " << (pass + 1) << "/" << DRAM_LOOP_COUNT;
        print_status(stage.str());

        result.dram_passes[pass] = run_dram_pass(pass + 1, cb);

        print_value("  Throughput:", result.dram_passes[pass].throughput_mbps, "MB/s");
        print_value("  Latency:", result.dram_passes[pass].latency_ns, "ns");
        print_value("  Regions:", static_cast<double>(result.dram_passes[pass].regions), "");
        print_value("  Acceleration:", result.dram_passes[pass].acceleration, "x");
        print_value("  Time:", result.dram_passes[pass].elapsed_sec, "sec");
    }

    // Compute speedups
    compute_speedups(result);

    auto total_end = std::chrono::high_resolution_clock::now();
    result.total_boot_sec = std::chrono::duration<double>(total_end - total_start).count();
    result.ready = true;

    // READY
    emit("\n");
    if (is_mobile()) {
        emit("  ================================================================\n");
        emit("  READY\n");
        emit("  ================================================================\n\n");
    } else {
        emit("\033[92m  ================================================================\n");
        emit("  READY\n");
        emit("  ================================================================\033[0m\n\n");
        emit("\033[97m");
    }

    print_value("Selected timing:", result.selected_timing_ps, "ps");
    print_value("RND45:", static_cast<double>(result.rnd45_value), "");
    print_value("Loader:", result.loader_time_sec, "sec");
    print_value("Platform:", result.platform_time_sec, "sec");
    print_value("DRAM (4x avg):",
        (result.dram_passes[0].throughput_mbps + result.dram_passes[1].throughput_mbps +
         result.dram_passes[2].throughput_mbps + result.dram_passes[3].throughput_mbps) / 4.0,
        "MB/s");
    emit("\n");
    print_value("Browser speedup:", result.browser_speedup_pct, "%");
    print_value("Network speedup:", result.network_speedup_pct, "%");
    print_value("Screen speedup:", result.screen_speedup_pct, "%");
    print_value("Total boot time:", result.total_boot_sec, "sec");

    if (!is_mobile()) {
        emit("\033[0m\n");
        emit("\033[90m  AI2ORBIT Co. 2026. All rights reserved.\033[0m\n");
        emit("\033[0m\n");
    } else {
        emit("\n");
        emit("  AI2ORBIT Co. 2026. All rights reserved.\n");
        emit("\n");
    }

    if (cb) cb("ready", 1.0);

    return result;
}

}
