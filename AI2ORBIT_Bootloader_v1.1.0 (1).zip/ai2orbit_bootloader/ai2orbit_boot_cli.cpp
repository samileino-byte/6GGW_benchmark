/**
 * ai2orbit_boot_cli.cpp - AI2ORBIT Bootloader CLI
 *
 * Manually started bootloader.
 * Black screen, numbers listed, AI2ORBIT ..running
 *
 * Usage:
 *   ai2orbit_boot_cli                     (auto-detect platform)
 *   ai2orbit_boot_cli --android           (simulate Android phone)
 *   ai2orbit_boot_cli --android --tablet  (simulate Android tablet)
 *   ai2orbit_boot_cli --ios               (simulate iOS phone)
 *   ai2orbit_boot_cli --ios --tablet      (simulate iPad)
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "ai2orbit_boot.h"
#include <cstring>
#include <iostream>

int main(int argc, char* argv[]) {
    ai2orbit::Bootloader boot;

    bool force_tablet = false;

    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--android") == 0) {
            boot.set_platform(ai2orbit::BootPlatform::ANDROID);
        } else if (std::strcmp(argv[i], "--ios") == 0) {
            boot.set_platform(ai2orbit::BootPlatform::IOS);
        } else if (std::strcmp(argv[i], "--tablet") == 0) {
            force_tablet = true;
        } else if (std::strcmp(argv[i], "--windows") == 0) {
            boot.set_platform(ai2orbit::BootPlatform::WINDOWS);
        } else if (std::strcmp(argv[i], "--macos") == 0) {
            boot.set_platform(ai2orbit::BootPlatform::MACOS);
        } else if (std::strcmp(argv[i], "--linux") == 0) {
            boot.set_platform(ai2orbit::BootPlatform::LINUX);
        }
    }

    if (force_tablet) {
        boot.set_form_factor(ai2orbit::BootFormFactor::TABLET);
    }

    auto result = boot.run();

    if (!result.ready) {
        std::cerr << "Boot failed.\n";
        return 1;
    }

    return 0;
}
