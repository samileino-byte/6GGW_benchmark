/**
 * ai2orbit_boot.h - AI2ORBIT Bootloader Library
 *
 * Performance bootloader for application startup.
 * Selects random picosecond timing from 244 options,
 * runs DRAM mapper 4x, optimizes browser/network/screen.
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 *
 * This software is proprietary and confidential.
 * Unauthorized copying, distribution, or modification is strictly prohibited.
 *
 * Platforms: Windows, Linux, macOS, Android (NDK), iOS
 */

#ifndef AI2ORBIT_BOOT_H
#define AI2ORBIT_BOOT_H

#include <cstdint>
#include <string>
#include <vector>
#include <functional>

namespace ai2orbit {

struct TimingOption {
    int index;
    double picoseconds;
};

struct DramPassResult {
    int pass_number;
    double elapsed_sec;
    double throughput_mbps;
    double latency_ns;
    int regions;
    double acceleration;
};

struct BootResult {
    double selected_timing_ps;
    int selected_index;
    int rnd45_value;
    double loader_time_sec;
    double platform_time_sec;
    DramPassResult dram_passes[4];
    double total_boot_sec;

    double browser_speedup_pct;
    double network_speedup_pct;
    double screen_speedup_pct;

    std::string platform;
    bool ready;
};

enum class BootPlatform {
    WINDOWS,
    LINUX,
    MACOS,
    ANDROID,
    IOS
};

using BootProgressCallback = std::function<void(const std::string& stage, double progress)>;

class Bootloader {
public:
    Bootloader();
    ~Bootloader();

    void set_platform(BootPlatform platform);

    void generate_timing_table();

    const std::vector<TimingOption>& get_timing_table() const;

    BootResult run(BootProgressCallback on_progress = nullptr);

    static const char* platform_name(BootPlatform p);

    static BootPlatform detect_platform();

    static const char* version();

private:
    BootPlatform platform_;
    std::vector<TimingOption> timing_table_;

    TimingOption select_random_timing();
    int select_rnd45();
    void run_loader_bar(double duration_sec, BootProgressCallback cb);
    void run_platform_init(BootProgressCallback cb);
    DramPassResult run_dram_pass(int pass_num, BootProgressCallback cb);
    void compute_speedups(BootResult& result);
    void print_status(const std::string& msg);
    void print_value(const std::string& label, double value, const std::string& unit);
};

}

#endif
