/**
 * ai2orbit_boot_cli.cpp - AI2ORBIT Bootloader CLI
 *
 * Manually started bootloader.
 * Black screen, numbers listed, AI2ORBIT ..running
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "ai2orbit_boot.h"
#include <iostream>

int main() {
    ai2orbit::Bootloader boot;
    auto result = boot.run();

    if (!result.ready) {
        std::cerr << "Boot failed.\n";
        return 1;
    }

    return 0;
}
