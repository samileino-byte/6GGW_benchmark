/**
 * test_bench.cpp - AI2ORBIT Windows Test Bench
 *
 * Comprehensive component testing tool for desktop and phone form factors.
 * Tests: Virtual Streams, WiFi 802.11, Network, GPS, Port Switching, Tunnels.
 *
 * Copyright (c) AI2ORBIT Co. 2026
 * Authors: Sami Leino, Anirudha Talmale
 * All rights reserved.
 */

#include "netswitch.h"
#include "winsock_engine.h"
#include "port_switcher.h"
#include "tunnel_manager.h"
#include "connection_pool.h"
#include "virtual_stream.h"
#include "wifi_tester.h"
#include "logger.h"

#include <iostream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <cstring>
#include <cmath>

using namespace netswitch;

static const char* VERSION = "1.2.0";

enum class FormFactor { DESKTOP, PHONE, TABLET };

struct GpsLocation {
    double latitude;
    double longitude;
    double altitude_m;
    double accuracy_m;
    bool valid;
    std::string provider;
};

struct TestBenchConfig {
    FormFactor form_factor;
    GpsLocation gps;
    bool run_streams;
    bool run_wifi;
    bool run_network;
    bool run_gps;
    bool run_ports;
    bool run_tunnels;
    bool verbose;
};

struct TestBenchResult {
    int total_tests;
    int passed;
    int failed;
    double duration_sec;
    std::string report;
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

static std::string form_factor_name(FormFactor ff) {
    switch (ff) {
        case FormFactor::DESKTOP: return "Desktop";
        case FormFactor::PHONE:   return "Phone";
        case FormFactor::TABLET:  return "Tablet";
    }
    return "Unknown";
}

static void print_header(std::ostringstream& ss, const TestBenchConfig& cfg) {
    ss << "================================================================\n";
    ss << "  AI2ORBIT Test Bench v" << VERSION << "\n";
    ss << "  Form Factor: " << form_factor_name(cfg.form_factor) << "\n";
    if (cfg.gps.valid) {
        ss << std::fixed << std::setprecision(6);
        ss << "  GPS: " << cfg.gps.latitude << ", " << cfg.gps.longitude
           << " (alt: " << std::setprecision(1) << cfg.gps.altitude_m << "m"
           << ", acc: " << cfg.gps.accuracy_m << "m"
           << ", src: " << cfg.gps.provider << ")\n";
    } else {
        ss << "  GPS: Not available\n";
    }
    ss << "================================================================\n\n";
}

static void section(std::ostringstream& ss, const std::string& name) {
    ss << "--- " << name << " ";
    int padding = 60 - static_cast<int>(name.length());
    for (int i = 0; i < padding; i++) ss << "-";
    ss << "\n\n";
}

// ---------------------------------------------------------------------------
// Test: Virtual Streams
// ---------------------------------------------------------------------------

static int test_virtual_streams(WinsockEngine& engine, Logger& logger,
                                 std::ostringstream& ss, FormFactor ff) {
    section(ss, "VIRTUAL STREAMS (Protocol > Port > Socket > App)");

    VirtualStream vs(engine, logger);
    int passed = 0, failed = 0;

    auto check = [&](const std::string& name, bool result) {
        if (result) {
            ss << "  [PASS] " << name << "\n";
            passed++;
        } else {
            ss << "  [FAIL] " << name << "\n";
            failed++;
        }
    };

    // System streams 1-6
    ss << "  System Streams (1-6):\n";
    for (int i = 1; i <= 6; i++) {
        auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080 + i);
        bool ok = vs.open_stream(cfg);
        check("  Open system stream " + std::to_string(i), ok);
    }

    auto sys = vs.get_system_streams();
    check("  All 6 system streams open", sys.size() == 6);

    // App streams 7-12
    ss << "\n  Application Streams (7+):\n";
    int app_count = (ff == FormFactor::PHONE) ? 3 : 6;
    for (int i = 7; i < 7 + app_count; i++) {
        auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 9000 + i);
        bool ok = vs.open_stream(cfg);
        check("  Open app stream " + std::to_string(i), ok);
    }

    auto apps = vs.get_application_streams();
    check("  App streams count correct", static_cast<int>(apps.size()) == app_count);

    // Boundary tests
    ss << "\n  Boundary Tests:\n";
    {
        StreamConfig bad = {};
        bad.stream_id = 0;
        bad.group = StreamGroup::SYSTEM;
        bad.protocol = StreamProtocol::TCP;
        bad.security_mode = StreamSecurityMode::EPHEMERAL;
        bad.remote_host = "127.0.0.1";
        bad.remote_port = 8080;
        bad.socket_timeout_ms = 1000;
        check("  Reject stream ID 0", !vs.open_stream(bad));
    }
    {
        StreamConfig bad = {};
        bad.stream_id = 7;
        bad.group = StreamGroup::SYSTEM;
        bad.protocol = StreamProtocol::TCP;
        bad.security_mode = StreamSecurityMode::EPHEMERAL;
        bad.remote_host = "127.0.0.1";
        bad.remote_port = 8080;
        bad.socket_timeout_ms = 1000;
        check("  Reject system ID 7", !vs.open_stream(bad));
    }
    check("  Reject duplicate stream", !vs.open_stream(VirtualStream::make_system_stream(1, "127.0.0.1", 8081)));

    // Ephemeral socket test
    ss << "\n  Ephemeral Socket (open/close per transfer):\n";
    {
        auto cfg = VirtualStream::make_system_stream(1, "192.0.2.1", 65534);
        // stream 1 already open, close and reopen with unreachable host
        vs.close_stream(1);
        cfg.socket_timeout_ms = 300;
        cfg.max_retries = 0;
        vs.open_stream(cfg);
        const char* data = "test-payload";
        auto result = vs.send(1, data, strlen(data));
        check("  Ephemeral send opens socket", result.socket_opens > 0);
        check("  Ephemeral send fails gracefully", !result.success);
        auto stats = vs.get_stats(1);
        check("  Stats track failed transfer", stats.failed_transfers == 1);
    }

    // Security modes
    ss << "\n  Security Modes:\n";
    {
        auto vpn_cfg = VirtualStream::make_vpn_stream(13, "vpn.test.local", 1194, "tun-001");
        check("  VPN stream auto-detects APP group", vpn_cfg.group == StreamGroup::APPLICATION);
        check("  VPN stream has TLS_TCP protocol", vpn_cfg.protocol == StreamProtocol::TLS_TCP);
        check("  VPN stream has TUNNEL_VPN security", vpn_cfg.security_mode == StreamSecurityMode::TUNNEL_VPN);
    }

    // Cleanup
    for (int id : vs.get_open_streams()) vs.close_stream(id);
    check("  All streams closed", vs.get_open_streams().empty());

    ss << "\n  Streams: " << passed << " passed, " << failed << " failed\n\n";
    return failed;
}

// ---------------------------------------------------------------------------
// Test: WiFi 802.11 Protocol
// ---------------------------------------------------------------------------

static int test_wifi(WinsockEngine& engine, Logger& logger, std::ostringstream& ss) {
    section(ss, "WLAN/WiFi 802.11 PROTOCOL TESTER");

    WifiTester wt(engine, logger);
    int passed = 0, failed = 0;

    auto check = [&](const std::string& name, bool result) {
        if (result) {
            ss << "  [PASS] " << name << "\n";
            passed++;
        } else {
            ss << "  [FAIL] " << name << "\n";
            failed++;
        }
    };

    // Capability tests
    ss << "  Capability Database:\n";
    auto caps = wt.get_all_capabilities();
    check("  8 WiFi standards registered", caps.size() == 8);

    for (auto& cap : caps) {
        check("  " + cap.name + " (" + cap.ieee_name + ") max=" + std::to_string(static_cast<int>(cap.max_data_rate_mbps)) + "Mbps",
              cap.max_data_rate_mbps > 0);
    }

    // Channel tests
    ss << "\n  Channel Enumeration:\n";
    auto ch24 = wt.get_channels(WifiBand::BAND_2_4GHZ);
    check("  2.4 GHz: " + std::to_string(ch24.size()) + " channels", ch24.size() == 11);

    auto ch5 = wt.get_channels(WifiBand::BAND_5GHZ);
    check("  5 GHz: " + std::to_string(ch5.size()) + " channels", ch5.size() == 25);

    auto ch6 = wt.get_channels(WifiBand::BAND_6GHZ);
    check("  6 GHz: " + std::to_string(ch6.size()) + " channels", ch6.size() > 0);

    // Per-standard throughput tests
    ss << "\n  Protocol Throughput Tests:\n";
    auto suite = wt.run_full_suite();

    for (auto& r : suite.results) {
        std::ostringstream label;
        label << std::fixed << std::setprecision(1);
        label << "  " << WifiTester::standard_name(r.standard)
              << ": " << r.measured_throughput_mbps << "/" << r.theoretical_max_mbps << " Mbps"
              << " eff=" << r.efficiency_pct << "%"
              << " lat=" << std::setprecision(2) << r.latency_ms << "ms"
              << " loss=" << r.packet_loss_pct << "%";
        check(label.str(), r.passed);
    }

    check("  All standards tested", suite.standards_tested == 8);

    ss << "\n  WiFi: " << passed << " passed, " << failed << " failed\n\n";
    return failed;
}

// ---------------------------------------------------------------------------
// Test: Network (Port Switching, Connection Pool)
// ---------------------------------------------------------------------------

static int test_network(WinsockEngine& engine, Logger& logger, std::ostringstream& ss) {
    section(ss, "NETWORK COMPONENTS");

    int passed = 0, failed = 0;

    auto check = [&](const std::string& name, bool result) {
        if (result) {
            ss << "  [PASS] " << name << "\n";
            passed++;
        } else {
            ss << "  [FAIL] " << name << "\n";
            failed++;
        }
    };

    // WinsockEngine
    ss << "  WinsockEngine:\n";
    check("  Engine initialized", engine.is_initialized());

    SOCKET sock = engine.create_socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    check("  Socket creation", sock != INVALID_SOCKET);
    if (sock != INVALID_SOCKET) {
        check("  Set reuse addr", engine.set_reuse_addr(sock, true));
        check("  Set nodelay", engine.set_nodelay(sock, true));
        check("  Set keepalive", engine.set_keepalive(sock, true, 30));
        check("  Set send timeout", engine.set_send_timeout(sock, 5000));
        check("  Set recv timeout", engine.set_recv_timeout(sock, 5000));
        check("  Set linger", engine.set_linger(sock, true, 2));
        engine.force_close(sock);
    }

    // Port Switcher
    ss << "\n  PortSwitcher:\n";
    {
        PortSwitcher ps(engine, logger);
        auto stats = ps.get_stats();
        check("  Initial stats zero", stats.total_switches == 0);
        check("  State is disconnected", ps.get_state() == ConnectionState::DISCONNECTED);

        ps.set_connect_timeout_ms(500);
        ps.set_cleanup_timeout_ms(500);
        auto result = ps.switch_port("127.0.0.1", 65534, 65535);
        check("  Switch graceful failure", !result.success || result.error_message.length() > 0);
    }

    // Connection Pool
    ss << "\n  ConnectionPool:\n";
    {
        ConnectionPool pool(engine, logger, 16);
        check("  Pool created (max=16)", pool.total_count() == 0);
        check("  Active count = 0", pool.active_count() == 0);
        check("  Idle count = 0", pool.idle_count() == 0);

        pool.set_max_idle_time(60);
        pool.set_max_lifetime(300);
        pool.evict_idle();
        check("  Evict idle (no-op)", pool.total_count() == 0);
        pool.drain();
        check("  Drain (no-op)", pool.total_count() == 0);

        auto stats = pool.get_stats();
        check("  Stats initial", stats.total_acquired == 0 && stats.total_created == 0);
    }

    // Connection Pool Manager
    ss << "\n  ConnectionPoolManager:\n";
    {
        ConnectionPoolManager mgr(engine, logger);
        auto& p1 = mgr.get_pool("default");
        auto& p2 = mgr.get_pool("streaming", 64);
        check("  Create pool 'default'", true);
        check("  Create pool 'streaming' (max=64)", true);

        auto pools = mgr.list_pools();
        check("  2 pools listed", pools.size() == 2);

        mgr.evict_all_idle();
        check("  Evict all idle", true);

        mgr.remove_pool("streaming");
        pools = mgr.list_pools();
        check("  Remove pool", pools.size() == 1);
    }

    // Tunnel Manager
    ss << "\n  TunnelManager:\n";
    {
        TunnelManager tm(engine, logger);
        auto tunnels = tm.get_all_tunnels();
        check("  No tunnels initially", tunnels.empty());

        TunnelConfig tc = {};
        tc.type = TunnelType::IKEV2;
        tc.remote_host = "vpn.test.local";
        tc.remote_port = 4500;
        tc.local_bind = "0.0.0.0";
        tc.local_port = 0;
        tc.keepalive_interval_sec = 30;
        tc.reconnect_delay_sec = 5;
        tc.auto_reconnect = false;

        std::string tid = tm.create_tunnel(tc);
        check("  Create IKEv2 tunnel config", !tid.empty());
        check("  Tunnel exists", !tm.get_all_tunnels().empty());

        auto state = tm.get_tunnel_state(tid);
        check("  Tunnel state DISCONNECTED", state.state == ConnectionState::DISCONNECTED);

        tm.destroy_tunnel(tid);
        check("  Tunnel destroyed", tm.get_all_tunnels().empty());
    }

    ss << "\n  Network: " << passed << " passed, " << failed << " failed\n\n";
    return failed;
}

// ---------------------------------------------------------------------------
// Test: GPS
// ---------------------------------------------------------------------------

static int test_gps(std::ostringstream& ss, const GpsLocation& gps) {
    section(ss, "GPS FUNCTIONALITY");

    int passed = 0, failed = 0;

    auto check = [&](const std::string& name, bool result) {
        if (result) {
            ss << "  [PASS] " << name << "\n";
            passed++;
        } else {
            ss << "  [FAIL] " << name << "\n";
            failed++;
        }
    };

    // GPS location validation
    ss << "  Location Validation:\n";
    check("  Latitude range [-90, 90]", gps.latitude >= -90.0 && gps.latitude <= 90.0);
    check("  Longitude range [-180, 180]", gps.longitude >= -180.0 && gps.longitude <= 180.0);
    check("  Altitude non-negative", gps.altitude_m >= 0.0);
    check("  Accuracy positive", gps.accuracy_m > 0.0);
    check("  Provider set", !gps.provider.empty());
    check("  Location valid", gps.valid);

    // GPS distance calculation (Haversine)
    ss << "\n  Haversine Distance Test:\n";
    {
        double lat1 = 60.1699, lon1 = 24.9384;   // Helsinki
        double lat2 = 61.4978, lon2 = 23.7610;   // Tampere

        double dLat = (lat2 - lat1) * M_PI / 180.0;
        double dLon = (lon2 - lon1) * M_PI / 180.0;
        double a = std::sin(dLat / 2) * std::sin(dLat / 2) +
                   std::cos(lat1 * M_PI / 180.0) * std::cos(lat2 * M_PI / 180.0) *
                   std::sin(dLon / 2) * std::sin(dLon / 2);
        double c = 2 * std::atan2(std::sqrt(a), std::sqrt(1 - a));
        double dist_km = 6371.0 * c;

        check("  Helsinki-Tampere ~162km", std::abs(dist_km - 162.0) < 10.0);
        ss << "    Calculated: " << std::fixed << std::setprecision(1) << dist_km << " km\n";
    }

    // GPS bearing calculation
    ss << "\n  Bearing Calculation:\n";
    {
        double lat1 = gps.latitude * M_PI / 180.0;
        double lon1 = gps.longitude * M_PI / 180.0;
        double lat2 = 0.0 * M_PI / 180.0;
        double lon2 = 0.0 * M_PI / 180.0;

        double dLon = lon2 - lon1;
        double x = std::sin(dLon) * std::cos(lat2);
        double y = std::cos(lat1) * std::sin(lat2) - std::sin(lat1) * std::cos(lat2) * std::cos(dLon);
        double bearing = std::atan2(x, y) * 180.0 / M_PI;
        bearing = std::fmod(bearing + 360.0, 360.0);

        check("  Bearing to 0,0 is 0-360", bearing >= 0.0 && bearing <= 360.0);
        ss << "    Bearing from GPS to origin: " << std::setprecision(1) << bearing << " deg\n";
    }

    // GPS coordinate precision
    ss << "\n  Coordinate Precision:\n";
    {
        double precision_m = gps.accuracy_m;
        std::string quality = (precision_m < 5.0) ? "HIGH (GPS)" :
                              (precision_m < 20.0) ? "MEDIUM (assisted)" :
                              (precision_m < 100.0) ? "LOW (WiFi/cell)" : "POOR";
        check("  Precision quality: " + quality, true);
        ss << "    Accuracy: " << std::setprecision(1) << precision_m << "m\n";
    }

    ss << "\n  GPS: " << passed << " passed, " << failed << " failed\n\n";
    return failed;
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

int main(int argc, char* argv[]) {
    TestBenchConfig cfg = {};
    cfg.form_factor = FormFactor::DESKTOP;
    cfg.run_streams = true;
    cfg.run_wifi = true;
    cfg.run_network = true;
    cfg.run_gps = true;
    cfg.run_ports = true;
    cfg.run_tunnels = true;
    cfg.verbose = false;

    // Default GPS: Helsinki, Finland (AI2ORBIT HQ)
    cfg.gps.latitude = 60.1699;
    cfg.gps.longitude = 24.9384;
    cfg.gps.altitude_m = 15.0;
    cfg.gps.accuracy_m = 3.0;
    cfg.gps.valid = true;
    cfg.gps.provider = "manual";

    // Parse arguments
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--phone") cfg.form_factor = FormFactor::PHONE;
        else if (arg == "--tablet") cfg.form_factor = FormFactor::TABLET;
        else if (arg == "--desktop") cfg.form_factor = FormFactor::DESKTOP;
        else if (arg == "--verbose" || arg == "-v") cfg.verbose = true;
        else if (arg == "--streams-only") { cfg.run_wifi = false; cfg.run_network = false; cfg.run_gps = false; }
        else if (arg == "--wifi-only") { cfg.run_streams = false; cfg.run_network = false; cfg.run_gps = false; }
        else if (arg == "--network-only") { cfg.run_streams = false; cfg.run_wifi = false; cfg.run_gps = false; }
        else if (arg == "--gps-only") { cfg.run_streams = false; cfg.run_wifi = false; cfg.run_network = false; }
        else if (arg == "--lat" && i + 1 < argc) cfg.gps.latitude = std::stod(argv[++i]);
        else if (arg == "--lon" && i + 1 < argc) cfg.gps.longitude = std::stod(argv[++i]);
        else if (arg == "--alt" && i + 1 < argc) cfg.gps.altitude_m = std::stod(argv[++i]);
        else if (arg == "--help") {
            std::cout << "AI2ORBIT Test Bench v" << VERSION << "\n\n"
                      << "Usage: test_bench [options]\n\n"
                      << "Form Factor:\n"
                      << "  --desktop      Desktop mode (default)\n"
                      << "  --phone        Phone mode\n"
                      << "  --tablet       Tablet mode\n\n"
                      << "Test Selection:\n"
                      << "  --streams-only Virtual streams only\n"
                      << "  --wifi-only    WiFi 802.11 only\n"
                      << "  --network-only Network components only\n"
                      << "  --gps-only     GPS functionality only\n\n"
                      << "GPS:\n"
                      << "  --lat <deg>    Latitude\n"
                      << "  --lon <deg>    Longitude\n"
                      << "  --alt <meters> Altitude\n\n"
                      << "Other:\n"
                      << "  -v, --verbose  Verbose output\n"
                      << "  --help         This message\n";
            return 0;
        }
    }

    // Initialize
    WinsockEngine engine;
    if (!engine.initialize()) {
        std::cerr << "Failed to initialize WinsockEngine\n";
        return 1;
    }

    Logger logger;
    logger.set_level(cfg.verbose ? LogLevel::DEBUG : LogLevel::WARNING);

    auto bench_start = std::chrono::steady_clock::now();
    std::ostringstream report;
    int total_failures = 0;
    int total_tests = 0;

    print_header(report, cfg);

    // Run selected tests
    if (cfg.run_streams) {
        int f = test_virtual_streams(engine, logger, report, cfg.form_factor);
        total_failures += f;
    }

    if (cfg.run_wifi) {
        int f = test_wifi(engine, logger, report);
        total_failures += f;
    }

    if (cfg.run_network) {
        int f = test_network(engine, logger, report);
        total_failures += f;
    }

    if (cfg.run_gps) {
        int f = test_gps(report, cfg.gps);
        total_failures += f;
    }

    auto bench_end = std::chrono::steady_clock::now();
    double duration = std::chrono::duration<double>(bench_end - bench_start).count();

    // Count totals
    std::string full_report = report.str();
    int pass_count = 0, fail_count = 0;
    size_t pos = 0;
    while ((pos = full_report.find("[PASS]", pos)) != std::string::npos) { pass_count++; pos++; }
    pos = 0;
    while ((pos = full_report.find("[FAIL]", pos)) != std::string::npos) { fail_count++; pos++; }

    // Summary
    std::ostringstream summary;
    summary << "================================================================\n";
    summary << "  TEST BENCH SUMMARY\n";
    summary << "================================================================\n";
    summary << "  Form Factor:  " << form_factor_name(cfg.form_factor) << "\n";
    summary << std::fixed << std::setprecision(2);
    summary << "  Duration:     " << duration << " sec\n";
    summary << "  Total Tests:  " << (pass_count + fail_count) << "\n";
    summary << "  Passed:       " << pass_count << "\n";
    summary << "  Failed:       " << fail_count << "\n";
    summary << "  Result:       " << (fail_count == 0 ? "ALL PASSED" : "FAILURES DETECTED") << "\n";
    summary << "================================================================\n";

    std::cout << full_report;
    std::cout << summary.str();

    engine.shutdown();
    return (fail_count == 0) ? 0 : 1;
}
