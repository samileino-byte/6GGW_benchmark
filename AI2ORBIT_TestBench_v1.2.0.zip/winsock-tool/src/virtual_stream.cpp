#include "virtual_stream.h"
#include <cstring>

namespace netswitch {

// ---------------------------------------------------------------------------
// VirtualStream
// ---------------------------------------------------------------------------

VirtualStream::VirtualStream(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger) {}

VirtualStream::~VirtualStream() {
    std::lock_guard<std::mutex> lk(mutex_);
    for (auto& [id, entry] : streams_) {
        entry->listening.store(false);
        if (entry->listener_thread.joinable())
            entry->listener_thread.join();
        if (entry->listener_socket != INVALID_SOCKET)
            engine_.disconnect_socket(entry->listener_socket, true);
    }
    streams_.clear();
}

bool VirtualStream::validate_stream_id(int id, StreamGroup group) const {
    if (group == StreamGroup::SYSTEM)
        return id >= SYSTEM_STREAM_MIN && id <= SYSTEM_STREAM_MAX;
    return id >= APP_STREAM_MIN && id <= APP_STREAM_MAX;
}

bool VirtualStream::open_stream(const StreamConfig& config) {
    if (!validate_stream_id(config.stream_id, config.group)) {
        logger_.error("VStream", "Invalid stream ID " + std::to_string(config.stream_id)
                      + " for group " + (config.group == StreamGroup::SYSTEM ? "SYSTEM(1-6)" : "APP(7+)"));
        return false;
    }

    std::lock_guard<std::mutex> lk(mutex_);
    if (streams_.count(config.stream_id)) {
        logger_.error("VStream", "Stream " + std::to_string(config.stream_id) + " already open");
        return false;
    }

    auto entry = std::make_unique<StreamEntry>();
    entry->config = config;
    entry->stats = {};
    entry->stats.stream_id = config.stream_id;
    entry->stats.created_at = std::chrono::steady_clock::now();
    entry->stats.min_transfer_ms = 1e9;

    streams_[config.stream_id] = std::move(entry);

    emit_event(config.stream_id, "OPENED",
               "group=" + std::string(config.group == StreamGroup::SYSTEM ? "SYSTEM" : "APP")
               + " proto=" + std::to_string(static_cast<int>(config.protocol))
               + " security=" + std::to_string(static_cast<int>(config.security_mode)));

    logger_.info("VStream", "Opened stream " + std::to_string(config.stream_id)
                 + " -> " + config.remote_host + ":" + std::to_string(config.remote_port));
    return true;
}

bool VirtualStream::close_stream(int stream_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it == streams_.end()) return false;

    auto& entry = it->second;
    entry->listening.store(false);
    if (entry->listener_thread.joinable())
        entry->listener_thread.join();
    if (entry->listener_socket != INVALID_SOCKET) {
        engine_.disconnect_socket(entry->listener_socket, true);
        entry->listener_socket = INVALID_SOCKET;
    }

    emit_event(stream_id, "CLOSED", "transfers=" + std::to_string(entry->stats.total_transfers));
    logger_.info("VStream", "Closed stream " + std::to_string(stream_id));
    streams_.erase(it);
    return true;
}

bool VirtualStream::is_stream_open(int stream_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    return streams_.count(stream_id) > 0;
}

SOCKET VirtualStream::ephemeral_connect(const StreamConfig& config) {
    int type = (config.protocol == StreamProtocol::UDP) ? SOCK_DGRAM : SOCK_STREAM;
    int proto = (config.protocol == StreamProtocol::UDP) ? IPPROTO_UDP : IPPROTO_TCP;

    SOCKET sock = engine_.create_socket(AF_INET, type, proto);
    if (sock == INVALID_SOCKET) {
        logger_.error("VStream", "Socket create failed: " + engine_.get_last_error());
        return INVALID_SOCKET;
    }

    engine_.set_linger(sock, true, config.linger_timeout_sec);
    engine_.set_reuse_addr(sock, true);

    if (config.tcp_nodelay && config.protocol != StreamProtocol::UDP)
        engine_.set_nodelay(sock, true);

    if (config.so_keepalive) {
        engine_.set_keepalive(sock, true, config.keepalive_interval_sec);
    }

    if (config.socket_timeout_ms > 0) {
        engine_.set_send_timeout(sock, config.socket_timeout_ms);
        engine_.set_recv_timeout(sock, config.socket_timeout_ms);
    }

    if (!engine_.connect_socket(sock, config.remote_host, config.remote_port, config.socket_timeout_ms)) {
        logger_.error("VStream", "Connect failed to " + config.remote_host + ":"
                      + std::to_string(config.remote_port) + " - " + engine_.get_last_error());
        engine_.force_close(sock);
        return INVALID_SOCKET;
    }

    return sock;
}

void VirtualStream::ephemeral_disconnect(SOCKET sock, const StreamConfig& config) {
    engine_.disconnect_socket(sock, true);
    engine_.cleanup_time_wait(config.remote_port);
}

SOCKET VirtualStream::tunnel_connect(const StreamConfig& config) {
    if (!tunnel_mgr_) {
        logger_.error("VStream", "No TunnelManager set for VPN stream " + std::to_string(config.stream_id));
        return INVALID_SOCKET;
    }

    if (!tunnel_mgr_->is_tunnel_active(config.tunnel_id)) {
        logger_.warning("VStream", "Tunnel " + config.tunnel_id + " not active, starting...");
        if (!tunnel_mgr_->start_tunnel(config.tunnel_id)) {
            logger_.error("VStream", "Failed to start tunnel " + config.tunnel_id);
            return INVALID_SOCKET;
        }
    }

    return ephemeral_connect(config);
}

int VirtualStream::send_all(SOCKET sock, const void* data, size_t len, int timeout_ms) {
    const uint8_t* ptr = static_cast<const uint8_t*>(data);
    size_t sent = 0;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);

    while (sent < len) {
        if (std::chrono::steady_clock::now() > deadline) return -1;

        int n = engine_.send_data(sock, ptr + sent, static_cast<int>(len - sent));
        if (n <= 0) return -1;
        sent += n;
    }
    return static_cast<int>(sent);
}

int VirtualStream::recv_all(SOCKET sock, void* buf, size_t len, int timeout_ms) {
    uint8_t* ptr = static_cast<uint8_t*>(buf);
    size_t received = 0;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);

    while (received < len) {
        if (std::chrono::steady_clock::now() > deadline) break;

        int n = engine_.recv_data(sock, ptr + received, static_cast<int>(len - received));
        if (n <= 0) break;
        received += n;
    }
    return static_cast<int>(received);
}

StreamTransfer VirtualStream::send(int stream_id, const void* data, size_t len) {
    StreamTransfer result = {};
    result.stream_id = stream_id;
    result.transfer_id = next_transfer_id_.fetch_add(1);

    std::unique_lock<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it == streams_.end()) {
        result.success = false;
        result.error = "Stream not open";
        return result;
    }

    auto& entry = *it->second;
    auto config = entry.config;
    lk.unlock();

    std::lock_guard<std::mutex> send_lk(entry.send_mutex);

    auto t_start = std::chrono::steady_clock::now();
    int retries = 0;
    bool sent = false;

    while (retries <= config.max_retries && !sent) {
        SOCKET sock = INVALID_SOCKET;

        if (config.security_mode == StreamSecurityMode::TUNNEL_VPN) {
            sock = tunnel_connect(config);
        } else {
            sock = ephemeral_connect(config);
        }

        if (sock == INVALID_SOCKET) {
            retries++;
            result.socket_opens++;
            continue;
        }
        result.socket_opens++;

        emit_event(stream_id, "SOCKET_OPEN", "retry=" + std::to_string(retries));

        int n = send_all(sock, data, len, config.socket_timeout_ms > 0 ? config.socket_timeout_ms : 5000);
        if (n == static_cast<int>(len)) {
            result.bytes_sent = len;
            sent = true;
        }

        ephemeral_disconnect(sock, config);
        result.socket_closes++;
        emit_event(stream_id, "SOCKET_CLOSE", "bytes=" + std::to_string(n));

        if (!sent) retries++;
    }

    auto t_end = std::chrono::steady_clock::now();
    result.elapsed_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    result.success = sent;
    if (!sent) result.error = "Send failed after " + std::to_string(retries) + " retries";

    lk.lock();
    it = streams_.find(stream_id);
    if (it != streams_.end()) update_stats(*it->second, result);

    return result;
}

StreamTransfer VirtualStream::send_with_response(int stream_id, const void* data, size_t len,
                                                  void* response_buf, size_t response_max,
                                                  size_t& response_len) {
    StreamTransfer result = {};
    result.stream_id = stream_id;
    result.transfer_id = next_transfer_id_.fetch_add(1);
    response_len = 0;

    std::unique_lock<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it == streams_.end()) {
        result.success = false;
        result.error = "Stream not open";
        return result;
    }

    auto& entry = *it->second;
    auto config = entry.config;
    lk.unlock();

    std::lock_guard<std::mutex> send_lk(entry.send_mutex);

    auto t_start = std::chrono::steady_clock::now();
    int retries = 0;
    bool done = false;

    while (retries <= config.max_retries && !done) {
        SOCKET sock = INVALID_SOCKET;

        if (config.security_mode == StreamSecurityMode::TUNNEL_VPN) {
            sock = tunnel_connect(config);
        } else {
            sock = ephemeral_connect(config);
        }

        if (sock == INVALID_SOCKET) {
            retries++;
            result.socket_opens++;
            continue;
        }
        result.socket_opens++;

        emit_event(stream_id, "SOCKET_OPEN", "request-response retry=" + std::to_string(retries));

        int timeout = config.socket_timeout_ms > 0 ? config.socket_timeout_ms : 5000;
        int n_sent = send_all(sock, data, len, timeout);

        if (n_sent == static_cast<int>(len)) {
            result.bytes_sent = len;

            int n_recv = recv_all(sock, response_buf, response_max, timeout);
            if (n_recv > 0) {
                response_len = static_cast<size_t>(n_recv);
                result.bytes_received = response_len;
                done = true;
            }
        }

        ephemeral_disconnect(sock, config);
        result.socket_closes++;
        emit_event(stream_id, "SOCKET_CLOSE", "sent=" + std::to_string(result.bytes_sent)
                   + " recv=" + std::to_string(result.bytes_received));

        if (!done) retries++;
    }

    auto t_end = std::chrono::steady_clock::now();
    result.elapsed_ms = std::chrono::duration<double, std::milli>(t_end - t_start).count();
    result.success = done;
    if (!done) result.error = "Request-response failed after " + std::to_string(retries) + " retries";

    lk.lock();
    it = streams_.find(stream_id);
    if (it != streams_.end()) update_stats(*it->second, result);

    return result;
}

bool VirtualStream::listen_stream(int stream_id, StreamDataCallback on_data) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it == streams_.end()) return false;

    auto& entry = *it->second;
    if (entry.listening.load()) return false;

    entry.listening.store(true);
    entry.listener_thread = std::thread(&VirtualStream::listener_worker, this, stream_id, on_data);
    return true;
}

bool VirtualStream::stop_listening(int stream_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it == streams_.end()) return false;

    auto& entry = *it->second;
    entry.listening.store(false);

    if (entry.listener_socket != INVALID_SOCKET) {
        engine_.force_close(entry.listener_socket);
        entry.listener_socket = INVALID_SOCKET;
    }

    if (entry.listener_thread.joinable())
        entry.listener_thread.join();

    return true;
}

void VirtualStream::listener_worker(int stream_id, StreamDataCallback callback) {
    StreamConfig config;
    {
        std::lock_guard<std::mutex> lk(mutex_);
        auto it = streams_.find(stream_id);
        if (it == streams_.end()) return;
        config = it->second->config;
    }

    int type = (config.protocol == StreamProtocol::UDP) ? SOCK_DGRAM : SOCK_STREAM;
    int proto = (config.protocol == StreamProtocol::UDP) ? IPPROTO_UDP : IPPROTO_TCP;

    SOCKET listen_sock = engine_.create_socket(AF_INET, type, proto);
    if (listen_sock == INVALID_SOCKET) {
        logger_.error("VStream", "Listener socket create failed for stream " + std::to_string(stream_id));
        return;
    }

    engine_.set_reuse_addr(listen_sock, true);
    engine_.set_recv_timeout(listen_sock, 1000);

    struct sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(config.bind_port);
    if (config.bind_address.empty() || config.bind_address == "0.0.0.0") {
        addr.sin_addr.s_addr = INADDR_ANY;
    } else {
        inet_pton(AF_INET, config.bind_address.c_str(), &addr.sin_addr);
    }

    if (bind(listen_sock, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        logger_.error("VStream", "Bind failed on port " + std::to_string(config.bind_port));
        closesocket(listen_sock);
        return;
    }

    if (config.protocol != StreamProtocol::UDP) {
        if (::listen(listen_sock, 16) < 0) {
            logger_.error("VStream", "Listen failed on stream " + std::to_string(stream_id));
            closesocket(listen_sock);
            return;
        }
    }

    {
        std::lock_guard<std::mutex> lk(mutex_);
        auto it = streams_.find(stream_id);
        if (it != streams_.end()) it->second->listener_socket = listen_sock;
    }

    emit_event(stream_id, "LISTENING", "port=" + std::to_string(config.bind_port));
    logger_.info("VStream", "Stream " + std::to_string(stream_id) + " listening on port "
                 + std::to_string(config.bind_port));

    uint8_t buf[65536];

    while (true) {
        {
            std::lock_guard<std::mutex> lk(mutex_);
            auto it = streams_.find(stream_id);
            if (it == streams_.end() || !it->second->listening.load()) break;
        }

        if (config.protocol == StreamProtocol::UDP) {
            int n = engine_.recv_data(listen_sock, buf, sizeof(buf));
            if (n > 0) {
                callback(stream_id, buf, static_cast<size_t>(n));
                emit_event(stream_id, "DATA_RECEIVED", "bytes=" + std::to_string(n));
            }
        } else {
            struct sockaddr_in client_addr = {};
            socklen_t client_len = sizeof(client_addr);
            SOCKET client = accept(listen_sock, reinterpret_cast<struct sockaddr*>(&client_addr), &client_len);
            if (client == INVALID_SOCKET) continue;

            emit_event(stream_id, "SOCKET_ACCEPT", "client=" + std::string(inet_ntoa(client_addr.sin_addr)));

            engine_.set_recv_timeout(client, config.socket_timeout_ms > 0 ? config.socket_timeout_ms : 5000);

            int n = engine_.recv_data(client, buf, sizeof(buf));
            if (n > 0) {
                callback(stream_id, buf, static_cast<size_t>(n));
                emit_event(stream_id, "DATA_RECEIVED", "bytes=" + std::to_string(n));
            }

            engine_.disconnect_socket(client, true);
            emit_event(stream_id, "SOCKET_CLOSE", "client disconnected after transfer");
        }
    }

    closesocket(listen_sock);
    logger_.info("VStream", "Stream " + std::to_string(stream_id) + " listener stopped");
}

StreamConfig VirtualStream::get_config(int stream_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it != streams_.end()) return it->second->config;
    return {};
}

StreamStats VirtualStream::get_stats(int stream_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = streams_.find(stream_id);
    if (it != streams_.end()) return it->second->stats;
    return {};
}

std::vector<int> VirtualStream::get_open_streams() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<int> ids;
    for (auto& [id, _] : streams_) ids.push_back(id);
    return ids;
}

std::vector<int> VirtualStream::get_system_streams() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<int> ids;
    for (auto& [id, entry] : streams_) {
        if (entry->config.group == StreamGroup::SYSTEM) ids.push_back(id);
    }
    return ids;
}

std::vector<int> VirtualStream::get_application_streams() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<int> ids;
    for (auto& [id, entry] : streams_) {
        if (entry->config.group == StreamGroup::APPLICATION) ids.push_back(id);
    }
    return ids;
}

StreamConfig VirtualStream::make_system_stream(int id, const std::string& host, uint16_t port) {
    StreamConfig cfg = {};
    cfg.stream_id = id;
    cfg.group = StreamGroup::SYSTEM;
    cfg.protocol = StreamProtocol::TCP;
    cfg.security_mode = StreamSecurityMode::EPHEMERAL;
    cfg.remote_host = host;
    cfg.remote_port = port;
    cfg.socket_timeout_ms = 5000;
    cfg.max_retries = 2;
    cfg.tcp_nodelay = true;
    cfg.so_keepalive = false;
    cfg.keepalive_interval_sec = 0;
    cfg.linger_timeout_sec = 0;
    return cfg;
}

StreamConfig VirtualStream::make_app_stream(int id, const std::string& host, uint16_t port) {
    StreamConfig cfg = {};
    cfg.stream_id = id;
    cfg.group = StreamGroup::APPLICATION;
    cfg.protocol = StreamProtocol::TCP;
    cfg.security_mode = StreamSecurityMode::EPHEMERAL;
    cfg.remote_host = host;
    cfg.remote_port = port;
    cfg.socket_timeout_ms = 10000;
    cfg.max_retries = 3;
    cfg.tcp_nodelay = true;
    cfg.so_keepalive = false;
    cfg.keepalive_interval_sec = 0;
    cfg.linger_timeout_sec = 0;
    return cfg;
}

StreamConfig VirtualStream::make_vpn_stream(int id, const std::string& host, uint16_t port,
                                             const std::string& tunnel_id) {
    StreamConfig cfg = {};
    cfg.stream_id = id;
    cfg.group = (id >= SYSTEM_STREAM_MIN && id <= SYSTEM_STREAM_MAX)
                    ? StreamGroup::SYSTEM : StreamGroup::APPLICATION;
    cfg.protocol = StreamProtocol::TLS_TCP;
    cfg.security_mode = StreamSecurityMode::TUNNEL_VPN;
    cfg.remote_host = host;
    cfg.remote_port = port;
    cfg.socket_timeout_ms = 10000;
    cfg.max_retries = 3;
    cfg.tcp_nodelay = true;
    cfg.so_keepalive = true;
    cfg.keepalive_interval_sec = 30;
    cfg.linger_timeout_sec = 2;
    cfg.tunnel_id = tunnel_id;
    return cfg;
}

void VirtualStream::emit_event(int stream_id, const std::string& event, const std::string& detail) {
    logger_.debug("VStream", "stream=" + std::to_string(stream_id) + " event=" + event + " " + detail);
    if (event_callback_) event_callback_(stream_id, event, detail);
}

void VirtualStream::update_stats(StreamEntry& entry, const StreamTransfer& transfer) {
    auto& s = entry.stats;
    s.total_transfers++;
    if (transfer.success) {
        s.successful_transfers++;
    } else {
        s.failed_transfers++;
    }
    s.total_bytes_sent += transfer.bytes_sent;
    s.total_bytes_received += transfer.bytes_received;
    s.total_socket_opens += transfer.socket_opens;
    s.total_socket_closes += transfer.socket_closes;

    double total_ms = s.avg_transfer_ms * (s.total_transfers - 1) + transfer.elapsed_ms;
    s.avg_transfer_ms = total_ms / s.total_transfers;

    if (transfer.elapsed_ms < s.min_transfer_ms) s.min_transfer_ms = transfer.elapsed_ms;
    if (transfer.elapsed_ms > s.max_transfer_ms) s.max_transfer_ms = transfer.elapsed_ms;

    s.last_transfer_at = std::chrono::steady_clock::now();
}

// ---------------------------------------------------------------------------
// VirtualStreamPipe
// ---------------------------------------------------------------------------

VirtualStreamPipe::VirtualStreamPipe(VirtualStream& vs, int from_stream, int to_stream, Logger& logger)
    : vs_(vs), from_stream_(from_stream), to_stream_(to_stream), logger_(logger) {}

VirtualStreamPipe::~VirtualStreamPipe() {
    stop();
}

bool VirtualStreamPipe::start() {
    if (running_.load()) return false;

    if (!vs_.is_stream_open(from_stream_) || !vs_.is_stream_open(to_stream_)) {
        logger_.error("VStreamPipe", "Source or destination stream not open");
        return false;
    }

    running_.store(true);
    pipe_thread_ = std::thread(&VirtualStreamPipe::pipe_worker, this);

    logger_.info("VStreamPipe", "Pipe started: stream " + std::to_string(from_stream_)
                 + " -> stream " + std::to_string(to_stream_));
    return true;
}

bool VirtualStreamPipe::stop() {
    if (!running_.load()) return false;
    running_.store(false);

    vs_.stop_listening(from_stream_);

    if (pipe_thread_.joinable())
        pipe_thread_.join();

    logger_.info("VStreamPipe", "Pipe stopped: " + std::to_string(stats_.messages_forwarded) + " messages forwarded");
    return true;
}

void VirtualStreamPipe::pipe_worker() {
    vs_.listen_stream(from_stream_, [this](int /*stream_id*/, const uint8_t* data, size_t len) {
        if (!running_.load()) return;

        auto t_start = std::chrono::steady_clock::now();
        auto result = vs_.send(to_stream_, data, len);
        auto t_end = std::chrono::steady_clock::now();

        double latency = std::chrono::duration<double, std::milli>(t_end - t_start).count();

        if (result.success) {
            stats_.messages_forwarded++;
            stats_.bytes_forwarded += len;
            double total = stats_.avg_latency_ms * (stats_.messages_forwarded - 1) + latency;
            stats_.avg_latency_ms = total / stats_.messages_forwarded;
        } else {
            stats_.errors++;
            logger_.warning("VStreamPipe", "Forward failed: " + result.error);
        }
    });
}

} // namespace netswitch
