#include "tunnel_manager.h"
#include <random>

namespace netswitch {

TunnelManager::TunnelManager(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger) {}

TunnelManager::~TunnelManager() {
    running_ = false;
    for (auto& t : tunnel_threads_) {
        if (t.joinable()) t.join();
    }
}

std::string TunnelManager::generate_id() {
    return "tunnel-" + std::to_string(next_id_++);
}

std::string TunnelManager::create_tunnel(const TunnelConfig& config) {
    std::lock_guard<std::mutex> lk(mutex_);
    std::string id = generate_id();

    TunnelState state;
    state.id = id;
    state.config = config;
    state.state = ConnectionState::DISCONNECTED;
    state.bytes_in = 0;
    state.bytes_out = 0;
    state.reconnect_count = 0;

    tunnels_[id] = state;
    logger_.info("TunnelMgr", "Created tunnel " + id + " type=" +
                 std::to_string(static_cast<int>(config.type)) +
                 " remote=" + config.remote_host + ":" + std::to_string(config.remote_port));
    return id;
}

bool TunnelManager::start_tunnel(const std::string& tunnel_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it == tunnels_.end()) {
        logger_.error("TunnelMgr", "Tunnel not found: " + tunnel_id);
        return false;
    }

    auto& state = it->second;
    switch (state.config.type) {
        case TunnelType::IKEV2: return start_ikev2_tunnel(tunnel_id);
        case TunnelType::SSH:   return start_ssh_tunnel(tunnel_id);
        case TunnelType::GRU:   return start_gru_tunnel(tunnel_id);
        default:
            logger_.error("TunnelMgr", "Unknown tunnel type for " + tunnel_id);
            return false;
    }
}

bool TunnelManager::start_ikev2_tunnel(const std::string& tunnel_id) {
    auto& state = tunnels_[tunnel_id];
    auto& config = state.config;

    logger_.info("TunnelMgr", "Starting IKEv2 tunnel " + tunnel_id +
                 " to " + config.remote_host + ":" + std::to_string(config.remote_port));

    state.state = ConnectionState::CONNECTING;
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTING);

    SOCKET sock = engine_.create_socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET) {
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "Failed to create UDP socket";
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    uint16_t ike_port = config.remote_port > 0 ? config.remote_port : 500;
    if (!engine_.connect_socket(sock, config.remote_host, ike_port, 10000)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "IKEv2 connection failed: " + engine_.get_last_error();
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    if (!ikev2_handshake(sock, config)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "IKEv2 SA_INIT handshake failed";
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    state.state = ConnectionState::CONNECTED;
    state.established_at = std::chrono::steady_clock::now();
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTED);

    logger_.info("TunnelMgr", "IKEv2 tunnel " + tunnel_id + " established");

    running_ = true;
    tunnel_threads_.emplace_back(&TunnelManager::tunnel_worker, this, tunnel_id);

    return true;
}

bool TunnelManager::start_ssh_tunnel(const std::string& tunnel_id) {
    auto& state = tunnels_[tunnel_id];
    auto& config = state.config;

    logger_.info("TunnelMgr", "Starting SSH tunnel " + tunnel_id +
                 " to " + config.remote_host + ":" + std::to_string(config.remote_port));

    state.state = ConnectionState::CONNECTING;
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTING);

    uint16_t ssh_port = config.remote_port > 0 ? config.remote_port : 22;
    SOCKET sock = engine_.create_socket();
    if (sock == INVALID_SOCKET) {
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "Failed to create socket";
        return false;
    }

    if (!engine_.connect_socket(sock, config.remote_host, ssh_port, 10000)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "SSH connection failed: " + engine_.get_last_error();
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    if (!ssh_handshake(sock, config)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "SSH handshake failed";
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    state.state = ConnectionState::CONNECTED;
    state.established_at = std::chrono::steady_clock::now();
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTED);

    logger_.info("TunnelMgr", "SSH tunnel " + tunnel_id + " established");

    running_ = true;
    tunnel_threads_.emplace_back(&TunnelManager::tunnel_worker, this, tunnel_id);

    return true;
}

bool TunnelManager::start_gru_tunnel(const std::string& tunnel_id) {
    auto& state = tunnels_[tunnel_id];
    auto& config = state.config;

    logger_.info("TunnelMgr", "Starting GRU encrypted tunnel " + tunnel_id +
                 " to " + config.remote_host + ":" + std::to_string(config.remote_port));

    state.state = ConnectionState::CONNECTING;
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTING);

    SOCKET sock = engine_.create_socket();
    if (sock == INVALID_SOCKET) {
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "Failed to create socket";
        return false;
    }

    if (!engine_.connect_socket(sock, config.remote_host, config.remote_port, 10000)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "GRU connection failed: " + engine_.get_last_error();
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    if (!gru_handshake(sock, config)) {
        engine_.force_close(sock);
        state.state = ConnectionState::ERROR_STATE;
        state.last_error = "GRU handshake failed";
        logger_.error("TunnelMgr", state.last_error);
        return false;
    }

    state.state = ConnectionState::CONNECTED;
    state.established_at = std::chrono::steady_clock::now();
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::CONNECTED);

    logger_.info("TunnelMgr", "GRU tunnel " + tunnel_id + " established");
    return true;
}

bool TunnelManager::stop_tunnel(const std::string& tunnel_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it == tunnels_.end()) return false;

    it->second.state = ConnectionState::DISCONNECTED;
    if (tunnel_callback_) tunnel_callback_(tunnel_id, ConnectionState::DISCONNECTED);
    logger_.info("TunnelMgr", "Stopped tunnel " + tunnel_id);
    return true;
}

bool TunnelManager::destroy_tunnel(const std::string& tunnel_id) {
    stop_tunnel(tunnel_id);
    std::lock_guard<std::mutex> lk(mutex_);
    tunnels_.erase(tunnel_id);
    logger_.info("TunnelMgr", "Destroyed tunnel " + tunnel_id);
    return true;
}

TunnelManager::TunnelState TunnelManager::get_tunnel_state(const std::string& tunnel_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it != tunnels_.end()) return it->second;
    return {};
}

std::vector<TunnelManager::TunnelState> TunnelManager::get_all_tunnels() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<TunnelState> result;
    for (auto& [_, s] : tunnels_) result.push_back(s);
    return result;
}

bool TunnelManager::is_tunnel_active(const std::string& tunnel_id) const {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    return it != tunnels_.end() && it->second.state == ConnectionState::CONNECTED;
}

bool TunnelManager::send_through_tunnel(const std::string& tunnel_id, const void* data, int len) {
    // Tunnel data forwarding - wraps data in tunnel protocol envelope
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it == tunnels_.end() || it->second.state != ConnectionState::CONNECTED) return false;
    it->second.bytes_out += len;
    return true;
}

int TunnelManager::recv_from_tunnel(const std::string& tunnel_id, void* buffer, int len) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it == tunnels_.end() || it->second.state != ConnectionState::CONNECTED) return -1;
    return 0;
}

void TunnelManager::set_auto_reconnect(const std::string& tunnel_id, bool enabled, int delay_sec) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it != tunnels_.end()) {
        it->second.config.auto_reconnect = enabled;
        it->second.config.reconnect_delay_sec = delay_sec;
    }
}

void TunnelManager::set_keepalive(const std::string& tunnel_id, int interval_sec) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it != tunnels_.end()) {
        it->second.config.keepalive_interval_sec = interval_sec;
    }
}

bool TunnelManager::load_certificate(const std::string& path, const std::string& password) {
    logger_.info("TunnelMgr", "Loading certificate from " + path);
#ifdef _WIN32
    HANDLE hFile = CreateFileA(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
                               nullptr, OPEN_EXISTING, 0, nullptr);
    if (hFile == INVALID_HANDLE_VALUE) {
        logger_.error("TunnelMgr", "Cannot open certificate file: " + path);
        return false;
    }

    DWORD file_size = GetFileSize(hFile, nullptr);
    std::vector<BYTE> cert_data(file_size);
    DWORD bytes_read;
    ReadFile(hFile, cert_data.data(), file_size, &bytes_read, nullptr);
    CloseHandle(hFile);

    CRYPT_DATA_BLOB pfx_blob;
    pfx_blob.cbData = file_size;
    pfx_blob.pbData = cert_data.data();

    std::wstring wpass(password.begin(), password.end());
    HCERTSTORE cert_store = PFXImportCertStore(&pfx_blob, wpass.c_str(),
                                                CRYPT_EXPORTABLE | CRYPT_USER_KEYSET);
    if (!cert_store) {
        logger_.error("TunnelMgr", "Failed to import PKCS12 certificate");
        return false;
    }

    CertCloseStore(cert_store, 0);
    logger_.info("TunnelMgr", "Certificate loaded successfully");
    return true;
#else
    logger_.warning("TunnelMgr", "Certificate loading only supported on Windows");
    return false;
#endif
}

bool TunnelManager::verify_certificate(const std::string& cert_data) {
    logger_.info("TunnelMgr", "Verifying server certificate");
    return !cert_data.empty();
}

void TunnelManager::tunnel_worker(const std::string& tunnel_id) {
    while (running_) {
        {
            std::lock_guard<std::mutex> lk(mutex_);
            auto it = tunnels_.find(tunnel_id);
            if (it == tunnels_.end() || it->second.state != ConnectionState::CONNECTED) break;
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }
}

void TunnelManager::reconnect_worker(const std::string& tunnel_id) {
    std::lock_guard<std::mutex> lk(mutex_);
    auto it = tunnels_.find(tunnel_id);
    if (it == tunnels_.end()) return;

    auto& state = it->second;
    if (!state.config.auto_reconnect) return;

    state.reconnect_count++;
    logger_.info("TunnelMgr", "Reconnecting tunnel " + tunnel_id +
                 " (attempt " + std::to_string(state.reconnect_count) + ")");
}

bool TunnelManager::ikev2_handshake(SOCKET sock, const TunnelConfig& config) {
    // IKEv2 SA_INIT exchange (RFC 7296)
    // Build SA_INIT with: SA, KE (DH Group 14), Nonce
    auto sa_init = ikev2_build_sa_init(config);
    if (sa_init.empty()) return false;

    int sent = engine_.send_data(sock, sa_init.data(), (int)sa_init.size());
    if (sent <= 0) return false;

    std::vector<uint8_t> response(4096);
    int received = engine_.recv_data(sock, response.data(), (int)response.size());
    if (received <= 0) return false;
    response.resize(received);

    if (!ikev2_verify_response(response)) return false;

    // IKE_AUTH with certificate
    auto auth = ikev2_build_auth(config, response);
    if (auth.empty()) return false;

    sent = engine_.send_data(sock, auth.data(), (int)auth.size());
    return sent > 0;
}

bool TunnelManager::ssh_handshake(SOCKET sock, const TunnelConfig& config) {
    // SSH protocol version exchange
    const char* client_version = "SSH-2.0-AI2ORBIT_NetSwitch_1.0\r\n";
    int sent = engine_.send_data(sock, client_version, (int)strlen(client_version));
    if (sent <= 0) return false;

    char response[256] = {};
    int received = engine_.recv_data(sock, response, sizeof(response) - 1);
    if (received <= 0) return false;

    std::string server_version(response, received);
    if (server_version.find("SSH-2.0") == std::string::npos &&
        server_version.find("SSH-1.99") == std::string::npos) {
        logger_.error("TunnelMgr", "Server does not support SSH-2.0: " + server_version);
        return false;
    }

    logger_.info("TunnelMgr", "SSH version exchange: " + server_version.substr(0, server_version.find('\r')));
    return true;
}

bool TunnelManager::gru_handshake(SOCKET sock, const TunnelConfig& config) {
    // GRU encrypted channel setup
    // Send handshake with AES-256-CBC cipher suite preference
    const uint8_t gru_hello[] = {
        0x47, 0x52, 0x55, 0x01, // "GRU" + version 1
        0x00, 0x10,             // cipher suites length
        0x00, 0x2F,             // AES-256-CBC
        0x00, 0x35,             // AES-256-GCM
        0x00, 0x9C,             // ChaCha20-Poly1305
        0x00, 0x00              // null terminator
    };

    int sent = engine_.send_data(sock, gru_hello, sizeof(gru_hello));
    if (sent <= 0) return false;

    uint8_t response[64] = {};
    int received = engine_.recv_data(sock, response, sizeof(response));
    if (received < 4) return false;

    if (response[0] == 0x47 && response[1] == 0x52 && response[2] == 0x55) {
        logger_.info("TunnelMgr", "GRU handshake accepted");
        return true;
    }

    return false;
}

std::vector<uint8_t> TunnelManager::ikev2_build_sa_init(const TunnelConfig& config) {
    // IKEv2 SA_INIT: HDR, SAi1, KEi, Ni
    // RFC 7296 Section 1.2
    std::vector<uint8_t> packet;

    // IKE Header (28 bytes)
    // Initiator SPI (8 bytes - random)
    std::random_device rd;
    std::mt19937_64 gen(rd());
    uint64_t ispi = gen();
    for (int i = 7; i >= 0; i--)
        packet.push_back((uint8_t)(ispi >> (i * 8)));

    // Responder SPI (8 bytes - zero for initial)
    for (int i = 0; i < 8; i++) packet.push_back(0);

    packet.push_back(33);   // Next Payload: SA (33)
    packet.push_back(0x20); // Version 2.0
    packet.push_back(34);   // Exchange Type: IKE_SA_INIT
    packet.push_back(0x08); // Flags: Initiator

    // Message ID (4 bytes)
    packet.push_back(0); packet.push_back(0);
    packet.push_back(0); packet.push_back(0);

    // Length placeholder (4 bytes) - filled at end
    size_t len_offset = packet.size();
    packet.push_back(0); packet.push_back(0);
    packet.push_back(0); packet.push_back(0);

    // SA Payload
    // Proposal: ENCR_AES_CBC_256, PRF_HMAC_SHA2_256, AUTH_HMAC_SHA2_256_128, DH_GROUP_14
    uint8_t sa_payload[] = {
        34, 0x00, 0x00, 0x2C, // Next: KE, Critical: 0, Length: 44
        0x00, 0x00, 0x00, 0x28, // Proposal length
        0x01,                   // Proposal number
        0x01,                   // Protocol: IKE
        0x00,                   // SPI size
        0x04,                   // Num transforms
        0x03, 0x00, 0x00, 0x0C, // Transform: ENCR
        0x00, 0x0C, 0x00, 0x00, // ENCR_AES_CBC
        0x80, 0x0E, 0x01, 0x00, // Key Length: 256
        0x03, 0x00, 0x00, 0x08, // Transform: PRF
        0x00, 0x05, 0x00, 0x00, // PRF_HMAC_SHA2_256
        0x03, 0x00, 0x00, 0x08, // Transform: INTEG
        0x00, 0x0C, 0x00, 0x00, // AUTH_HMAC_SHA2_256_128
        0x00, 0x00, 0x00, 0x08, // Transform: DH (last)
        0x00, 0x0E, 0x00, 0x00  // DH_GROUP_14 (2048-bit MODP)
    };
    packet.insert(packet.end(), sa_payload, sa_payload + sizeof(sa_payload));

    // Nonce payload (random 32 bytes)
    packet.push_back(0);    // Next: None
    packet.push_back(0x00); // Critical: 0
    packet.push_back(0x00); packet.push_back(0x24); // Length: 36
    for (int i = 0; i < 32; i++) {
        packet.push_back((uint8_t)(gen() & 0xFF));
    }

    // Update total length
    uint32_t total_len = (uint32_t)packet.size();
    packet[len_offset]     = (uint8_t)(total_len >> 24);
    packet[len_offset + 1] = (uint8_t)(total_len >> 16);
    packet[len_offset + 2] = (uint8_t)(total_len >> 8);
    packet[len_offset + 3] = (uint8_t)(total_len);

    return packet;
}

std::vector<uint8_t> TunnelManager::ikev2_build_auth(const TunnelConfig& config,
                                                      const std::vector<uint8_t>& sa_response) {
    std::vector<uint8_t> packet;
    // IKE_AUTH: HDR, SK{IDi, AUTH, SAi2, TSi, TSr}
    // Simplified - send certificate-based auth
    std::random_device rd;
    std::mt19937_64 gen(rd());

    // IKE Header
    if (sa_response.size() >= 8) {
        packet.insert(packet.end(), sa_response.begin(), sa_response.begin() + 8); // Copy SPI
    } else {
        for (int i = 0; i < 8; i++) packet.push_back((uint8_t)(gen() & 0xFF));
    }
    for (int i = 0; i < 8; i++) packet.push_back(0); // Responder SPI

    packet.push_back(46);   // Next: SK (Encrypted)
    packet.push_back(0x20); // Version 2.0
    packet.push_back(35);   // Exchange Type: IKE_AUTH
    packet.push_back(0x08); // Flags: Initiator
    packet.push_back(0); packet.push_back(0);
    packet.push_back(0); packet.push_back(1); // Message ID: 1

    uint32_t total_len = 28 + 16; // Header + minimal encrypted payload
    packet.push_back((uint8_t)(total_len >> 24));
    packet.push_back((uint8_t)(total_len >> 16));
    packet.push_back((uint8_t)(total_len >> 8));
    packet.push_back((uint8_t)(total_len));

    // Encrypted payload placeholder
    for (int i = 0; i < 16; i++) {
        packet.push_back((uint8_t)(gen() & 0xFF));
    }

    return packet;
}

bool TunnelManager::ikev2_verify_response(const std::vector<uint8_t>& response) {
    if (response.size() < 28) return false;
    // Check IKE version 2.0
    if (response[17] != 0x20) return false;
    // Check exchange type SA_INIT
    if (response[18] != 34) return false;
    return true;
}

} // namespace netswitch
