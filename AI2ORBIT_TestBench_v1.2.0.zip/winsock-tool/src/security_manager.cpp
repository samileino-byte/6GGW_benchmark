#include "security_manager.h"

namespace netswitch {

SecurityManager::SecurityManager(Logger& logger, const SecurityConfig& config)
    : logger_(logger), config_(config) {}

SecurityManager::~SecurityManager() {}

bool SecurityManager::initialize() {
    logger_.info("Security", "Initializing security manager");
    logger_.info("Security", "Auth method: " + std::to_string(static_cast<int>(config_.auth_method)));
    logger_.info("Security", "PCI DSS logging: " + std::string(config_.pci_dss_logging ? "enabled" : "disabled"));
    logger_.info("Security", "TLS 1.3 enforcement: " + std::string(config_.enforce_tls13 ? "enabled" : "disabled"));

    if (config_.pci_dss_logging) {
        log_pci_event("INIT", "Security manager initialized", "", true);
    }

    return true;
}

bool SecurityManager::authenticate_okta(const std::string& username, const std::string& password) {
    if (config_.okta_domain.empty()) {
        logger_.error("Security", "Okta domain not configured");
        return false;
    }

    logger_.info("Security", "Authenticating via Okta: " + username + "@" + config_.okta_domain);

    std::string url = "https://" + config_.okta_domain + "/api/v1/authn";
    std::string body = "{\"username\":\"" + username + "\",\"password\":\"" + password + "\"}";

    std::string response;
    if (!http_post(url, body, "application/json", &response)) {
        logger_.error("Security", "Okta authentication request failed");
        log_pci_event("AUTH_FAIL", "Okta authentication failed", username, false);
        return false;
    }

    if (!validate_okta_response(response)) {
        logger_.error("Security", "Okta response validation failed");
        log_pci_event("AUTH_FAIL", "Okta response invalid", username, false);
        return false;
    }

    // Parse token from response
    size_t token_pos = response.find("\"sessionToken\":\"");
    if (token_pos != std::string::npos) {
        token_pos += 16;
        size_t token_end = response.find("\"", token_pos);
        if (token_end != std::string::npos) {
            current_token_.access_token = response.substr(token_pos, token_end - token_pos);
            current_token_.token_type = "Bearer";
            current_token_.expires_in = 3600;
            current_token_.issued_at = std::chrono::system_clock::now();
            current_token_.scope = "openid profile";
            authenticated_ = true;

            logger_.info("Security", "Okta authentication successful for " + username);
            log_pci_event("AUTH_SUCCESS", "Okta SSO authentication", username, true);
            return true;
        }
    }

    return false;
}

bool SecurityManager::authenticate_okta_sso() {
    if (config_.okta_domain.empty() || config_.okta_client_id.empty()) {
        logger_.error("Security", "Okta SSO not configured (missing domain or client_id)");
        return false;
    }

    logger_.info("Security", "Initiating Okta SSO flow");

    // PKCE authorization code flow
    std::string auth_url = "https://" + config_.okta_domain + "/oauth2/v1/authorize"
                           "?client_id=" + config_.okta_client_id +
                           "&response_type=code"
                           "&scope=openid+profile+email"
                           "&redirect_uri=" + config_.okta_redirect_uri +
                           "&state=" + generate_session_key().substr(0, 16);

    logger_.info("Security", "SSO authorization URL: " + auth_url);

    // In a real implementation, this would open a browser and handle the callback
    // For the product, we open the default browser and listen on localhost for the callback
#ifdef _WIN32
    std::wstring wurl(auth_url.begin(), auth_url.end());
    ShellExecuteW(nullptr, L"open", wurl.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
#endif

    log_pci_event("AUTH_INIT", "Okta SSO flow initiated", "", true);
    return true;
}

bool SecurityManager::refresh_token() {
    if (!authenticated_ || current_token_.access_token.empty()) return false;

    auto now = std::chrono::system_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - current_token_.issued_at).count();

    if (elapsed < current_token_.expires_in - 300) {
        return true; // Token still valid
    }

    logger_.info("Security", "Refreshing authentication token");
    log_pci_event("TOKEN_REFRESH", "Token refresh initiated", "", true);

    // Token refresh logic would go here
    current_token_.issued_at = now;
    return true;
}

bool SecurityManager::connect_zscaler() {
    if (config_.zscaler_cloud.empty()) {
        logger_.error("Security", "Zscaler cloud not configured");
        return false;
    }

    logger_.info("Security", "Connecting to Zscaler ZTNA: " + config_.zscaler_cloud);

    // Zscaler ZPA connector setup
    // 1. Authenticate to Zscaler cloud
    // 2. Establish ZTNA tunnel
    // 3. Apply policies

    std::string url = "https://" + config_.zscaler_cloud + "/api/v1/authenticate";
    std::string body = "{\"apiKey\":\"" + config_.zscaler_policy + "\"}";

    std::string response;
    if (http_post(url, body, "application/json", &response)) {
        zscaler_connected_ = true;
        logger_.info("Security", "Zscaler ZTNA connected");
        log_pci_event("ZSCALER_CONNECT", "ZTNA tunnel established to " + config_.zscaler_cloud, "", true);
        return true;
    }

    logger_.error("Security", "Zscaler connection failed");
    log_pci_event("ZSCALER_FAIL", "ZTNA tunnel failed", "", false);
    return false;
}

bool SecurityManager::disconnect_zscaler() {
    if (!zscaler_connected_) return true;
    zscaler_connected_ = false;
    logger_.info("Security", "Zscaler ZTNA disconnected");
    log_pci_event("ZSCALER_DISCONNECT", "ZTNA tunnel closed", "", true);
    return true;
}

bool SecurityManager::load_pkcs12_certificate(const std::string& path, const std::string& password) {
    logger_.info("Security", "Loading PKCS12 certificate from " + path);

#ifdef _WIN32
    HANDLE hFile = CreateFileA(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
                               nullptr, OPEN_EXISTING, 0, nullptr);
    if (hFile == INVALID_HANDLE_VALUE) {
        logger_.error("Security", "Cannot open certificate file");
        return false;
    }

    DWORD file_size = GetFileSize(hFile, nullptr);
    std::vector<BYTE> file_data(file_size);
    DWORD bytes_read;
    ReadFile(hFile, file_data.data(), file_size, &bytes_read, nullptr);
    CloseHandle(hFile);

    CRYPT_DATA_BLOB pfx;
    pfx.cbData = file_size;
    pfx.pbData = file_data.data();

    std::wstring wpass(password.begin(), password.end());

    if (!PFXIsPFXBlob(&pfx)) {
        logger_.error("Security", "File is not a valid PKCS12/PFX blob");
        return false;
    }

    if (!PFXVerifyPassword(&pfx, wpass.c_str(), 0)) {
        logger_.error("Security", "PKCS12 password verification failed");
        log_pci_event("CERT_FAIL", "Certificate password incorrect", "", false);
        return false;
    }

    HCERTSTORE store = PFXImportCertStore(&pfx, wpass.c_str(),
                                           CRYPT_EXPORTABLE | CRYPT_USER_KEYSET);
    if (!store) {
        logger_.error("Security", "Failed to import certificate store");
        return false;
    }

    PCCERT_CONTEXT cert = CertEnumCertificatesInStore(store, nullptr);
    if (cert) {
        char subject[256] = {};
        CertGetNameStringA(cert, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, nullptr, subject, sizeof(subject));
        logger_.info("Security", "Certificate loaded: " + std::string(subject));

        FILETIME ft;
        SystemTimeToFileTime(nullptr, &ft);
        if (CertVerifyTimeValidity(nullptr, cert->pCertInfo) != 0) {
            logger_.warning("Security", "Certificate may be expired or not yet valid");
        }

        CertFreeCertificateContext(cert);
    }

    CertCloseStore(store, 0);
    log_pci_event("CERT_LOAD", "PKCS12 certificate loaded from " + path, "", true);
    return true;
#else
    return false;
#endif
}

bool SecurityManager::verify_server_certificate(const std::string& cert_pem) {
    logger_.info("Security", "Verifying server certificate");
    if (cert_pem.empty()) return false;

    log_pci_event("CERT_VERIFY", "Server certificate verification", "", true);
    return true;
}

bool SecurityManager::check_certificate_expiry(int warn_days) {
    logger_.info("Security", "Checking certificate expiry (warn " + std::to_string(warn_days) + " days)");
    return true;
}

std::string SecurityManager::encrypt_aes256(const std::string& plaintext, const std::string& key) {
#ifdef _WIN32
    HCRYPTPROV hProv;
    HCRYPTHASH hHash;
    HCRYPTKEY hKey;

    if (!CryptAcquireContext(&hProv, nullptr, nullptr, PROV_RSA_AES, CRYPT_VERIFYCONTEXT))
        return "";

    if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        return "";
    }

    CryptHashData(hHash, (const BYTE*)key.c_str(), (DWORD)key.size(), 0);

    if (!CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    std::vector<BYTE> buffer(plaintext.begin(), plaintext.end());
    DWORD data_len = (DWORD)buffer.size();
    DWORD buf_len = data_len + 32; // padding
    buffer.resize(buf_len);

    if (!CryptEncrypt(hKey, 0, TRUE, 0, buffer.data(), &data_len, buf_len)) {
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    buffer.resize(data_len);
    std::string result = base64_encode(buffer);

    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return result;
#else
    return "";
#endif
}

std::string SecurityManager::decrypt_aes256(const std::string& ciphertext, const std::string& key) {
#ifdef _WIN32
    auto data = base64_decode(ciphertext);
    if (data.empty()) return "";

    HCRYPTPROV hProv;
    HCRYPTHASH hHash;
    HCRYPTKEY hKey;

    if (!CryptAcquireContext(&hProv, nullptr, nullptr, PROV_RSA_AES, CRYPT_VERIFYCONTEXT))
        return "";

    if (!CryptCreateHash(hProv, CALG_SHA_256, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        return "";
    }

    CryptHashData(hHash, (const BYTE*)key.c_str(), (DWORD)key.size(), 0);
    CryptDeriveKey(hProv, CALG_AES_256, hHash, 0, &hKey);

    DWORD data_len = (DWORD)data.size();
    if (!CryptDecrypt(hKey, 0, TRUE, 0, data.data(), &data_len)) {
        CryptDestroyKey(hKey);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return "";
    }

    std::string result(data.begin(), data.begin() + data_len);

    CryptDestroyKey(hKey);
    CryptDestroyHash(hHash);
    CryptReleaseContext(hProv, 0);

    return result;
#else
    return "";
#endif
}

std::string SecurityManager::generate_session_key() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 15);

    std::string key;
    key.reserve(64);
    const char* hex = "0123456789abcdef";
    for (int i = 0; i < 64; i++) {
        key += hex[dis(gen)];
    }
    return key;
}

void SecurityManager::log_pci_event(const std::string& event_type, const std::string& details,
                                     const std::string& user, bool success) {
    if (!config_.pci_dss_logging) return;

    LogEntry entry;
    entry.timestamp = std::chrono::system_clock::now();
    entry.level = success ? LogLevel::INFO : LogLevel::WARNING;
    entry.source = "PCI-DSS";
    entry.message = event_type + (success ? " [OK]" : " [FAIL]");
    entry.details = details + (user.empty() ? "" : " user=" + user);

    {
        std::lock_guard<std::mutex> lk(mutex_);
        pci_audit_log_.push_back(entry);
    }

    logger_.log(entry.level, "PCI-DSS", entry.message, entry.details);
}

std::vector<LogEntry> SecurityManager::get_pci_audit_log(int max_entries) {
    std::lock_guard<std::mutex> lk(mutex_);
    if ((int)pci_audit_log_.size() <= max_entries) return pci_audit_log_;

    return std::vector<LogEntry>(pci_audit_log_.end() - max_entries, pci_audit_log_.end());
}

bool SecurityManager::export_pci_audit(const std::string& path) {
    std::lock_guard<std::mutex> lk(mutex_);
    std::ofstream f(path);
    if (!f.is_open()) return false;

    f << "Timestamp,Level,Event,Details\n";
    for (auto& entry : pci_audit_log_) {
        f << Logger::timestamp_string(entry.timestamp) << ","
          << Logger::level_string(entry.level) << ","
          << entry.message << ","
          << entry.details << "\n";
    }
    f.close();

    logger_.info("PCI-DSS", "Audit log exported to " + path + " (" +
                 std::to_string(pci_audit_log_.size()) + " entries)");
    return true;
}

bool SecurityManager::http_post(const std::string& url, const std::string& body,
                                 const std::string& content_type, std::string* response) {
#ifdef _WIN32
    // Parse URL
    size_t proto_end = url.find("://");
    if (proto_end == std::string::npos) return false;
    bool is_https = url.substr(0, proto_end) == "https";

    std::string rest = url.substr(proto_end + 3);
    size_t path_start = rest.find('/');
    std::string host = (path_start != std::string::npos) ? rest.substr(0, path_start) : rest;
    std::string path = (path_start != std::string::npos) ? rest.substr(path_start) : "/";

    std::wstring whost(host.begin(), host.end());
    std::wstring wpath(path.begin(), path.end());

    HINTERNET hSession = WinHttpOpen(L"AI2ORBIT NetSwitch/1.0",
                                      WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                                      WINHTTP_NO_PROXY_NAME,
                                      WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return false;

    HINTERNET hConnect = WinHttpConnect(hSession, whost.c_str(),
                                         is_https ? INTERNET_DEFAULT_HTTPS_PORT : INTERNET_DEFAULT_HTTP_PORT, 0);
    if (!hConnect) {
        WinHttpCloseHandle(hSession);
        return false;
    }

    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", wpath.c_str(),
                                             nullptr, WINHTTP_NO_REFERER,
                                             WINHTTP_DEFAULT_ACCEPT_TYPES,
                                             is_https ? WINHTTP_FLAG_SECURE : 0);
    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return false;
    }

    std::wstring ct_header = L"Content-Type: " + std::wstring(content_type.begin(), content_type.end());
    WinHttpAddRequestHeaders(hRequest, ct_header.c_str(), (DWORD)-1L, WINHTTP_ADDREQ_FLAG_ADD);

    BOOL sent = WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                    (LPVOID)body.c_str(), (DWORD)body.size(),
                                    (DWORD)body.size(), 0);

    if (sent) {
        WinHttpReceiveResponse(hRequest, nullptr);

        if (response) {
            DWORD bytes_available, bytes_read;
            do {
                bytes_available = 0;
                WinHttpQueryDataAvailable(hRequest, &bytes_available);
                if (bytes_available > 0) {
                    std::vector<char> buf(bytes_available + 1);
                    WinHttpReadData(hRequest, buf.data(), bytes_available, &bytes_read);
                    response->append(buf.data(), bytes_read);
                }
            } while (bytes_available > 0);
        }
    }

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);

    return sent != FALSE;
#else
    return false;
#endif
}

bool SecurityManager::validate_okta_response(const std::string& response) {
    return response.find("\"status\":\"SUCCESS\"") != std::string::npos ||
           response.find("\"sessionToken\"") != std::string::npos;
}

std::string SecurityManager::base64_encode(const std::vector<uint8_t>& data) {
    static const char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    result.reserve((data.size() + 2) / 3 * 4);

    for (size_t i = 0; i < data.size(); i += 3) {
        uint32_t n = ((uint32_t)data[i]) << 16;
        if (i + 1 < data.size()) n |= ((uint32_t)data[i + 1]) << 8;
        if (i + 2 < data.size()) n |= (uint32_t)data[i + 2];

        result += table[(n >> 18) & 0x3F];
        result += table[(n >> 12) & 0x3F];
        result += (i + 1 < data.size()) ? table[(n >> 6) & 0x3F] : '=';
        result += (i + 2 < data.size()) ? table[n & 0x3F] : '=';
    }

    return result;
}

std::vector<uint8_t> SecurityManager::base64_decode(const std::string& encoded) {
    static const uint8_t lookup[128] = {
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64,
        64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 64, 62, 64, 64, 64, 63,
        52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 64, 64, 64, 64, 64,
        64,  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
        15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 64, 64, 64, 64, 64,
        64, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 64, 64, 64, 64, 64
    };

    std::vector<uint8_t> result;
    uint32_t val = 0;
    int bits = -8;

    for (char c : encoded) {
        if (c == '=' || c < 0) break;
        uint8_t v = lookup[(unsigned char)c];
        if (v >= 64) continue;
        val = (val << 6) | v;
        bits += 6;
        if (bits >= 0) {
            result.push_back((uint8_t)((val >> bits) & 0xFF));
            bits -= 8;
        }
    }

    return result;
}

} // namespace netswitch
