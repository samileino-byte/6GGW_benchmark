#include "port_switcher.h"

namespace netswitch {

PortSwitcher::PortSwitcher(WinsockEngine& engine, Logger& logger)
    : engine_(engine), logger_(logger) {}

PortSwitcher::~PortSwitcher() {
    disconnect_current();
}

SwitchResult PortSwitcher::switch_port(const std::string& host, uint16_t from_port, uint16_t to_port) {
    auto start = std::chrono::steady_clock::now();
    SwitchResult result = {};
    result.old_state = current_state_;

    logger_.info("PortSwitch", "Switching " + host + " from port " +
                 std::to_string(from_port) + " to port " + std::to_string(to_port));

    set_state(ConnectionState::SWITCHING, "Initiating port switch");
    stats_.total_switches++;

    // Step 1: Flush pending data
    if (flush_before_switch_ && current_socket_ != INVALID_SOCKET) {
        logger_.debug("PortSwitch", "Flushing socket buffer before disconnect");
        flush_socket(current_socket_);
    }

    // Step 2: Graceful disconnect from current port
    if (current_socket_ != INVALID_SOCKET) {
        logger_.debug("PortSwitch", "Disconnecting from port " + std::to_string(from_port));

        if (graceful_shutdown_) {
            engine_.disconnect_socket(current_socket_, true);
        } else {
            engine_.force_close(current_socket_);
        }
        current_socket_ = INVALID_SOCKET;

        // Step 3: Wait for socket to fully close
        if (!wait_for_close(current_socket_, cleanup_timeout_ms_)) {
            logger_.warning("PortSwitch", "Socket did not close cleanly within timeout");
        }
    }

    // Step 4: Force cleanup TIME_WAIT on both ports
    int tw_from = force_cleanup_time_wait(from_port);
    int tw_to = force_cleanup_time_wait(to_port);
    result.time_wait_cleared = tw_from + tw_to;
    result.sockets_cleaned = tw_from + tw_to;

    if (tw_from > 0 || tw_to > 0) {
        logger_.info("PortSwitch", "Cleared " + std::to_string(tw_from + tw_to) +
                     " TIME_WAIT sockets (port " + std::to_string(from_port) + ": " +
                     std::to_string(tw_from) + ", port " + std::to_string(to_port) + ": " +
                     std::to_string(tw_to) + ")");
    }

    // Step 5: Small delay to ensure OS releases the socket resources
    std::this_thread::sleep_for(std::chrono::milliseconds(50));

    // Step 6: Create new socket and connect to target port
    SOCKET new_sock = engine_.create_socket();
    if (new_sock == INVALID_SOCKET) {
        result.success = false;
        result.error_message = "Failed to create socket: " + engine_.get_last_error();
        set_state(ConnectionState::ERROR_STATE, result.error_message);
        stats_.failed_switches++;
        logger_.error("PortSwitch", result.error_message);
        return result;
    }

    engine_.set_linger(new_sock, true, 0);
    engine_.set_keepalive(new_sock, true, 30);

    if (!engine_.connect_socket(new_sock, host, to_port, connect_timeout_ms_)) {
        engine_.force_close(new_sock);
        result.success = false;
        result.error_message = "Failed to connect to " + host + ":" +
                              std::to_string(to_port) + ": " + engine_.get_last_error();
        set_state(ConnectionState::ERROR_STATE, result.error_message);
        stats_.failed_switches++;
        logger_.error("PortSwitch", result.error_message);
        return result;
    }

    current_socket_ = new_sock;
    current_endpoint_ = {host, to_port, detect_protocol(to_port),
                         host + ":" + std::to_string(to_port)};

    auto end = std::chrono::steady_clock::now();
    double elapsed_ms = std::chrono::duration<double, std::milli>(end - start).count();

    result.success = true;
    result.switch_time_ms = elapsed_ms;
    result.new_state = ConnectionState::CONNECTED;
    set_state(ConnectionState::CONNECTED, "Connected to port " + std::to_string(to_port));

    stats_.successful_switches++;
    stats_.total_time_wait_cleared += result.time_wait_cleared;
    if (stats_.successful_switches == 1) {
        stats_.min_switch_time_ms = elapsed_ms;
        stats_.max_switch_time_ms = elapsed_ms;
        stats_.avg_switch_time_ms = elapsed_ms;
    } else {
        stats_.min_switch_time_ms = std::min(stats_.min_switch_time_ms, elapsed_ms);
        stats_.max_switch_time_ms = std::max(stats_.max_switch_time_ms, elapsed_ms);
        stats_.avg_switch_time_ms = ((stats_.avg_switch_time_ms * (stats_.successful_switches - 1)) +
                                     elapsed_ms) / stats_.successful_switches;
    }

    logger_.info("PortSwitch", "Switch complete in " + std::to_string(elapsed_ms) + "ms | " +
                 std::to_string(from_port) + " -> " + std::to_string(to_port) +
                 " | TIME_WAIT cleared: " + std::to_string(result.time_wait_cleared));

    return result;
}

SwitchResult PortSwitcher::switch_ftp_to_ssh(const std::string& host) {
    return switch_port(host, 21, 22);
}

SwitchResult PortSwitcher::switch_ssh_to_ftp(const std::string& host) {
    return switch_port(host, 22, 21);
}

bool PortSwitcher::connect_to(const std::string& host, uint16_t port, PortProtocol proto) {
    set_state(ConnectionState::CONNECTING, "Connecting to " + host + ":" + std::to_string(port));

    SOCKET sock = engine_.create_socket();
    if (sock == INVALID_SOCKET) {
        set_state(ConnectionState::ERROR_STATE, engine_.get_last_error());
        return false;
    }

    engine_.set_linger(sock, true, 0);
    engine_.set_keepalive(sock, true, 30);

    if (!engine_.connect_socket(sock, host, port, connect_timeout_ms_)) {
        engine_.force_close(sock);
        set_state(ConnectionState::ERROR_STATE, engine_.get_last_error());
        return false;
    }

    current_socket_ = sock;
    if (proto == PortProtocol::CUSTOM) proto = detect_protocol(port);
    current_endpoint_ = {host, port, proto, host + ":" + std::to_string(port)};
    set_state(ConnectionState::CONNECTED, "Connected");
    return true;
}

bool PortSwitcher::disconnect_current() {
    if (current_socket_ == INVALID_SOCKET) return true;

    bool ok = engine_.disconnect_socket(current_socket_, graceful_shutdown_);
    current_socket_ = INVALID_SOCKET;
    set_state(ConnectionState::DISCONNECTED);
    return ok;
}

void PortSwitcher::set_state(ConnectionState state, const std::string& detail) {
    current_state_ = state;
    if (state_callback_) state_callback_(state, detail);
}

bool PortSwitcher::flush_socket(SOCKET sock) {
    if (sock == INVALID_SOCKET) return false;

    engine_.set_nonblocking(sock, true);
    char buf[4096];
    int total = 0;
    while (true) {
        int n = engine_.recv_data(sock, buf, sizeof(buf));
        if (n <= 0) break;
        total += n;
    }
    engine_.set_nonblocking(sock, false);

    if (total > 0) {
        logger_.debug("PortSwitch", "Flushed " + std::to_string(total) + " bytes from socket buffer");
    }
    return true;
}

bool PortSwitcher::wait_for_close(SOCKET sock, int timeout_ms) {
    auto start = std::chrono::steady_clock::now();
    while (true) {
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - start).count();
        if (elapsed >= timeout_ms) return false;

        if (!engine_.is_connected(sock)) return true;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

int PortSwitcher::force_cleanup_time_wait(uint16_t port) {
    set_state(ConnectionState::TIME_WAIT_CLEANUP, "Cleaning TIME_WAIT on port " + std::to_string(port));
    return engine_.cleanup_time_wait(port);
}

PortProtocol PortSwitcher::detect_protocol(uint16_t port) {
    switch (port) {
        case 21: return PortProtocol::FTP_21;
        case 22: return PortProtocol::SSH_22;
        case 443: return PortProtocol::HTTPS_443;
        default: return PortProtocol::CUSTOM;
    }
}

} // namespace netswitch
