#include "winsock_engine.h"
#include <iostream>
#ifndef _WIN32
#include <fcntl.h>
#endif

namespace netswitch {

WinsockEngine::WinsockEngine() {}

WinsockEngine::~WinsockEngine() {
    shutdown();
}

bool WinsockEngine::initialize() {
    std::lock_guard<std::mutex> lk(mutex_);
    if (initialized_) return true;

#ifdef _WIN32
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data_);
    if (result != 0) {
        set_error("WSAStartup failed", result);
        return false;
    }
    if (LOBYTE(wsa_data_.wVersion) != 2 || HIBYTE(wsa_data_.wVersion) != 2) {
        WSACleanup();
        set_error("WinSock 2.2 not available");
        return false;
    }
#endif
    initialized_ = true;
    return true;
}

void WinsockEngine::shutdown() {
    std::lock_guard<std::mutex> lk(mutex_);
    if (!initialized_) return;

    for (auto& [sock, state] : active_sockets_) {
        if (sock != INVALID_SOCKET) {
            ::closesocket(sock);
        }
    }
    active_sockets_.clear();

#ifdef _WIN32
    WSACleanup();
#endif
    initialized_ = false;
}

SOCKET WinsockEngine::create_socket(int af, int type, int protocol) {
    SOCKET sock = ::socket(af, type, protocol);
    if (sock == INVALID_SOCKET) {
#ifdef _WIN32
        set_error("socket() failed", WSAGetLastError());
#else
        set_error("socket() failed", errno);
#endif
        return INVALID_SOCKET;
    }

    set_reuse_addr(sock, true);
    set_nodelay(sock, true);

    return sock;
}

bool WinsockEngine::connect_socket(SOCKET sock, const std::string& host, uint16_t port, int timeout_ms) {
    struct addrinfo hints = {}, *result = nullptr;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    std::string port_str = std::to_string(port);
    int ret = getaddrinfo(host.c_str(), port_str.c_str(), &hints, &result);
    if (ret != 0) {
        set_error("getaddrinfo failed for " + host + ":" + port_str, ret);
        return false;
    }

    set_nonblocking(sock, true);

    bool connected = false;
    for (auto ptr = result; ptr != nullptr; ptr = ptr->ai_next) {
        ret = ::connect(sock, ptr->ai_addr, (int)ptr->ai_addrlen);
        if (ret == 0) {
            connected = true;
            break;
        }

#ifdef _WIN32
        int err = WSAGetLastError();
        if (err == WSAEWOULDBLOCK) {
            fd_set write_fds, error_fds;
            FD_ZERO(&write_fds);
            FD_ZERO(&error_fds);
            FD_SET(sock, &write_fds);
            FD_SET(sock, &error_fds);

            struct timeval tv;
            tv.tv_sec = timeout_ms / 1000;
            tv.tv_usec = (timeout_ms % 1000) * 1000;

            ret = select(0, nullptr, &write_fds, &error_fds, &tv);
            if (ret > 0 && FD_ISSET(sock, &write_fds)) {
                int sock_err = get_socket_error(sock);
                if (sock_err == 0) {
                    connected = true;
                    break;
                }
            }
        }
#else
        if (errno == EINPROGRESS) {
            fd_set write_fds;
            FD_ZERO(&write_fds);
            FD_SET(sock, &write_fds);

            struct timeval tv;
            tv.tv_sec = timeout_ms / 1000;
            tv.tv_usec = (timeout_ms % 1000) * 1000;

            ret = select(sock + 1, nullptr, &write_fds, nullptr, &tv);
            if (ret > 0 && FD_ISSET(sock, &write_fds)) {
                int sock_err = get_socket_error(sock);
                if (sock_err == 0) {
                    connected = true;
                    break;
                }
            }
        }
#endif
    }

    freeaddrinfo(result);
    set_nonblocking(sock, false);

    if (connected) {
        ConnectionEndpoint ep{host, port, PortProtocol::CUSTOM, host + ":" + std::to_string(port)};
        track_socket(sock, ep);
    } else {
        set_error("Connection to " + host + ":" + std::to_string(port) + " failed");
    }

    return connected;
}

bool WinsockEngine::disconnect_socket(SOCKET sock, bool graceful) {
    if (sock == INVALID_SOCKET) return false;

    if (graceful) {
        ::shutdown(sock, 2); // SD_BOTH
        char buf[256];
        while (::recv(sock, buf, sizeof(buf), 0) > 0) {}
    }

    set_linger(sock, true, 0);
    ::closesocket(sock);
    untrack_socket(sock);
    return true;
}

void WinsockEngine::force_close(SOCKET sock) {
    if (sock == INVALID_SOCKET) return;
    set_linger(sock, true, 0);
    ::closesocket(sock);
    untrack_socket(sock);
}

bool WinsockEngine::set_linger(SOCKET sock, bool enable, int timeout_sec) {
    struct linger lg;
    lg.l_onoff = enable ? 1 : 0;
    lg.l_linger = (unsigned short)timeout_sec;
    return setsockopt(sock, SOL_SOCKET, SO_LINGER, (const char*)&lg, sizeof(lg)) == 0;
}

bool WinsockEngine::set_reuse_addr(SOCKET sock, bool enable) {
    int val = enable ? 1 : 0;
    return setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (const char*)&val, sizeof(val)) == 0;
}

bool WinsockEngine::set_nodelay(SOCKET sock, bool enable) {
    int val = enable ? 1 : 0;
    return setsockopt(sock, IPPROTO_TCP, 6 /* TCP_NODELAY */, (const char*)&val, sizeof(val)) == 0;
}

bool WinsockEngine::set_keepalive(SOCKET sock, bool enable, int interval_sec) {
    int val = enable ? 1 : 0;
    if (setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, (const char*)&val, sizeof(val)) != 0)
        return false;

#ifdef _WIN32
    if (enable) {
        DWORD bytes_returned;
        struct tcp_keepalive ka;
        ka.onoff = 1;
        ka.keepalivetime = interval_sec * 1000;
        ka.keepaliveinterval = 1000;
        WSAIoctl(sock, SIO_KEEPALIVE_VALS, &ka, sizeof(ka), nullptr, 0, &bytes_returned, nullptr, nullptr);
    }
#endif
    return true;
}

bool WinsockEngine::set_send_timeout(SOCKET sock, int timeout_ms) {
#ifdef _WIN32
    DWORD tv = timeout_ms;
#else
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
#endif
    return setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, (const char*)&tv, sizeof(tv)) == 0;
}

bool WinsockEngine::set_recv_timeout(SOCKET sock, int timeout_ms) {
#ifdef _WIN32
    DWORD tv = timeout_ms;
#else
    struct timeval tv;
    tv.tv_sec = timeout_ms / 1000;
    tv.tv_usec = (timeout_ms % 1000) * 1000;
#endif
    return setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv)) == 0;
}

bool WinsockEngine::set_nonblocking(SOCKET sock, bool enable) {
#ifdef _WIN32
    u_long mode = enable ? 1 : 0;
    return ioctlsocket(sock, FIONBIO, &mode) == 0;
#else
    int flags = fcntl(sock, F_GETFL, 0);
    if (enable) flags |= O_NONBLOCK;
    else flags &= ~O_NONBLOCK;
    return fcntl(sock, F_SETFL, flags) == 0;
#endif
}

int WinsockEngine::send_data(SOCKET sock, const void* data, int len) {
    int sent = ::send(sock, (const char*)data, len, 0);
    if (sent > 0) {
        std::lock_guard<std::mutex> lk(mutex_);
        auto it = active_sockets_.find(sock);
        if (it != active_sockets_.end()) it->second.bytes_sent += sent;
    }
    return sent;
}

int WinsockEngine::recv_data(SOCKET sock, void* buffer, int len) {
    int received = ::recv(sock, (char*)buffer, len, 0);
    if (received > 0) {
        std::lock_guard<std::mutex> lk(mutex_);
        auto it = active_sockets_.find(sock);
        if (it != active_sockets_.end()) it->second.bytes_received += received;
    }
    return received;
}

bool WinsockEngine::is_connected(SOCKET sock) {
    if (sock == INVALID_SOCKET) return false;
    char buf;
    int result = ::recv(sock, &buf, 1, MSG_PEEK);
    if (result > 0) return true;
    if (result == 0) return false;
#ifdef _WIN32
    int err = WSAGetLastError();
    return err == WSAEWOULDBLOCK;
#else
    return errno == EAGAIN || errno == EWOULDBLOCK;
#endif
}

int WinsockEngine::get_socket_error(SOCKET sock) {
    int err = 0;
    int len = sizeof(err);
    getsockopt(sock, SOL_SOCKET, SO_ERROR, (char*)&err, (socklen_t*)&len);
    return err;
}

std::string WinsockEngine::get_peer_address(SOCKET sock) {
    struct sockaddr_storage addr;
    socklen_t len = sizeof(addr);
    if (getpeername(sock, (struct sockaddr*)&addr, &len) != 0)
        return "";

    char ip[INET6_ADDRSTRLEN] = {};
    if (addr.ss_family == AF_INET) {
        inet_ntop(AF_INET, &((struct sockaddr_in*)&addr)->sin_addr, ip, sizeof(ip));
    } else {
        inet_ntop(AF_INET6, &((struct sockaddr_in6*)&addr)->sin6_addr, ip, sizeof(ip));
    }
    return std::string(ip);
}

uint16_t WinsockEngine::get_peer_port(SOCKET sock) {
    struct sockaddr_storage addr;
    socklen_t len = sizeof(addr);
    if (getpeername(sock, (struct sockaddr*)&addr, &len) != 0) return 0;

    if (addr.ss_family == AF_INET)
        return ntohs(((struct sockaddr_in*)&addr)->sin_port);
    return ntohs(((struct sockaddr_in6*)&addr)->sin6_port);
}

int WinsockEngine::cleanup_time_wait(uint16_t port) {
    int cleaned = 0;
#ifdef _WIN32
    PMIB_TCPTABLE2 tcp_table = nullptr;
    ULONG size = 0;
    ULONG result = GetTcpTable2(nullptr, &size, TRUE);
    if (result == ERROR_INSUFFICIENT_BUFFER) {
        tcp_table = (PMIB_TCPTABLE2)malloc(size);
        if (!tcp_table) return 0;
        result = GetTcpTable2(tcp_table, &size, TRUE);
    }

    if (result == NO_ERROR && tcp_table) {
        for (DWORD i = 0; i < tcp_table->dwNumEntries; i++) {
            auto& row = tcp_table->table[i];
            uint16_t local_port = ntohs((uint16_t)row.dwLocalPort);
            if (local_port == port && row.dwState == MIB_TCP_STATE_TIME_WAIT) {
                MIB_TCPROW delete_row;
                delete_row.dwState = MIB_TCP_STATE_DELETE_TCB;
                delete_row.dwLocalAddr = row.dwLocalAddr;
                delete_row.dwLocalPort = row.dwLocalPort;
                delete_row.dwRemoteAddr = row.dwRemoteAddr;
                delete_row.dwRemotePort = row.dwRemotePort;
                if (SetTcpEntry(&delete_row) == NO_ERROR) {
                    cleaned++;
                }
            }
        }
    }
    if (tcp_table) free(tcp_table);
#endif
    return cleaned;
}

int WinsockEngine::get_time_wait_count(uint16_t port) {
    int count = 0;
#ifdef _WIN32
    PMIB_TCPTABLE2 tcp_table = nullptr;
    ULONG size = 0;
    GetTcpTable2(nullptr, &size, TRUE);
    tcp_table = (PMIB_TCPTABLE2)malloc(size);
    if (tcp_table && GetTcpTable2(tcp_table, &size, TRUE) == NO_ERROR) {
        for (DWORD i = 0; i < tcp_table->dwNumEntries; i++) {
            uint16_t local_port = ntohs((uint16_t)tcp_table->table[i].dwLocalPort);
            if (local_port == port && tcp_table->table[i].dwState == MIB_TCP_STATE_TIME_WAIT) {
                count++;
            }
        }
    }
    if (tcp_table) free(tcp_table);
#endif
    return count;
}

std::vector<SocketState> WinsockEngine::get_active_sockets() const {
    std::lock_guard<std::mutex> lk(mutex_);
    std::vector<SocketState> result;
    for (auto& [_, state] : active_sockets_) {
        result.push_back(state);
    }
    return result;
}

std::string WinsockEngine::wsa_error_string(int error_code) {
    switch (error_code) {
#ifdef _WIN32
        case WSAECONNREFUSED:    return "Connection refused";
        case WSAETIMEDOUT:       return "Connection timed out";
        case WSAECONNRESET:      return "Connection reset by peer";
        case WSAEADDRINUSE:      return "Address already in use";
        case WSAEADDRNOTAVAIL:   return "Address not available";
        case WSAENETUNREACH:     return "Network unreachable";
        case WSAEHOSTUNREACH:    return "Host unreachable";
        case WSAEWOULDBLOCK:     return "Operation would block";
        case WSAEINPROGRESS:     return "Operation in progress";
        case WSAECONNABORTED:    return "Connection aborted";
        case WSAENOTSOCK:        return "Not a socket";
        case WSAESHUTDOWN:       return "Socket shutdown";
        case WSANOTINITIALISED:  return "WSA not initialized";
#endif
        default: return "Error " + std::to_string(error_code);
    }
}

void WinsockEngine::set_error(const std::string& msg, int code) {
    last_error_ = msg;
    last_error_code_ = code;
}

void WinsockEngine::track_socket(SOCKET sock, const ConnectionEndpoint& ep) {
    std::lock_guard<std::mutex> lk(mutex_);
    SocketState state;
    state.socket = sock;
    state.state = ConnectionState::CONNECTED;
    state.endpoint = ep;
    state.connected_at = std::chrono::steady_clock::now();
    state.bytes_sent = 0;
    state.bytes_received = 0;
    state.linger_timeout_ms = 0;
    state.reuse_addr = true;
    active_sockets_[sock] = state;
}

void WinsockEngine::untrack_socket(SOCKET sock) {
    std::lock_guard<std::mutex> lk(mutex_);
    active_sockets_.erase(sock);
}

} // namespace netswitch
