#include "packet_inspector.h"
#include <sstream>
#include <iomanip>
#include <cstring>

namespace netswitch {

static std::string cipher_suite_hex(uint16_t cs) {
    char buf[8];
    snprintf(buf, sizeof(buf), "%04X", cs);
    return buf;
}

PacketInspector::PacketInspector(Logger& logger) : logger_(logger) {}

uint16_t PacketInspector::read_u16_be(const uint8_t* p) {
    return ((uint16_t)p[0] << 8) | p[1];
}

uint32_t PacketInspector::read_u32_be(const uint8_t* p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}

EthernetFrame PacketInspector::parse_ethernet(const uint8_t* data, int len) {
    EthernetFrame frame = {};
    if (len < 14) return frame;

    std::memcpy(frame.dest_mac, data, 6);
    std::memcpy(frame.src_mac, data + 6, 6);
    frame.ethertype = read_u16_be(data + 12);

    // Check for 802.1Q VLAN tag (0x8100)
    if (frame.ethertype == 0x8100 && len >= 18) {
        frame.has_vlan = true;
        uint16_t tci = read_u16_be(data + 14);
        frame.vlan_priority = (tci >> 13) & 0x07;
        frame.vlan_id = tci & 0x0FFF;
        frame.ethertype = read_u16_be(data + 16);
    }

    return frame;
}

IPv4Header PacketInspector::parse_ipv4(const uint8_t* data, int len) {
    IPv4Header hdr = {};
    if (len < 20) return hdr;

    hdr.version = (data[0] >> 4) & 0x0F;
    hdr.ihl = data[0] & 0x0F;
    hdr.dscp = (data[1] >> 2) & 0x3F;
    hdr.ecn = data[1] & 0x03;
    hdr.total_length = read_u16_be(data + 2);
    hdr.identification = read_u16_be(data + 4);

    uint16_t flags_frag = read_u16_be(data + 6);
    hdr.dont_fragment = (flags_frag >> 14) & 0x01;
    hdr.more_fragments = (flags_frag >> 13) & 0x01;
    hdr.fragment_offset = flags_frag & 0x1FFF;

    hdr.ttl = data[8];
    hdr.protocol = data[9];
    hdr.checksum = read_u16_be(data + 10);
    hdr.src_addr = read_u32_be(data + 12);
    hdr.dst_addr = read_u32_be(data + 16);

    hdr.checksum_valid = verify_ip_checksum(data, hdr.ihl * 4);

    stats_.ipv4_packets++;
    return hdr;
}

IPv6Header PacketInspector::parse_ipv6(const uint8_t* data, int len) {
    IPv6Header hdr = {};
    if (len < 40) return hdr;

    uint32_t vtcfl = read_u32_be(data);
    hdr.version = (vtcfl >> 28) & 0x0F;
    hdr.traffic_class = (vtcfl >> 20) & 0xFF;
    hdr.flow_label = vtcfl & 0x000FFFFF;
    hdr.payload_length = read_u16_be(data + 4);
    hdr.next_header = data[6];
    hdr.hop_limit = data[7];
    std::memcpy(hdr.src_addr, data + 8, 16);
    std::memcpy(hdr.dst_addr, data + 24, 16);

    stats_.ipv6_packets++;
    return hdr;
}

TCPHeader PacketInspector::parse_tcp(const uint8_t* data, int len) {
    TCPHeader hdr = {};
    if (len < 20) return hdr;

    hdr.src_port = read_u16_be(data);
    hdr.dst_port = read_u16_be(data + 2);
    hdr.seq_number = read_u32_be(data + 4);
    hdr.ack_number = read_u32_be(data + 8);
    hdr.data_offset = (data[12] >> 4) & 0x0F;

    uint8_t flags = data[13];
    hdr.flag_urg = (flags >> 5) & 0x01;
    hdr.flag_ack = (flags >> 4) & 0x01;
    hdr.flag_psh = (flags >> 3) & 0x01;
    hdr.flag_rst = (flags >> 2) & 0x01;
    hdr.flag_syn = (flags >> 1) & 0x01;
    hdr.flag_fin = flags & 0x01;

    hdr.window_size = read_u16_be(data + 14);
    hdr.checksum = read_u16_be(data + 16);
    hdr.urgent_pointer = read_u16_be(data + 18);

    stats_.tcp_packets++;
    if (hdr.flag_syn) stats_.syn_packets++;
    if (hdr.flag_fin) stats_.fin_packets++;
    if (hdr.flag_rst) stats_.rst_packets++;

    stats_.port_distribution[hdr.src_port]++;
    stats_.port_distribution[hdr.dst_port]++;

    return hdr;
}

UDPHeader PacketInspector::parse_udp(const uint8_t* data, int len) {
    UDPHeader hdr = {};
    if (len < 8) return hdr;

    hdr.src_port = read_u16_be(data);
    hdr.dst_port = read_u16_be(data + 2);
    hdr.length = read_u16_be(data + 4);
    hdr.checksum = read_u16_be(data + 6);

    stats_.udp_packets++;
    stats_.port_distribution[hdr.src_port]++;
    stats_.port_distribution[hdr.dst_port]++;

    return hdr;
}

TLSRecord PacketInspector::parse_tls(const uint8_t* data, int len) {
    TLSRecord rec = {};
    if (len < 5) return rec;

    rec.content_type = data[0];
    rec.version_major = data[1];
    rec.version_minor = data[2];
    rec.length = read_u16_be(data + 3);
    rec.tls_version_string = tls_version_name(rec.version_major, rec.version_minor);

    // Parse handshake messages
    if (rec.content_type == 22 && len >= 9) {
        rec.handshake_type = data[5];

        // ClientHello - extract SNI and cipher suites
        if (rec.handshake_type == 1 && len >= 43) {
            int offset = 5 + 4; // handshake header
            // Skip client version (2) + random (32)
            offset += 2 + 32;

            if (offset < len) {
                // Skip session ID
                uint8_t session_len = data[offset];
                offset += 1 + session_len;

                // Cipher suites
                if (offset + 2 <= len) {
                    uint16_t cs_len = read_u16_be(data + offset);
                    offset += 2;
                    for (int i = 0; i < cs_len && offset + 1 < len; i += 2) {
                        uint16_t cs = read_u16_be(data + offset);
                        rec.cipher_suites.push_back("0x" + cipher_suite_hex(cs));
                        offset += 2;
                    }
                }

                // Skip compression methods
                if (offset < len) {
                    uint8_t comp_len = data[offset];
                    offset += 1 + comp_len;
                }

                // Extensions - look for SNI (type 0x0000)
                if (offset + 2 <= len) {
                    uint16_t ext_len = read_u16_be(data + offset);
                    offset += 2;
                    int ext_end = offset + ext_len;

                    while (offset + 4 <= ext_end && offset + 4 <= len) {
                        uint16_t ext_type = read_u16_be(data + offset);
                        uint16_t ext_data_len = read_u16_be(data + offset + 2);
                        offset += 4;

                        if (ext_type == 0x0000 && offset + 5 <= len) {
                            // SNI extension
                            int sni_offset = offset + 2 + 1; // skip list len + type
                            if (sni_offset + 2 <= len) {
                                uint16_t name_len = read_u16_be(data + sni_offset);
                                sni_offset += 2;
                                if (sni_offset + name_len <= len) {
                                    rec.sni = std::string((char*)data + sni_offset, name_len);
                                }
                            }
                        }
                        offset += ext_data_len;
                    }
                }
            }
        }
    }

    stats_.tls_packets++;
    return rec;
}

PacketSummary PacketInspector::inspect_packet(const uint8_t* data, int len) {
    PacketSummary summary = {};
    summary.timestamp = std::chrono::system_clock::now();
    summary.frame_number = ++frame_counter_;
    summary.length = len;

    stats_.total_packets++;
    stats_.total_bytes += len;

    if (len < 14) {
        summary.protocol = "Unknown";
        summary.info = "Frame too short";
        return summary;
    }

    auto eth = parse_ethernet(data, len);
    int ip_offset = eth.has_vlan ? 18 : 14;

    if (eth.ethertype == 0x0800 && len >= ip_offset + 20) {
        auto ipv4 = parse_ipv4(data + ip_offset, len - ip_offset);
        summary.src_addr = ipv4_to_string(ipv4.src_addr);
        summary.dst_addr = ipv4_to_string(ipv4.dst_addr);

        int transport_offset = ip_offset + ipv4.ihl * 4;

        if (ipv4.protocol == 6 && len >= transport_offset + 20) {
            auto tcp = parse_tcp(data + transport_offset, len - transport_offset);
            summary.src_port = tcp.src_port;
            summary.dst_port = tcp.dst_port;
            summary.protocol = "TCP";
            summary.info = tcp_flags_string(tcp) + " Seq=" +
                          std::to_string(tcp.seq_number) + " Win=" +
                          std::to_string(tcp.window_size);

            // Check for TLS
            int payload_offset = transport_offset + tcp.data_offset * 4;
            if (payload_offset < len && data[payload_offset] >= 20 && data[payload_offset] <= 23) {
                auto tls = parse_tls(data + payload_offset, len - payload_offset);
                if (!tls.tls_version_string.empty()) {
                    summary.protocol = "TLS";
                    summary.is_encrypted = true;
                    summary.info = tls.tls_version_string + " " +
                                  tls_handshake_name(tls.handshake_type);
                    if (!tls.sni.empty()) summary.info += " SNI=" + tls.sni;
                }
            }
        } else if (ipv4.protocol == 17 && len >= transport_offset + 8) {
            auto udp = parse_udp(data + transport_offset, len - transport_offset);
            summary.src_port = udp.src_port;
            summary.dst_port = udp.dst_port;

            // IKEv2 on port 500/4500
            if (udp.src_port == 500 || udp.dst_port == 500 ||
                udp.src_port == 4500 || udp.dst_port == 4500) {
                summary.protocol = "IKEv2";
                summary.info = "IKE SA negotiation";
            } else {
                summary.protocol = "UDP";
                summary.info = "Len=" + std::to_string(udp.length);
            }
        } else {
            summary.protocol = protocol_name(ipv4.protocol);
        }

        summary.info += " TTL=" + std::to_string(ipv4.ttl);
        if (!ipv4.checksum_valid) summary.info += " [BAD CHECKSUM]";

    } else if (eth.ethertype == 0x86DD && len >= ip_offset + 40) {
        auto ipv6 = parse_ipv6(data + ip_offset, len - ip_offset);
        summary.src_addr = ipv6_to_string(ipv6.src_addr);
        summary.dst_addr = ipv6_to_string(ipv6.dst_addr);
        summary.protocol = protocol_name(ipv6.next_header);
    } else if (eth.ethertype == 0x0806) {
        summary.protocol = "ARP";
        summary.info = "ARP " + mac_to_string(eth.src_mac) + " -> " + mac_to_string(eth.dest_mac);
    } else {
        summary.protocol = ethertype_name(eth.ethertype);
    }

    stats_.protocol_distribution[summary.protocol]++;
    return summary;
}

std::vector<PacketSummary> PacketInspector::inspect_stream(
    const std::vector<std::vector<uint8_t>>& packets) {
    std::vector<PacketSummary> results;
    results.reserve(packets.size());
    for (auto& pkt : packets) {
        results.push_back(inspect_packet(pkt.data(), (int)pkt.size()));
    }
    return results;
}

uint16_t PacketInspector::compute_ip_checksum(const uint8_t* header, int len) {
    uint32_t sum = 0;
    for (int i = 0; i < len; i += 2) {
        uint16_t word = ((uint16_t)header[i] << 8);
        if (i + 1 < len) word |= header[i + 1];
        sum += word;
    }
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (uint16_t)(~sum & 0xFFFF);
}

bool PacketInspector::verify_ip_checksum(const uint8_t* header, int len) {
    return compute_ip_checksum(header, len) == 0;
}

std::string PacketInspector::mac_to_string(const uint8_t mac[6]) {
    char buf[18];
    snprintf(buf, sizeof(buf), "%02x:%02x:%02x:%02x:%02x:%02x",
             mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    return buf;
}

std::string PacketInspector::ipv4_to_string(uint32_t addr) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%u.%u.%u.%u",
             (addr >> 24) & 0xFF, (addr >> 16) & 0xFF,
             (addr >> 8) & 0xFF, addr & 0xFF);
    return buf;
}

std::string PacketInspector::ipv6_to_string(const uint8_t addr[16]) {
    char buf[40];
    snprintf(buf, sizeof(buf), "%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x",
             addr[0], addr[1], addr[2], addr[3], addr[4], addr[5], addr[6], addr[7],
             addr[8], addr[9], addr[10], addr[11], addr[12], addr[13], addr[14], addr[15]);
    return buf;
}

std::string PacketInspector::protocol_name(uint8_t protocol_number) {
    switch (protocol_number) {
        case 1:  return "ICMP";
        case 2:  return "IGMP";
        case 6:  return "TCP";
        case 17: return "UDP";
        case 41: return "IPv6-in-IPv4";
        case 47: return "GRE";
        case 50: return "ESP";
        case 51: return "AH";
        case 58: return "ICMPv6";
        case 89: return "OSPF";
        case 132: return "SCTP";
        default: return "Proto-" + std::to_string(protocol_number);
    }
}

std::string PacketInspector::ethertype_name(uint16_t ethertype) {
    switch (ethertype) {
        case 0x0800: return "IPv4";
        case 0x0806: return "ARP";
        case 0x8100: return "802.1Q";
        case 0x86DD: return "IPv6";
        case 0x8847: return "MPLS";
        case 0x88CC: return "LLDP";
        case 0x88F7: return "PTP";
        default: return "EtherType-0x" + std::to_string(ethertype);
    }
}

std::string PacketInspector::tcp_flags_string(const TCPHeader& tcp) {
    std::string flags = "[";
    if (tcp.flag_syn) flags += "SYN ";
    if (tcp.flag_ack) flags += "ACK ";
    if (tcp.flag_psh) flags += "PSH ";
    if (tcp.flag_rst) flags += "RST ";
    if (tcp.flag_fin) flags += "FIN ";
    if (tcp.flag_urg) flags += "URG ";
    if (flags.back() == ' ') flags.pop_back();
    flags += "]";
    return flags;
}

std::string PacketInspector::tls_version_name(uint8_t major, uint8_t minor) {
    if (major == 3) {
        switch (minor) {
            case 0: return "SSLv3.0";
            case 1: return "TLSv1.0";
            case 2: return "TLSv1.1";
            case 3: return "TLSv1.2";
            case 4: return "TLSv1.3";
        }
    }
    return "TLS-" + std::to_string(major) + "." + std::to_string(minor);
}

std::string PacketInspector::tls_handshake_name(uint8_t type) {
    switch (type) {
        case 0:  return "HelloRequest";
        case 1:  return "ClientHello";
        case 2:  return "ServerHello";
        case 4:  return "NewSessionTicket";
        case 8:  return "EncryptedExtensions";
        case 11: return "Certificate";
        case 12: return "ServerKeyExchange";
        case 13: return "CertificateRequest";
        case 14: return "ServerHelloDone";
        case 15: return "CertificateVerify";
        case 16: return "ClientKeyExchange";
        case 20: return "Finished";
        default: return "Handshake-" + std::to_string(type);
    }
}

} // namespace netswitch
