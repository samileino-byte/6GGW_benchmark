#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

class NetworkConfig {
public:
    explicit NetworkConfig(Logger& logger);
    ~NetworkConfig();

    std::vector<NetworkInterface> get_interfaces();
    NetworkInterface get_interface(const std::string& name);

    bool set_static_ip(const std::string& iface, const std::string& ip,
                       const std::string& subnet, const std::string& gateway);
    bool set_dhcp(const std::string& iface);
    bool set_dns(const std::string& iface, const std::string& primary,
                 const std::string& secondary = "");
    bool set_mtu(const std::string& iface, uint32_t mtu);

    bool enable_interface(const std::string& iface);
    bool disable_interface(const std::string& iface);

    bool switch_ip(const std::string& iface, const std::string& from_ip,
                   const std::string& to_ip, const std::string& subnet);

    bool flush_dns();
    bool flush_arp();
    bool reset_winsock();
    bool reset_tcp_ip();

    std::string get_default_gateway();
    std::string get_primary_dns();
    std::vector<std::string> get_routing_table();

    bool add_route(const std::string& dest, const std::string& mask,
                   const std::string& gateway, int metric = 0);
    bool remove_route(const std::string& dest, const std::string& mask);

    struct ConnectionTest {
        bool dns_ok;
        bool gateway_ok;
        bool internet_ok;
        double latency_ms;
        std::string public_ip;
    };
    ConnectionTest test_connectivity(const std::string& test_host = "8.8.8.8");

    bool is_elevated() const;

private:
    Logger& logger_;

    bool execute_netsh(const std::string& args, std::string* output = nullptr);
    bool execute_command(const std::string& cmd, std::string* output = nullptr);

#ifdef _WIN32
    bool set_ip_via_api(const std::string& iface, const std::string& ip,
                        const std::string& subnet, const std::string& gateway);
    std::vector<NetworkInterface> enumerate_adapters_win32();
#endif
};

} // namespace netswitch
