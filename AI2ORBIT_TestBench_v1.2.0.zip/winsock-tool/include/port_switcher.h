#pragma once
#include "netswitch.h"
#include "winsock_engine.h"
#include "logger.h"

namespace netswitch {

class PortSwitcher {
public:
    explicit PortSwitcher(WinsockEngine& engine, Logger& logger);
    ~PortSwitcher();

    SwitchResult switch_port(const std::string& host, uint16_t from_port, uint16_t to_port);
    SwitchResult switch_ftp_to_ssh(const std::string& host);
    SwitchResult switch_ssh_to_ftp(const std::string& host);

    bool connect_to(const std::string& host, uint16_t port, PortProtocol proto = PortProtocol::CUSTOM);
    bool disconnect_current();

    ConnectionState get_state() const { return current_state_; }
    ConnectionEndpoint get_current_endpoint() const { return current_endpoint_; }
    SOCKET get_current_socket() const { return current_socket_; }

    void set_cleanup_timeout_ms(int ms) { cleanup_timeout_ms_ = ms; }
    void set_connect_timeout_ms(int ms) { connect_timeout_ms_ = ms; }
    void set_graceful_shutdown(bool enabled) { graceful_shutdown_ = enabled; }
    void set_flush_before_switch(bool enabled) { flush_before_switch_ = enabled; }

    void on_state_change(StateCallback cb) { state_callback_ = cb; }

    struct SwitchStats {
        uint64_t total_switches;
        uint64_t successful_switches;
        uint64_t failed_switches;
        double avg_switch_time_ms;
        double min_switch_time_ms;
        double max_switch_time_ms;
        int total_time_wait_cleared;
    };
    SwitchStats get_stats() const { return stats_; }

private:
    WinsockEngine& engine_;
    Logger& logger_;
    SOCKET current_socket_ = INVALID_SOCKET;
    ConnectionState current_state_ = ConnectionState::DISCONNECTED;
    ConnectionEndpoint current_endpoint_;
    StateCallback state_callback_;

    int cleanup_timeout_ms_ = 1000;
    int connect_timeout_ms_ = 5000;
    bool graceful_shutdown_ = true;
    bool flush_before_switch_ = true;

    SwitchStats stats_ = {};

    void set_state(ConnectionState state, const std::string& detail = "");
    bool flush_socket(SOCKET sock);
    bool wait_for_close(SOCKET sock, int timeout_ms);
    int force_cleanup_time_wait(uint16_t port);
    PortProtocol detect_protocol(uint16_t port);
};

} // namespace netswitch
