#pragma once

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <windows.h>
#include <shellapi.h>
#include <wincrypt.h>
#include <winhttp.h>
#include <commctrl.h>
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "advapi32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
typedef int SOCKET;
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#define closesocket close
#endif

#include <string>
#include <vector>
#include <memory>
#include <functional>
#include <mutex>
#include <atomic>
#include <thread>
#include <random>
#include <chrono>
#include <map>
#include <queue>
#include <sstream>
#include <fstream>
#include <ctime>
#include <cstring>
#include <algorithm>

#ifndef NETSWITCH_VERSION
#define NETSWITCH_VERSION "1.0.0"
#endif

namespace netswitch {

enum class LogLevel { TRACE, DEBUG, INFO, WARNING, ERROR_LEVEL, CRITICAL };
enum class PortProtocol { FTP_21, SSH_22, HTTPS_443, CUSTOM };
enum class TunnelType { IKEV2, SSH, GRU, NONE };
enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, SWITCHING, ERROR_STATE, TIME_WAIT_CLEANUP };
enum class AuthMethod { NONE, CERTIFICATE, OKTA_SSO, ZSCALER_ZTNA };

struct LogEntry {
    std::chrono::system_clock::time_point timestamp;
    LogLevel level;
    std::string source;
    std::string message;
    std::string details;
};

struct ConnectionEndpoint {
    std::string host;
    uint16_t port;
    PortProtocol protocol;
    std::string label;
};

struct SocketState {
    SOCKET socket;
    ConnectionState state;
    ConnectionEndpoint endpoint;
    std::chrono::steady_clock::time_point connected_at;
    uint64_t bytes_sent;
    uint64_t bytes_received;
    int linger_timeout_ms;
    bool reuse_addr;
};

struct NetworkInterface {
    std::string name;
    std::string description;
    std::string ipv4_address;
    std::string ipv4_subnet;
    std::string ipv4_gateway;
    std::string ipv6_address;
    std::string mac_address;
    bool dhcp_enabled;
    bool is_up;
    uint32_t mtu;
    uint64_t speed_bps;
};

struct TunnelConfig {
    TunnelType type;
    std::string remote_host;
    uint16_t remote_port;
    std::string local_bind;
    uint16_t local_port;
    std::string certificate_path;
    std::string key_path;
    std::string username;
    std::string password;
    int keepalive_interval_sec;
    int reconnect_delay_sec;
    bool auto_reconnect;
};

struct SecurityConfig {
    AuthMethod auth_method;
    std::string okta_domain;
    std::string okta_client_id;
    std::string okta_redirect_uri;
    std::string zscaler_cloud;
    std::string zscaler_policy;
    std::string cert_store_path;
    bool pci_dss_logging;
    bool enforce_tls13;
};

struct SwitchResult {
    bool success;
    double switch_time_ms;
    ConnectionState old_state;
    ConnectionState new_state;
    std::string error_message;
    int sockets_cleaned;
    int time_wait_cleared;
};

using LogCallback = std::function<void(const LogEntry&)>;
using StateCallback = std::function<void(ConnectionState, const std::string&)>;

} // namespace netswitch
