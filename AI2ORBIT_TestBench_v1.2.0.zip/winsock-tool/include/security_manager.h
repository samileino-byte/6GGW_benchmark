#pragma once
#include "netswitch.h"
#include "logger.h"

namespace netswitch {

class SecurityManager {
public:
    SecurityManager(Logger& logger, const SecurityConfig& config);
    ~SecurityManager();

    bool initialize();

    struct AuthToken {
        std::string access_token;
        std::string token_type;
        int expires_in;
        std::chrono::system_clock::time_point issued_at;
        std::string scope;
    };

    bool authenticate_okta(const std::string& username, const std::string& password);
    bool authenticate_okta_sso();
    AuthToken get_current_token() const { return current_token_; }
    bool is_authenticated() const { return authenticated_; }
    bool refresh_token();

    bool connect_zscaler();
    bool disconnect_zscaler();
    bool is_zscaler_connected() const { return zscaler_connected_; }

    bool load_pkcs12_certificate(const std::string& path, const std::string& password);
    bool verify_server_certificate(const std::string& cert_pem);
    bool check_certificate_expiry(int warn_days = 30);

    std::string encrypt_aes256(const std::string& plaintext, const std::string& key);
    std::string decrypt_aes256(const std::string& ciphertext, const std::string& key);
    std::string generate_session_key();

    void log_pci_event(const std::string& event_type, const std::string& details,
                       const std::string& user = "", bool success = true);
    std::vector<LogEntry> get_pci_audit_log(int max_entries = 100);
    bool export_pci_audit(const std::string& path);

    bool enforce_tls13() const { return config_.enforce_tls13; }

private:
    Logger& logger_;
    SecurityConfig config_;
    AuthToken current_token_;
    bool authenticated_ = false;
    bool zscaler_connected_ = false;
    mutable std::mutex mutex_;
    std::vector<LogEntry> pci_audit_log_;

    bool http_post(const std::string& url, const std::string& body,
                   const std::string& content_type, std::string* response);
    bool validate_okta_response(const std::string& response);
    std::string base64_encode(const std::vector<uint8_t>& data);
    std::vector<uint8_t> base64_decode(const std::string& encoded);
};

} // namespace netswitch
