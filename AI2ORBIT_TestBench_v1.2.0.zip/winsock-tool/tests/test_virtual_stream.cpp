#include "virtual_stream.h"
#include <cassert>
#include <iostream>
#include <sstream>
#include <cstring>
#include <thread>

using namespace netswitch;

static int tests_run = 0;
static int tests_passed = 0;

#define TEST(name) do { \
    tests_run++; \
    std::cout << "  [TEST] " << name << "... "; \
    std::cout.flush(); \
} while(0)

#define PASS() do { \
    tests_passed++; \
    std::cout << "PASS" << std::endl; \
} while(0)

#define FAIL(msg) do { \
    std::cout << "FAIL: " << msg << std::endl; \
} while(0)

// ---------------------------------------------------------------------------
// Test: Stream ID validation
// ---------------------------------------------------------------------------
static void test_stream_id_validation() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("System stream IDs 1-6 are valid");
    for (int i = 1; i <= 6; i++) {
        auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080);
        assert(vs.open_stream(cfg));
        assert(vs.is_stream_open(i));
        vs.close_stream(i);
    }
    PASS();

    TEST("System stream ID 0 is invalid");
    {
        auto cfg = VirtualStream::make_system_stream(0, "127.0.0.1", 8080);
        cfg.stream_id = 0;
        assert(!vs.open_stream(cfg));
    }
    PASS();

    TEST("System stream ID 7+ is invalid for SYSTEM group");
    {
        StreamConfig cfg = {};
        cfg.stream_id = 7;
        cfg.group = StreamGroup::SYSTEM;
        cfg.protocol = StreamProtocol::TCP;
        cfg.security_mode = StreamSecurityMode::EPHEMERAL;
        cfg.remote_host = "127.0.0.1";
        cfg.remote_port = 8080;
        cfg.socket_timeout_ms = 5000;
        cfg.max_retries = 0;
        assert(!vs.open_stream(cfg));
    }
    PASS();

    TEST("Application stream IDs 7+ are valid");
    for (int i = 7; i <= 12; i++) {
        auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 9090);
        assert(vs.open_stream(cfg));
        assert(vs.is_stream_open(i));
        vs.close_stream(i);
    }
    PASS();

    TEST("Application stream ID < 7 is invalid for APP group");
    {
        StreamConfig cfg = {};
        cfg.stream_id = 3;
        cfg.group = StreamGroup::APPLICATION;
        cfg.protocol = StreamProtocol::TCP;
        cfg.security_mode = StreamSecurityMode::EPHEMERAL;
        cfg.remote_host = "127.0.0.1";
        cfg.remote_port = 8080;
        cfg.socket_timeout_ms = 5000;
        cfg.max_retries = 0;
        assert(!vs.open_stream(cfg));
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Stream lifecycle (open/close)
// ---------------------------------------------------------------------------
static void test_stream_lifecycle() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Open and close system stream");
    {
        auto cfg = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        assert(vs.open_stream(cfg));
        assert(vs.is_stream_open(1));
        assert(vs.close_stream(1));
        assert(!vs.is_stream_open(1));
    }
    PASS();

    TEST("Duplicate stream ID rejected");
    {
        auto cfg = VirtualStream::make_system_stream(2, "127.0.0.1", 8080);
        assert(vs.open_stream(cfg));
        assert(!vs.open_stream(cfg));
        vs.close_stream(2);
    }
    PASS();

    TEST("Reopen after close");
    {
        auto cfg = VirtualStream::make_system_stream(3, "127.0.0.1", 8080);
        assert(vs.open_stream(cfg));
        vs.close_stream(3);
        assert(!vs.is_stream_open(3));
        assert(vs.open_stream(cfg));
        vs.close_stream(3);
    }
    PASS();

    TEST("Close non-existent stream returns false");
    assert(!vs.close_stream(99));
    PASS();

    TEST("All 6 system streams open simultaneously");
    {
        for (int i = 1; i <= 6; i++) {
            auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080 + i);
            assert(vs.open_stream(cfg));
        }
        auto sys = vs.get_system_streams();
        assert(sys.size() == 6);
        for (int i = 1; i <= 6; i++) vs.close_stream(i);
    }
    PASS();

    TEST("Multiple app streams open simultaneously");
    {
        for (int i = 7; i <= 16; i++) {
            auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 9000 + i);
            assert(vs.open_stream(cfg));
        }
        auto apps = vs.get_application_streams();
        assert(apps.size() == 10);
        for (int i = 7; i <= 16; i++) vs.close_stream(i);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Stream groups
// ---------------------------------------------------------------------------
static void test_stream_groups() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("System and app streams coexist");
    {
        for (int i = 1; i <= 3; i++) {
            auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080);
            vs.open_stream(cfg);
        }
        for (int i = 7; i <= 9; i++) {
            auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 9090);
            vs.open_stream(cfg);
        }

        auto all = vs.get_open_streams();
        auto sys = vs.get_system_streams();
        auto app = vs.get_application_streams();

        assert(all.size() == 6);
        assert(sys.size() == 3);
        assert(app.size() == 3);

        for (int id : all) vs.close_stream(id);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Configuration factory methods
// ---------------------------------------------------------------------------
static void test_config_factories() {
    TEST("make_system_stream defaults");
    {
        auto cfg = VirtualStream::make_system_stream(1, "10.0.0.1", 443);
        assert(cfg.stream_id == 1);
        assert(cfg.group == StreamGroup::SYSTEM);
        assert(cfg.protocol == StreamProtocol::TCP);
        assert(cfg.security_mode == StreamSecurityMode::EPHEMERAL);
        assert(cfg.remote_host == "10.0.0.1");
        assert(cfg.remote_port == 443);
        assert(cfg.tcp_nodelay == true);
        assert(cfg.max_retries == 2);
    }
    PASS();

    TEST("make_app_stream defaults");
    {
        auto cfg = VirtualStream::make_app_stream(10, "192.168.1.1", 8080);
        assert(cfg.stream_id == 10);
        assert(cfg.group == StreamGroup::APPLICATION);
        assert(cfg.max_retries == 3);
        assert(cfg.socket_timeout_ms == 10000);
    }
    PASS();

    TEST("make_vpn_stream defaults");
    {
        auto cfg = VirtualStream::make_vpn_stream(5, "vpn.example.com", 1194, "tun-001");
        assert(cfg.stream_id == 5);
        assert(cfg.group == StreamGroup::SYSTEM);
        assert(cfg.protocol == StreamProtocol::TLS_TCP);
        assert(cfg.security_mode == StreamSecurityMode::TUNNEL_VPN);
        assert(cfg.tunnel_id == "tun-001");
        assert(cfg.so_keepalive == true);
    }
    PASS();

    TEST("make_vpn_stream auto-detects APP group for ID >= 7");
    {
        auto cfg = VirtualStream::make_vpn_stream(8, "vpn.example.com", 1194, "tun-002");
        assert(cfg.group == StreamGroup::APPLICATION);
    }
    PASS();
}

// ---------------------------------------------------------------------------
// Test: Stats tracking
// ---------------------------------------------------------------------------
static void test_stats_tracking() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Initial stats are zero");
    {
        auto cfg = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        vs.open_stream(cfg);
        auto stats = vs.get_stats(1);
        assert(stats.stream_id == 1);
        assert(stats.total_transfers == 0);
        assert(stats.total_bytes_sent == 0);
        vs.close_stream(1);
    }
    PASS();

    TEST("Stats for non-existent stream returns empty");
    {
        auto stats = vs.get_stats(999);
        assert(stats.stream_id == 0);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Event callbacks
// ---------------------------------------------------------------------------
static void test_event_callbacks() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    std::vector<std::pair<std::string, int>> events;

    vs.on_event([&events](int stream_id, const std::string& event, const std::string& /*detail*/) {
        events.push_back({event, stream_id});
    });

    TEST("OPENED event fires on open_stream");
    {
        auto cfg = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        vs.open_stream(cfg);
        bool found = false;
        for (auto& e : events) {
            if (e.first == "OPENED" && e.second == 1) { found = true; break; }
        }
        assert(found);
    }
    PASS();

    TEST("CLOSED event fires on close_stream");
    {
        events.clear();
        vs.close_stream(1);
        bool found = false;
        for (auto& e : events) {
            if (e.first == "CLOSED" && e.second == 1) { found = true; break; }
        }
        assert(found);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Send to unreachable host (ephemeral socket open/close verification)
// ---------------------------------------------------------------------------
static void test_ephemeral_send() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Send to unreachable host fails gracefully");
    {
        auto cfg = VirtualStream::make_system_stream(1, "192.0.2.1", 65534);
        cfg.socket_timeout_ms = 500;
        cfg.max_retries = 0;
        vs.open_stream(cfg);

        const char* data = "test payload";
        auto result = vs.send(1, data, strlen(data));
        assert(!result.success);
        assert(result.socket_opens > 0);
        assert(result.error.length() > 0);

        auto stats = vs.get_stats(1);
        assert(stats.total_transfers == 1);
        assert(stats.failed_transfers == 1);
        assert(stats.total_socket_opens > 0);

        vs.close_stream(1);
    }
    PASS();

    TEST("Send to non-open stream returns error");
    {
        const char* data = "test";
        auto result = vs.send(99, data, 4);
        assert(!result.success);
        assert(result.error == "Stream not open");
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Concurrent stream operations
// ---------------------------------------------------------------------------
static void test_concurrent_operations() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Concurrent open/close from multiple threads");
    {
        std::vector<std::thread> threads;
        std::atomic<int> successes{0};

        for (int i = 1; i <= 6; i++) {
            threads.emplace_back([&vs, i, &successes]() {
                auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 8080 + i);
                if (vs.open_stream(cfg)) successes++;
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                vs.close_stream(i);
            });
        }

        for (auto& t : threads) t.join();
        assert(successes.load() == 6);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Multiple protocol types
// ---------------------------------------------------------------------------
static void test_protocol_types() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("TCP stream config");
    {
        StreamConfig cfg = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        cfg.protocol = StreamProtocol::TCP;
        assert(vs.open_stream(cfg));
        assert(vs.get_config(1).protocol == StreamProtocol::TCP);
        vs.close_stream(1);
    }
    PASS();

    TEST("UDP stream config");
    {
        StreamConfig cfg = VirtualStream::make_system_stream(2, "127.0.0.1", 8081);
        cfg.protocol = StreamProtocol::UDP;
        assert(vs.open_stream(cfg));
        assert(vs.get_config(2).protocol == StreamProtocol::UDP);
        vs.close_stream(2);
    }
    PASS();

    TEST("TLS_TCP stream config");
    {
        StreamConfig cfg = VirtualStream::make_system_stream(3, "127.0.0.1", 443);
        cfg.protocol = StreamProtocol::TLS_TCP;
        assert(vs.open_stream(cfg));
        assert(vs.get_config(3).protocol == StreamProtocol::TLS_TCP);
        vs.close_stream(3);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Security modes
// ---------------------------------------------------------------------------
static void test_security_modes() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Ephemeral security mode");
    {
        auto cfg = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        assert(cfg.security_mode == StreamSecurityMode::EPHEMERAL);
        assert(vs.open_stream(cfg));
        vs.close_stream(1);
    }
    PASS();

    TEST("Persistent security mode");
    {
        StreamConfig cfg = VirtualStream::make_app_stream(7, "127.0.0.1", 8080);
        cfg.security_mode = StreamSecurityMode::PERSISTENT;
        assert(vs.open_stream(cfg));
        assert(vs.get_config(7).security_mode == StreamSecurityMode::PERSISTENT);
        vs.close_stream(7);
    }
    PASS();

    TEST("VPN tunnel security mode");
    {
        auto cfg = VirtualStream::make_vpn_stream(8, "vpn.test.com", 1194, "tun-test");
        assert(cfg.security_mode == StreamSecurityMode::TUNNEL_VPN);
        assert(vs.open_stream(cfg));
        vs.close_stream(8);
    }
    PASS();

    TEST("VPN send without TunnelManager fails gracefully");
    {
        auto cfg = VirtualStream::make_vpn_stream(9, "vpn.test.com", 1194, "tun-test");
        cfg.max_retries = 0;
        cfg.socket_timeout_ms = 500;
        vs.open_stream(cfg);

        const char* data = "vpn test";
        auto result = vs.send(9, data, strlen(data));
        assert(!result.success);

        vs.close_stream(9);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Stream config retrieval
// ---------------------------------------------------------------------------
static void test_config_retrieval() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Get config for open stream");
    {
        auto cfg = VirtualStream::make_system_stream(1, "10.0.0.5", 9999);
        vs.open_stream(cfg);
        auto retrieved = vs.get_config(1);
        assert(retrieved.stream_id == 1);
        assert(retrieved.remote_host == "10.0.0.5");
        assert(retrieved.remote_port == 9999);
        vs.close_stream(1);
    }
    PASS();

    TEST("Get config for closed stream returns empty");
    {
        auto retrieved = vs.get_config(99);
        assert(retrieved.stream_id == 0);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Full system + app stream scenario
// ---------------------------------------------------------------------------
static void test_full_scenario() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    logger.set_level(LogLevel::WARNING);
    VirtualStream vs(engine, logger);

    TEST("Full scenario: 6 system + 4 app streams");
    {
        for (int i = 1; i <= 6; i++) {
            auto cfg = VirtualStream::make_system_stream(i, "127.0.0.1", 10000 + i);
            assert(vs.open_stream(cfg));
        }
        for (int i = 7; i <= 10; i++) {
            auto cfg = VirtualStream::make_app_stream(i, "127.0.0.1", 20000 + i);
            assert(vs.open_stream(cfg));
        }

        assert(vs.get_open_streams().size() == 10);
        assert(vs.get_system_streams().size() == 6);
        assert(vs.get_application_streams().size() == 4);

        for (int i = 1; i <= 3; i++) vs.close_stream(i);
        assert(vs.get_system_streams().size() == 3);
        assert(vs.get_open_streams().size() == 7);

        for (int id : vs.get_open_streams()) vs.close_stream(id);
        assert(vs.get_open_streams().empty());
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: VirtualStreamPipe
// ---------------------------------------------------------------------------
static void test_pipe_creation() {
    WinsockEngine engine;
    engine.initialize();
    Logger logger;
    VirtualStream vs(engine, logger);

    TEST("Pipe requires both streams open");
    {
        auto cfg1 = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        vs.open_stream(cfg1);

        VirtualStreamPipe pipe(vs, 1, 7, logger);
        assert(!pipe.start());

        vs.close_stream(1);
    }
    PASS();

    TEST("Pipe stats initially zero");
    {
        auto cfg1 = VirtualStream::make_system_stream(1, "127.0.0.1", 8080);
        auto cfg2 = VirtualStream::make_app_stream(7, "127.0.0.1", 9090);
        vs.open_stream(cfg1);
        vs.open_stream(cfg2);

        VirtualStreamPipe pipe(vs, 1, 7, logger);
        auto stats = pipe.get_stats();
        assert(stats.messages_forwarded == 0);
        assert(stats.bytes_forwarded == 0);
        assert(stats.errors == 0);

        vs.close_stream(1);
        vs.close_stream(7);
    }
    PASS();

    engine.shutdown();
}

// ---------------------------------------------------------------------------
// Test: Constants
// ---------------------------------------------------------------------------
static void test_constants() {
    TEST("Stream ID range constants");
    assert(VirtualStream::SYSTEM_STREAM_MIN == 1);
    assert(VirtualStream::SYSTEM_STREAM_MAX == 6);
    assert(VirtualStream::APP_STREAM_MIN == 7);
    assert(VirtualStream::APP_STREAM_MAX == 65535);
    PASS();
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
int main() {
    std::cout << "================================================================" << std::endl;
    std::cout << "  AI2ORBIT Virtual Stream Tests" << std::endl;
    std::cout << "  Protocol > Port > Socket > App" << std::endl;
    std::cout << "================================================================" << std::endl;
    std::cout << std::endl;

    std::cout << "[Stream ID Validation]" << std::endl;
    test_stream_id_validation();
    std::cout << std::endl;

    std::cout << "[Stream Lifecycle]" << std::endl;
    test_stream_lifecycle();
    std::cout << std::endl;

    std::cout << "[Stream Groups]" << std::endl;
    test_stream_groups();
    std::cout << std::endl;

    std::cout << "[Config Factory Methods]" << std::endl;
    test_config_factories();
    std::cout << std::endl;

    std::cout << "[Stats Tracking]" << std::endl;
    test_stats_tracking();
    std::cout << std::endl;

    std::cout << "[Event Callbacks]" << std::endl;
    test_event_callbacks();
    std::cout << std::endl;

    std::cout << "[Ephemeral Send]" << std::endl;
    test_ephemeral_send();
    std::cout << std::endl;

    std::cout << "[Concurrent Operations]" << std::endl;
    test_concurrent_operations();
    std::cout << std::endl;

    std::cout << "[Protocol Types]" << std::endl;
    test_protocol_types();
    std::cout << std::endl;

    std::cout << "[Security Modes]" << std::endl;
    test_security_modes();
    std::cout << std::endl;

    std::cout << "[Config Retrieval]" << std::endl;
    test_config_retrieval();
    std::cout << std::endl;

    std::cout << "[Full Scenario]" << std::endl;
    test_full_scenario();
    std::cout << std::endl;

    std::cout << "[Pipe Creation]" << std::endl;
    test_pipe_creation();
    std::cout << std::endl;

    std::cout << "[Constants]" << std::endl;
    test_constants();
    std::cout << std::endl;

    std::cout << "================================================================" << std::endl;
    std::cout << "  Results: " << tests_passed << "/" << tests_run << " passed" << std::endl;
    if (tests_passed == tests_run) {
        std::cout << "  ALL TESTS PASSED" << std::endl;
    } else {
        std::cout << "  FAILURES: " << (tests_run - tests_passed) << std::endl;
    }
    std::cout << "================================================================" << std::endl;

    return (tests_passed == tests_run) ? 0 : 1;
}
